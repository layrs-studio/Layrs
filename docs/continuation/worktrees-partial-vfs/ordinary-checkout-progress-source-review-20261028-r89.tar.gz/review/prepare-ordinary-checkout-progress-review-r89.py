from pathlib import Path
import datetime, difflib, hashlib, json, subprocess

root = Path('D:/Layrs/layrs')
tmp = Path('D:/Layrs/tmp')
prefix = 'provider-ordinary-checkout-progress'
baseline = root / '.layrs-local/validation/provider-ordinary-fresh-private-ready-20261028-r88/source'
old = json.loads((tmp / 'provider-ordinary-ready-ordering-review-r86-inputs.json').read_bytes())
head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD']).decode().strip()
assert head == '91c566ab6cf778f731167e7adc1334fc1a46ce73'
branch = subprocess.check_output(['git', '-C', str(root), 'branch', '--show-current']).decode().strip()
assert branch == 'feature/worktrees-partial-vfs'
changed = subprocess.check_output(['git', '-C', str(root), 'diff', '--name-only', '--', '*.rs']).decode().splitlines()
assert len(changed) == 7
paths = sorted(set([e['path'] for e in old['files']] + changed))
snapshot = tmp / f'{prefix}-review-r89-source'
snapshot.mkdir(exist_ok=False)
files, diff = [], []
normal = lambda b: b.decode('utf-8').replace('\r\n', '\n')
for rel in paths:
    raw, before = (root / rel).read_bytes(), (baseline / rel).read_bytes()
    assert (normal(raw) != normal(before)) == (rel in changed), rel
    if rel in changed:
        diff.extend(difflib.unified_diff(normal(before).splitlines(True), normal(raw).splitlines(True), fromfile='r88/' + rel, tofile='r89/' + rel))
    target = snapshot / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    files.append(dict(path=rel, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), changed=rel in changed))
diff_path = tmp / f'{prefix}-review-r89.diff'
with diff_path.open('x', encoding='utf-8') as f: f.write(''.join(diff))
manifest = dict(head=head, branch=branch, snapshot=str(snapshot), baseline=str(baseline), files=files, changed=changed,
    diffSha256=hashlib.sha256(diff_path.read_bytes()).hexdigest(), recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Read-only Ordinary protected checkout progress: absent or fully typed partial/complete journal under exact B/C Staging, family, union, protection and future C10 budget. Finalizable still rejects absent/partial. Extended SQL recipe. ROOT fixes fresh private fixture inherited-receipt witness and splits allocation phase timing into four. No physical checkout recovery driver added.',
    execution='SOURCE ONLY review. r88 terminal failure at setup receipt witness, before fresh driver. No runtime/build/SQL/fixture opens or source mutations authorized to reviewer. ROOT owns compilation and later qualification.',
    limits=['SQL DATA confers no filesystem authority.', 'No physical partial-checkout recovery, crash, OS close failure or time bound qualified.'])
path = tmp / f'{prefix}-review-r89-inputs.json'
with path.open('x', encoding='utf-8') as f: json.dump(manifest, f, indent=2)
print(json.dumps(dict(manifest=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), files=len(files), changed=len(changed), diffSha256=manifest['diffSha256'])))
