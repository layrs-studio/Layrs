from pathlib import Path
import datetime, hashlib, io, json, tarfile
root, tmp = Path('D:/Layrs/layrs'), Path('D:/Layrs/tmp')
prefix = 'provider-ordinary-checkout-progress'
manifest_path = tmp / f'{prefix}-review-r89-inputs.json'
report_path = tmp / f'{prefix}-critical-review-r89.json'
manifest, report = [json.loads(p.read_bytes()) for p in [manifest_path, report_path]]
assert not report['findings']
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
entries = {}
for e in manifest['files']:
    p = Path(manifest['snapshot']) / e['path']
    assert pin(p) == dict(bytes=e['bytes'], sha256=e['sha256'])
    entries['source/' + e['path']] = p
for e in report['inputs']['additional_dependencies']:
    p = Path(e['path'])
    assert pin(p) == {k:e['end'][k] for k in ['bytes','sha256']}
    entries['source/' + p.relative_to(root).as_posix()] = p
for p in [manifest_path, report_path, tmp / f'{prefix}-review-r89.diff', tmp / 'prepare-ordinary-checkout-progress-review-r89.py', Path(__file__)]:
    entries['review/' + p.name] = p
record = dict(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='SOURCE ONLY critical review r89; no runtime qualification. ROOT r90 build/check recorded separately.',
    files=[dict(path=n, **pin(p)) for n,p in sorted(entries.items())])
dest = root / 'docs/continuation/worktrees-partial-vfs'
archive = dest / 'ordinary-checkout-progress-source-review-20261028-r89.tar.gz'
inventory = dest / 'ordinary-checkout-progress-source-review-inventory-20261028-r89.json'
assert not archive.exists() and not inventory.exists()
data = json.dumps(record,indent=2).encode('utf-8')
with tarfile.open(archive,'x:gz') as tar:
    info = tarfile.TarInfo('manifest.json'); info.size = len(data)
    tar.addfile(info,io.BytesIO(data))
    for n,p in sorted(entries.items()): tar.add(p,arcname=n,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers()) == len(entries)+1
    for e in record['files']:
        data = tar.extractfile(e['path']).read()
        assert len(data) == e['bytes'] and hashlib.sha256(data).hexdigest() == e['sha256']
record['archive'] = dict(path=archive.name,**pin(archive))
with inventory.open('x',encoding='utf-8') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(archive=str(archive),files=len(entries)+1,**pin(archive))))
