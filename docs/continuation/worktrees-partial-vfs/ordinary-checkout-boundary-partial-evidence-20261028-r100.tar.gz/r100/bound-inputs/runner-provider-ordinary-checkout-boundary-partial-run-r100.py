from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time

assert sys.argv[1:] == ['r100']
out = Path('D:/Layrs/layrs/.layrs-local/validation/provider-ordinary-checkout-boundary-partial-20261028-r100')
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
host = read(out / 'host-disposition.json')
release = read(out / 'ordinary-checkout-boundary-partial-source-release.json')
assert release['decision'] == 'released'
assert sha(Path(__file__)) == release['input_bindings']['runner']['sha256']
exe = Path(host['executable']['path'])
assert sha(exe) == host['executable']['sha256']
for entry in host['sourceClosure']:
    relative = Path(entry['path']).relative_to(Path('D:/Layrs/layrs'))
    assert sha(out / 'source' / relative) == entry['sha256'], str(relative)
parent = Path('C:/Users/ALEXA/AppData/Local/Temp/layrs-provider-ordinary-checkout-boundary-partial-r100')
parent.mkdir(exist_ok=False)
env = os.environ.copy()
env['LAYRS_PROVIDER_SQLITE_TEST_HOST'] = 'audited-layrs-test-host-v1'
report = dict(executable=host['executable'], sourceRelease=release,
              startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              fixtureParent=str(parent), inheritedRustMinStack=env.get('RUST_MIN_STACK'), results=[])
report_path = out / 'ordinary-checkout-boundary-partial-results.json'
with report_path.open('x', encoding='utf-8') as f:
    json.dump(report, f, indent=2)
for index, recipe in enumerate(release['recipes']):
    name = recipe['name']
    assert name.startswith('projection::') and recipe['outer_seconds'] <= 3660
    fixture = parent / f'recipe-{index+1:02d}'
    fixture.mkdir(exist_ok=False)
    env.update(LAYRS_VFS_TEST_PARENT=str(fixture), TEMP=str(fixture), TMP=str(fixture))
    args = [str(exe), '--exact', name, '--nocapture', '--test-threads=1']
    if recipe['ignored']:
        args.append('--ignored')
    path = out / (name.rsplit('::', 1)[1] + '.log')
    print('START', name, flush=True)
    started = time.monotonic()
    timeout_cleanup = None
    with path.open('xb') as log:
        process = subprocess.Popen(args, env=env, stdout=log, stderr=subprocess.STDOUT,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            code = process.wait(timeout=recipe['outer_seconds'])
        except subprocess.TimeoutExpired:
            stopped = subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                                     capture_output=True, timeout=30,
                                     creationflags=subprocess.CREATE_NO_WINDOW)
            timeout_cleanup = dict(pid=process.pid, taskkill=stopped.returncode,
                                   output=stopped.stdout.decode(errors='replace'),
                                   reaped=process.wait(timeout=30))
            code = 'outer process timeout'
    elapsed = round(time.monotonic() - started, 3)
    if code == 0 and 'test result: ok. 1 passed;' not in path.read_text(encoding='utf-8'):
        code = 'expected exact test did not run'
    report['results'].append(dict(test=name, exit=code, seconds=elapsed,
                                 fixtureParent=str(fixture), timeoutCleanup=timeout_cleanup))
    report_path.write_text(json.dumps(report, indent=2), encoding='utf-8')
    print('END', name, code, elapsed, flush=True)
    if code != 0:
        raise SystemExit(1)
