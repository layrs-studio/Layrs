"""Retain only after r98 terminal PASS and r99 build/check; no runtime here."""
from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, sys

assert sys.argv[1:] == ['--root-accept-source-review']
root, tmp = Path('D:/Layrs/layrs'), Path('D:/Layrs/tmp')
prior = root/'.layrs-local/validation/provider-ordinary-checkout-late-20261028-r98'
out = root/'.layrs-local/validation/provider-ordinary-checkout-boundary-partial-20261028-r100'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pin = lambda p: dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))
manifest_path = tmp/'ordinary-checkout-boundary-partial-source/manifest.json'
assert sha(manifest_path) == 'fe1c0755b1252e8279a909147bbd00f08b4b73296bda9625ccc4224d0a097f79'
manifest = read(manifest_path)
review_path = tmp/'provider-ordinary-checkout-boundary-partial-source-review.json'
review = read(review_path)
assert review['findings'] == [] and len(review['files']) == 5
for e in review['files']:
    assert e['beginning'] == e['end']
    assert sha(root/e['path']) == e['end']['sha256']
expected = {e['path']:e for e in manifest['files']}
for e in expected.values():
    assert sha(root/e['path']) == sha(manifest_path.parent/'source'/e['path']) == e['sha256']
previous = read(prior/'ordinary-checkout-late-results.json')
assert len(previous['results']) == 5 and all(r['exit'] == 0 for r in previous['results'])
oldhost = read(prior/'host-disposition.json')
changed = set()
oldpaths = set()
for e in oldhost['sourceClosure']:
    p = Path(e['path']); rel = p.relative_to(root).as_posix(); oldpaths.add(rel)
    assert sha(prior/'source'/rel) == e['sha256']
    if sha(p) != e['sha256']: changed.add(rel)
new = set(expected) - oldpaths
assert new == {'crates/layrs-store-local/src/projection/provider/managed_export/checkout_copy_probe.rs'}
assert changed == set(expected)-new
build_report = tmp/'provider-ordinary-checkout-boundary-partial-build-results-r99.json'
build = read(build_report)
assert [e['name'] for e in build['results']] == ['build', 'check']
for e in build['results']:
    assert e['exit'] == 0 and sha(Path(e['log'])) == e['sha256']
    log = Path(e['log']).read_text(encoding='utf-8')
    assert 'Finished `' in log and 'error[' not in log
prior_archive = root/'docs/continuation/worktrees-partial-vfs/ordinary-checkout-late-evidence-20261028-r98.tar.gz'
assert prior_archive.is_file()
audit = tmp/'provider-ordinary-checkout-boundary-partial-host-audit-r100.py'
text = (tmp/'provider-ordinary-checkout-late-host-audit-r98.py').read_text(encoding='utf-8')
text = text.replace('r98', 'r100').replace('provider-ordinary-checkout-late', 'provider-ordinary-checkout-boundary-partial')
text = text.replace('Five appended late checkout and allocation-gap recipes from r95 review, corrected R95-F1/F2 by ROOT r96. Product and r94 recipes byte-identical. Build/check r97 PASS; new recipe runtime pending.',
    'Five-file independently reviewed test-only delta: C10 T-1/T SQL fixture and actual partial-write checkout recovery. Production cfg(not(test)) behavior unchanged. Build/check r99 PASS; runtime pending.')
text = text.replace('after critical review;', 'after ROOT source acceptance and independent test-delta review;')
with audit.open('x', encoding='utf-8') as f: f.write(text)
subprocess.run(['py', str(audit), 'r100'], check=True)
host = read(out/'host-disposition.json')
assert len(host['sourceClosure']) == 673
assert {Path(e['path']).relative_to(root).as_posix() for e in host['sourceClosure']} == oldpaths|new
for e in host['sourceClosure']:
    p = Path(e['path'])
    assert sha(p) == sha(out/'source'/p.relative_to(root)) == e['sha256']
runner = tmp/'provider-ordinary-checkout-boundary-partial-run-r100.py'
text = (tmp/'provider-ordinary-checkout-late-run-r98.py').read_text(encoding='utf-8')
text = text.replace('r98', 'r100').replace('provider-ordinary-checkout-late', 'provider-ordinary-checkout-boundary-partial').replace('ordinary-checkout-late', 'ordinary-checkout-boundary-partial')
with runner.open('x', encoding='utf-8') as f: f.write(text)
prefix = 'projection::provider::destination_ready::ordinary_tests::'
sql = [
    'ordinary_checkout_progress_isolates_future_c10_metadata_floor_at_one_byte_boundary',
    'ordinary_ready_writer_preserves_restore_history_replays_readonly_and_refuses_corruption',
    'ordinary_family_publication_authenticates_actual_ready_changes_one_row_and_replays_readonly',
    'ordinary_source_publication_partitions_receipts_fences_ready_and_replays_historical_published',
    'ordinary_autonomy_keeps_uncopied_selected_base_and_current_representations_through_admission10',
]
recipes = [dict(name=prefix+n, ignored=True, outer_seconds=180, scope='New boundary or existing SQL caller of changed pure fixture preparation; no physical-transfer evidence.') for n in sql]
recipes.append(dict(name='projection::provider::bootstrap::preparation::activation::session::managed_ordinary_fresh_checkout_tests::managed_ordinary_fresh_checkout_partial_write_retains_owned_inode_and_restarts_copy', ignored=True, outer_seconds=3660, scope='Actual prefix write and injected typed I/O error, durable Owned inode, zero-writer fresh open, rewrite and same-inode publication, complete replay.'))
bindings = dict(runner=pin(runner), host_audit=pin(audit), release_script=pin(Path(__file__)),
    manifest=pin(manifest_path), review=pin(review_path), patch=pin(Path(manifest['patch']['path'])),
    build_report=pin(build_report), build=pin(Path(build['results'][0]['log'])), workspace_check=pin(Path(build['results'][1]['log'])),
    prior_results=pin(prior/'ordinary-checkout-late-results.json'), prior_release=pin(prior/'ordinary-checkout-late-source-release.json'), prior_archive=pin(prior_archive))
saved = out/'bound-inputs'; saved.mkdir(exist_ok=False)
for name, e in bindings.items(): shutil.copyfile(e['path'], saved/(name+'-'+Path(e['path']).name))
release = dict(decision='released', revision='r100', recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip(), artifact_audit=host['executable'],
    reviewer='Independent change-verifier test-only source review; ROOT integrated acceptance. Existing production-boundary critical reviews retained, not broadened.',
    source_review='All673 inputs retained and matched; exact five-file reviewed delta from r98, four old files plus new cfg(test) module. Build/check r99 PASS. Runtime pending.',
    reused_evidence='r91 Ready7PASS, r94 checkout5PASS and r98 late checkout5PASS retained. No unchanged native reruns.',
    limitations=['Single small file and injected typed I/O error after a real prefix write; no native disk/close failure, crash, owner-loss or arbitrary cancellation qualification.',
        'SQL cases are DATA-only and do not exercise the native planner or physical transfer.',
        'Proposed native child3600/outer3660 and SQL child120/outer180 bounds unmeasured for new cases.',
        'No C13 or full L0-L9 completion claim.'], recipes=recipes, input_bindings=bindings)
path = out/'ordinary-checkout-boundary-partial-source-release.json'
with path.open('x', encoding='utf-8') as f: json.dump(release, f, indent=2)
print(json.dumps(dict(release=pin(path), source_inputs=673, changed_files=5, recipes=len(recipes))))
