from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time

revision = sys.argv[1]
assert revision == 'r34'
out = Path('D:/Layrs/layrs/.layrs-local/validation/provider-family-publication-20261027-' + revision)
host = json.loads((out / 'host-disposition.json').read_text())
exe = Path(host['executable']['path'])
assert hashlib.sha256(exe.read_bytes()).hexdigest() == host['executable']['sha256']
release = json.loads((out / 'ordinary-staging-source-release.json').read_text(encoding='utf-8-sig'))
assert release['decision'] == 'released' and release['reviewed_paths'] and release['recipes']
for record in release['reviewed_paths']:
    assert hashlib.sha256((out / 'source' / record['path']).read_bytes()).hexdigest() == record['sha256'].lower(), record['path']
parent = Path('C:/Users/ALEXA/AppData/Local/Temp/layrs-provider-ordinary-staging-' + revision)
parent.mkdir(exist_ok=False)
env = os.environ.copy()
env.update(LAYRS_PROVIDER_SQLITE_TEST_HOST='audited-layrs-test-host-v1',
           LAYRS_VFS_TEST_PARENT=str(parent), TEMP=str(parent), TMP=str(parent))
report = dict(executable=host['executable']['sha256'], sourceRelease=release,
              fixtureParent=str(parent), startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              scope='Complete immutable planning envelope and preallocation capacity; ordinary source/destination Staging DATA and physical phase-gap replay. No C reservation/content installation, Ready/Published, C admission, OS close failure or crash recovery.', results=[])
report_path = out / 'ordinary-staging-results.json'
assert not report_path.exists()
report_path.write_text(json.dumps(report, indent=2))
for index, recipe in enumerate(release['recipes']):
    name = recipe['name']
    assert name.startswith('projection::') and recipe['outer_seconds'] <= 1560
    path = out / (name.rsplit('::', 1)[1] + '.log')
    fixture = parent / f'recipe-{index + 1:02d}'
    fixture.mkdir(exist_ok=False)
    env.update(LAYRS_VFS_TEST_PARENT=str(fixture), TEMP=str(fixture), TMP=str(fixture))
    args = [str(exe), '--exact', name, '--nocapture', '--test-threads=1']
    if recipe['ignored']:
        args.append('--ignored')
    print('START', name, flush=True)
    started = time.monotonic()
    with path.open('xb') as log:
        try:
            result = subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT,
                                    creationflags=subprocess.CREATE_NO_WINDOW,
                                    timeout=recipe['outer_seconds'])
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = 'owned process timeout'
    elapsed = round(time.monotonic() - started, 3)
    if code == 0 and 'test result: ok. 1 passed;' not in path.read_text():
        code = 'expected exact test did not run'
    report['results'].append(dict(test=name, exit=code, seconds=elapsed, fixtureParent=str(fixture)))
    report_path.write_text(json.dumps(report, indent=2))
    print('END', name, code, elapsed, flush=True)
    if code != 0:
        raise SystemExit(1)
