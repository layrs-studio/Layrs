from pathlib import Path
import datetime,difflib,hashlib,json,re,shutil,subprocess,sys
assert sys.argv[1:] == ['--root-accept-diagnostic']
root=Path('D:/Layrs/layrs'); tmp=Path('D:/Layrs/tmp')
prior=root/'.layrs-local/validation/provider-ordinary-fresh-staging-20261028-r72'
out=root/'.layrs-local/validation/provider-ordinary-staging-diagnostic-20261028-r77'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pin=lambda p:dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
reviews=[('ready-quiescence','r73','72cbc76bdd2733ba3bc68ca4a6eea2a1eaf319dee4aad231834f09a527c6570a'),('source10-export','r74','a1c6e84506eca97916dc4115d14713d205b6cfd4ecce53e4733a1e6641dc5fef')]
changed=set();reviewed={};bindings={}
for topic,rev,digest in reviews:
    mp=tmp/f'provider-ordinary-{topic}-review-{rev}-inputs.json'
    rp=tmp/f'provider-ordinary-{topic}-critical-review-{rev}.json'
    dp=tmp/f'provider-ordinary-{topic}-review-{rev}.diff'
    assert sha(mp)==digest
    m=read(mp);r=read(rp)
    assert r['findings']==[] and sha(dp)==m['diffSha256']
    if rev=='r73': assert r['integrity']['beginning_and_end_match']
    else: assert r['integrity']['beginning'].startswith('PASS:') and r['integrity']['end'].startswith('PASS:')
    for e in m['files']:
        assert sha(root/e['path'])==e['sha256']
        reviewed[e['path']]=e
    changed.update(m['changed'])
    bindings.update({f'manifest{rev}':pin(mp),f'review{rev}':pin(rp),f'diff{rev}':pin(dp)})
provider='crates/layrs-store-local/src/projection/provider/'
diagnostic=[provider+'managed_export/staging_reopen.rs',provider+'bootstrap/preparation/activation/session/managed_ordinary_fresh_staging_tests.rs']
for path in diagnostic:
    old=(prior/'source'/path).read_text(encoding='utf-8')
    new=(root/path).read_text(encoding='utf-8')
    if path.endswith('staging_reopen.rs'):
        stripped=re.sub(r'        #\[cfg\(test\)\]\n        trace_stage\("[^"]+"\);\n','',new)
        helper='#[cfg(test)]\n#[inline(never)]\nfn trace_stage(stage: &str) {\n    eprintln!("ORDINARY_STAGING_PHASE={stage}");\n}\n\n'
        assert helper in stripped
        stripped=stripped.replace(helper,'')
    else:
        stripped=re.sub(r'        eprintln!\("STAGING_RECIPE_PHASE=[^"]+"\);\n','',new)
    assert stripped==old, 'diagnostic must only add phase traces: '+path
changed.update(diagnostic)
head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()
assert head=='e2a1ac460fb422b46b784796ce00f521443f6695'
results=read(prior/'ordinary-fresh-staging-results.json')['results']
assert [x['exit'] for x in results]==[0,0,0,0,0,101]
build=tmp/'provider-ordinary-staging-diagnostic-build-r76.log'
check=tmp/'provider-ordinary-staging-diagnostic-check-r76.log'
for path in [build,check]:
    raw=path.read_bytes();text=raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert 'Finished `' in text and 'error[' not in text
audit=tmp/'provider-ordinary-staging-diagnostic-host-audit-r77.py'
text=(tmp/'provider-ordinary-fresh-staging-host-audit-r72.py').read_text(encoding='utf-8').replace('r72','r77').replace('provider-ordinary-fresh-staging','provider-ordinary-staging-diagnostic')
text=text.replace('Fresh B Exclusive and C Shared, actual Ordinary Staging-to-Ready with independently rehashed B image and exact fixed funding; strict close failure-stop and separate Ready handoff.', 'Diagnostic build after retained r72 stack overflow, with test-only phase traces, separately reviewed Ready quiescence guard and compiled but unexecuted source10 recipe.')
with audit.open('x',encoding='utf-8') as f:f.write(text)
subprocess.run(['py',str(audit),'r77'],check=True)
host=read(out/'host-disposition.json');assert len(host['sourceClosure'])==662
actual_changed=[];diff=[]
for e in host['sourceClosure']:
    rel=Path(e['path']).relative_to(root)
    assert sha(root/rel)==e['sha256']==sha(out/'source'/rel)
    old=(prior/'source'/rel).read_text(encoding='utf-8') if (prior/'source'/rel).is_file() else ''
    new=(out/'source'/rel).read_text(encoding='utf-8')
    if old!=new:
        actual_changed.append(rel.as_posix())
        diff.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='r72/'+rel.as_posix(),tofile='r77/'+rel.as_posix()))
assert set(actual_changed)==changed,actual_changed
dp=out/'changes-r72-r77.diff'
with dp.open('x',encoding='utf-8') as f:f.write(''.join(diff))
runner=tmp/'provider-ordinary-staging-diagnostic-run-r77.py'
text=(tmp/'provider-ordinary-fresh-staging-run-r72.py').read_text(encoding='utf-8').replace('r72','r77').replace('ordinary-fresh-staging','ordinary-staging-diagnostic')
text=text.replace('fixtureParent=str(parent), results=[]','fixtureParent=str(parent), inheritedRustMinStack=env.get(\'RUST_MIN_STACK\'), results=[]')
with runner.open('x',encoding='utf-8') as f:f.write(text)
recipes=[dict(name='projection::provider::destination_ready::ordinary_tests::ordinary_source_publication_partitions_receipts_fences_ready_and_replays_historical_published',ignored=True,child_seconds=120,outer_seconds=180,scope='r73 operational pending refusals, unchanged exact SQL dumps, existing restore-history and historicalPublished replay positives.'),dict(name='projection::provider::bootstrap::preparation::activation::session::managed_ordinary_fresh_staging_tests::managed_ordinary_fresh_staging_refuses_changed_b_image_then_promotes_exact_ready_after_all_holders_release',ignored=True,child_seconds=3600,outer_seconds=3660,scope='Same first Staging native scenario, fresh independent fixture, test-only markers to locate retained r72 stack overflow. Stack limit unchanged; no claimed fix.')]
bindings.update({k:pin(p) for k,p in dict(runner=runner,host_audit=audit,release_script=Path(__file__),build=build,workspace_check=check,diff=dp,prior_release=prior/'ordinary-fresh-staging-source-release.json',prior_results=prior/'ordinary-fresh-staging-results.json',prior_failure=prior/'managed_ordinary_fresh_staging_refuses_changed_b_image_then_promotes_exact_ready_after_all_holders_release.log',offline_frames=tmp/'ordinary-r72-stack-frames.json',offline_parser=tmp/'inspect-r72-stack-frames.py').items()})
saved=out/'bound-inputs';saved.mkdir(exist_ok=False)
for name,e in bindings.items():shutil.copyfile(e['path'],saved/(name+'-'+Path(e['path']).name))
release=dict(decision='released',revision='r77',purpose='Bounded SQL regression and stack-overflow phase diagnosis only, not a claim that the native failure is corrected.',recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_head=head,artifact_audit=host['executable'],reviewed_paths=list(reviewed.values()),source_review='Independent r73/r74 reviews read completely; every frozen live hash matches. ROOT-only diagnostic additions mechanically stripped back to exact r72 source. All 662 retained/live build inputs match; exact nine-path delta.',limitations=['r72 five regressions passed, first native failed0xc00000fd after642.474s; second native never executed. Failed fixture retained and never reopened.','No change to RUST_MIN_STACK or normal stack limits; phase traces may identify a failing region but do not establish root cause or a fix.','r74 source10 recipe is compiled but excluded from execution here.','Actual close failure/crash/owner loss and full programme remain unqualified.'],recipes=recipes,input_bindings=bindings)
path=out/'ordinary-staging-diagnostic-source-release.json'
with path.open('x',encoding='utf-8') as f:json.dump(release,f,indent=2)
print(json.dumps(dict(release=pin(path),changed=len(actual_changed),recipes=len(recipes))))
