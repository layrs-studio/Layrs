from pathlib import Path
import re,json
p=Path('D:/Layrs/tmp/ordinary-r72-unwind.txt')
header=re.compile(r'^  [0-9A-F]{8} ([0-9A-F]{8}) ([0-9A-F]{8}) ([0-9A-F]{8})(?:\s+(.*))?$')
rows=[];current=None
with p.open(encoding='utf-16') as f:
    for line in f:
        m=header.match(line.rstrip())
        if m:
            if current: rows.append(current)
            current=dict(rva=m[1],end=m[2],name=m[4] or '',stack=0)
        elif current:
            alloc=re.search(r'ALLOC_(?:LARGE|SMALL), size=0x([0-9A-Fa-f]+)',line)
            if alloc: current['stack']+=int(alloc[1],16)
            if 'PUSH_NONVOL' in line: current['stack']+=8
    if current: rows.append(current)
interesting=[r for r in rows if any(s in r['name'] for s in ['fresh_staging','staging_reopen','source_publication_inner','close_at_family_ready'])]
summary=dict(parsed=len(rows),interesting=sorted(interesting,key=lambda r:r['stack'],reverse=True)[:35],largest=sorted(rows,key=lambda r:r['stack'],reverse=True)[:12])
Path('D:/Layrs/tmp/ordinary-r72-stack-frames.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary))
