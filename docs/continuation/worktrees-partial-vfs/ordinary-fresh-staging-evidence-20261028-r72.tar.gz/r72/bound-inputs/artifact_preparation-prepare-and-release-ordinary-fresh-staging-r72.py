from pathlib import Path
import datetime, difflib, hashlib, json, shutil, subprocess, sys

assert sys.argv[1:] == ['--root-accept-source-review']
root = Path('D:/Layrs/layrs')
tmp = Path('D:/Layrs/tmp')
out = root/'.layrs-local/validation/provider-ordinary-fresh-staging-20261028-r72'
prior = root/'.layrs-local/validation/provider-ordinary-fresh-publication-20261028-r69'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pin = lambda p: dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))
manifest_path = tmp/'provider-ordinary-fresh-staging-review-r70-inputs.json'
review_path = tmp/'provider-ordinary-fresh-staging-critical-review-r70.json'
manifest = read(manifest_path)
review = read(review_path)
assert sha(manifest_path) == '985ff127c0a1fb4d9931b7442e2f56d72f3cff29e9f615401e2a3d5a1282133b'
assert review['findings'] == [] and review['mode'] == 'SOURCE ONLY'
assert review['integrity']['status'] == 'passed_beginning_and_end'
assert review['integrity']['manifest']['sha256'] == sha(manifest_path)
diff_path = tmp/'provider-ordinary-fresh-staging-review-r70.diff'
assert sha(diff_path) == manifest['diffSha256'] == 'c8ce7873ac05dae2c60d5fab84d36e1f7cef2ede39a425d778fcf7492687e937'
head = subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()
assert head == manifest['head'] == review['integrity']['end_head']
for e in manifest['files']:
    assert sha(root/e['path']) == e['sha256']
for e in review['integrity']['supplemental_source_reads']:
    assert sha(root/e['path']) == e['sha256']
build = tmp/'provider-ordinary-fresh-staging-build-r71.log'
check = tmp/'provider-ordinary-fresh-staging-check-r71.log'
for p in [build, check]:
    raw = p.read_bytes()
    text = raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert 'Finished `' in text and 'error[' not in text
assert [r['exit'] for r in read(prior/'ordinary-fresh-publication-results.json')['results']] == [0]*5
audit = tmp/'provider-ordinary-fresh-staging-host-audit-r72.py'
text = (tmp/'provider-ordinary-fresh-publication-host-audit-r69.py').read_text(encoding='utf-8')
text = text.replace('r69','r72').replace('provider-ordinary-fresh-publication','provider-ordinary-fresh-staging')
text = text.replace('Fresh B Exclusive then C Shared, actual Ordinary Ready-to-Published, strict nested failure-stop, positive source close and writer-free actual Published replay/resolution.', 'Fresh B Exclusive and C Shared, actual Ordinary Staging-to-Ready with independently rehashed B image and exact fixed funding; strict close failure-stop and separate Ready handoff.')
with audit.open('x', encoding='utf-8') as f: f.write(text)
subprocess.run(['py',str(audit),'r72'],check=True)
host = read(out/'host-disposition.json')
assert len(host['sourceClosure']) == 661
for e in [host['executable'],host['pdb']]: assert pin(Path(e['path'])) == e
changed, diffs = [], []
for e in host['sourceClosure']:
    rel = Path(e['path']).relative_to(root)
    assert sha(root/rel) == e['sha256'] == sha(out/'source'/rel)
    old = (prior/'source'/rel).read_bytes().replace(b'\r\n', b'\n') if (prior/'source'/rel).exists() else b''
    new = (out/'source'/rel).read_bytes().replace(b'\r\n', b'\n')
    if old != new:
        changed.append(rel.as_posix())
        diffs.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='r69/'+rel.as_posix(),tofile='r72/'+rel.as_posix()))
assert set(changed) == set(manifest['changed']), changed
diff = out/'changes-r69-r72.diff'
with diff.open('x',encoding='utf-8') as f: f.write(''.join(diffs))
runner = tmp/'provider-ordinary-fresh-staging-run-r72.py'
text = (tmp/'provider-ordinary-fresh-publication-run-r69.py').read_text(encoding='utf-8')
text = text.replace('r69','r72').replace('ordinary-fresh-publication','ordinary-fresh-staging')
with runner.open('x',encoding='utf-8') as f: f.write(text)
scan = 'projection::capture::scan::tests::'
native = 'projection::provider::bootstrap::preparation::activation::session::managed_ordinary_fresh_staging_tests::'
recipes = [
    dict(name=scan+'ordinary_scan_hash_without_cancellation_keeps_file_identity_and_length_checks', ignored=False, outer_seconds=60, scope='Pure hash identity and length regression.'),
    dict(name=scan+'cancellation::scan_hash_cancellation_during_read_stops_before_next_chunk_and_covers_eof', ignored=False, outer_seconds=60, scope='Pure cancellation during Read, including EOF.'),
    dict(name=scan+'cancellation::scan_hash_precancellation_refuses_before_reading_any_bytes', ignored=False, outer_seconds=60, scope='Pure pre-cancellation forbids reads.'),
    dict(name='projection::tests::capture::protected_unknown_alias_and_readonly_changes_never_produce_a_capture', ignored=False, outer_seconds=180, scope='Fresh ordinary TEMP fixture; protected/unknown/aliased/read-only capture refusals; fixture destructor only removes its exact owned child.'),
    dict(name='projection::provider::destination_ready::ordinary_tests::ordinary_source_publication_partitions_receipts_fences_ready_and_replays_historical_published', ignored=True, child_seconds=120, outer_seconds=180, scope='Existing source-publication SQL phase, receipt and replay regression.'),
    dict(name=native+'managed_ordinary_fresh_staging_refuses_changed_b_image_then_promotes_exact_ready_after_all_holders_release', ignored=True, child_seconds=3600, outer_seconds=3660, scope='Released original holders; real B image drift refusal before writer, restored exact bytes, fresh Ready commit/close/readback with all pins retained.'),
    dict(name=native+'managed_ordinary_fresh_staging_withheld_b_close_ack_reopens_actual_ready_after_explicit_holder_release', ignored=True, child_seconds=3600, outer_seconds=3660, scope='Withheld ACK after successful physical close; zero postfailure probes and original cause; explicit holder drop then separate Ready adapter open without publishing.')]
bindings = {name:pin(p) for name,p in dict(runner=runner,host_audit=audit,artifact_preparation=Path(__file__),build=build,workspace_check=check,review70=review_path,manifest70=manifest_path,review_diff=diff_path,diff=diff,prior_release=prior/'ordinary-fresh-publication-source-release.json',prior_results=prior/'ordinary-fresh-publication-results.json').items()}
saved = out/'bound-inputs'
saved.mkdir(exist_ok=False)
for name,e in bindings.items(): shutil.copyfile(e['path'],saved/(name+'-'+Path(e['path']).name))
release = dict(decision='released',revision='r72',recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_head=head,
    reviewer='ROOT acceptance after reading completed r70 independent source review. Limited to seven exact recipes.',
    artifact_audit=host['executable'],reviewed_paths=manifest['files'],
    source_review='29 reviewed files and seven supplemental sources match; all 661 retained/live build inputs match. Exactly ten Rust paths changed from r69. Build/check r71 PASS.',
    inherited_evidence='r69 five exact recipes PASS; no transfer of qualification to changed Staging driver or extracted scan/image paths.',
    limitations=['Fresh C parent only; serial children; stop first failure; no old fixture reopening.',
        'Native 3600/3660 bounds are proposed and unmeasured for these recipes.',
        'Clean teardown and withheld ACK after successful physical close are not crash or real close-failure recovery.',
        'One README only; fresh missing/alias/protected/manifest/plan/history/selection/family negatives and positive nested/deletion remain unqualified.',
        'Older Ready-only adapter operational pending/history quiescence is an open source investigation, not established by this lot.',
        'External namespace quiescence remains required. No full-programme or production-host acceptance.'],
    recipes=recipes,input_bindings=bindings)
path = out/'ordinary-fresh-staging-source-release.json'
with path.open('x',encoding='utf-8') as f: json.dump(release,f,indent=2)
print(json.dumps(dict(release=pin(path),recipes=len(recipes),changed=len(changed))))
