from pathlib import Path
import datetime, hashlib, json, sys

assert sys.argv[1:] == ['--root-accept-source-review']
root = Path('D:/Layrs/layrs')
tmp = Path('D:/Layrs/tmp')
out = root / '.layrs-local/validation/provider-ordinary-admission10-20261028-r56'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pin = lambda p: dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))
host = read(out / 'host-disposition.json')
manifest = tmp / 'provider-ordinary-admission10-review-r56-inputs.json'
review = tmp / 'provider-ordinary-admission10-critical-review-r56.json'
assert review.is_file()
inputs = read(manifest)
for entry in inputs['files']:
    assert sha(root / entry['path']) == sha(out / 'source' / entry['path']) == entry['sha256']
for entry in host['sourceClosure']:
    relative = Path(entry['path']).relative_to(root)
    assert sha(root / relative) == sha(out / 'source' / relative) == entry['sha256']
assert sha(Path(host['executable']['path'])) == host['executable']['sha256']
for filename in ['ordinary-admission10-build-r56.log', 'ordinary-admission10-workspace-r56.log']:
    data = (tmp / filename).read_bytes()
    log = data.decode('utf-16' if data.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert 'Finished `' in log and 'error[E' not in log

recipes = []
def add(module, names, kind):
    for name in names.split():
        recipes.append(dict(name='projection::' + module + '::' + name, kind=kind,
                            ignored=kind != 'pure', child_seconds=3600 if kind == 'native' else 120 if kind == 'sql' else None,
                            outer_seconds=3660 if kind == 'native' else 180 if kind == 'sql' else 30))
add('provider::managed_admission::representations::tests', '''
witness_retains_two_representations_of_one_file_and_rejects_lost_or_extra_triples
a_self_consistent_digest_cannot_hide_duplicates_order_or_contradictory_lengths''', 'pure')
add('provider::managed_budget::admission::tests', '''
ordinary_admission_funds_the_exact_bounded_witness_without_growing_quota
ordinary_admission_cost_rejects_missing_extra_or_mischarged_witness
ordinary_admission_metadata_cap_includes_witness_separately_from_family_margin
admission_budget_retains_both_journals_and_full_ack_capacity''', 'pure')
add('provider::managed_admission::tests', '''
admitted_schema_requires_exact_version_ddl_and_matching_origin
admitted_witness_scalar_fence_precedes_admission_body_decoding
admitted_private_history_survives_local_capture_publication_claims_and_operational_stage
admitted_private_history_refuses_ack_archive_and_schema_corruption_without_repair''', 'sql')
add('provider::admitted_ordinary::tests', '''
admitted_capture_origin_dispatch_respects_imported_and_local_generation_intervals''', 'sql')
add('shared::admitted_catalog::terminal_ready_tests', '''
terminal_ready_accepts_complete_family_without_source_context
terminal_ready_rejects_foreign_corruption_and_unclassified_groups
terminal_ready_exact_member_root_and_union_are_mandatory
terminal_ready_known_empty_union_and_unknown_empty_policy''', 'sql')
add('provider::destination_ready::ordinary_tests', '''
ordinary_autonomy_keeps_uncopied_selected_base_and_current_representations_through_admission10''', 'sql')
add('provider::bootstrap::preparation::activation::session::managed_ordinary_admission_tests', '''
managed_ordinary_admission_commits_exact_c10_after_published_and_positive_closes
managed_ordinary_admission_withheld_c_ack_retains_holder_for_sourceless_resolution''', 'native')
bindings = {name: pin(path) for name, path in dict(
    runner=tmp/'provider-ordinary-admission10-run-r56.py',
    host_audit=tmp/'provider-ordinary-admission10-host-audit-r56.py',
    review=review, manifest=manifest,
    build=tmp/'ordinary-admission10-build-r56.log',
    workspace=tmp/'ordinary-admission10-workspace-r56.log',
    release_script=Path(__file__)).items()}
release = dict(decision='released', revision='r56',
               reviewer='ROOT acceptance after independent source review; no runtime result inferred',
               recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               baseline_head=inputs['head'], artifact_audit=host['executable'],
               reviewed_paths=inputs['files'], source_inputs=len(host['sourceClosure']),
               input_bindings=bindings, recipes=recipes,
               limits=['Proposed child120/outer180 SQL and child3600/outer3660 native bounds remain unmeasured.',
                       'Native withheld ACK follows physical close success; no actual OS close/rollback failure, crash or owner loss.',
                       'Historical C10 ancestor regression uses declared future receipt DATA; no live D admission or physical D->E chain.',
                       'Retained C owner resolution only. Product reopening and broader lifecycle remain unfinished.'])
saved = out / 'bound-inputs'
saved.mkdir(exist_ok=False)
for name, entry in bindings.items():
    with (saved / (name + '-' + Path(entry['path']).name)).open('xb') as f:
        f.write(Path(entry['path']).read_bytes())
path = out / 'ordinary-admission10-source-release.json'
with path.open('x', encoding='utf-8') as f:
    json.dump(release, f, indent=2)
print(json.dumps(dict(release=pin(path), recipes=len(recipes), sources=len(host['sourceClosure']))))
