from pathlib import Path
import datetime, hashlib, io, json, tarfile

root = Path('D:/Layrs/layrs')
tmp = Path('D:/Layrs/tmp')
prefix = 'provider-ordinary-fresh-private-ready'
manifest_path = tmp / f'{prefix}-review-r85-inputs.json'
report_path = tmp / f'{prefix}-critical-review-r85.json'
manifest = json.loads(manifest_path.read_bytes())
report = json.loads(report_path.read_bytes())
frozen = tmp / f'{prefix}-review-r85-source'
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
assert pin(manifest_path)['sha256'] == 'ed6167d858eec42dda2038e75ed821d43a62071af4266114d82dee5e6a0b3c1f'
assert not report['findings']
assert report['inputs']['identity_at_end']['issues'] == []
entries = {}
for e in manifest['files']:
    expected = {k: e[k] for k in ['bytes', 'sha256']}
    assert pin(frozen / e['path']) == expected, e['path']
    assert pin(root / e['path']) == expected, ('live drift', e['path'])
    entries['reviewed-source/' + e['path']] = frozen / e['path']
for e in report['inputs']['extra_source_dependencies']:
    p = root / e['path']
    assert pin(p)['sha256'] == e['sha256'], e['path']
    entries['reviewed-dependencies/' + e['path']] = p
for name in [f'{prefix}-review-r85-inputs.json', f'{prefix}-review-r85.diff',
             f'{prefix}-critical-review-r85.json', 'prepare-ordinary-fresh-private-ready-review-r85.py']:
    entries['support/' + name] = tmp / name
entries['support/' + Path(__file__).name] = Path(__file__)
record = dict(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='SOURCE ONLY fresh B Staging + complete C Staging -> private C Ready. Independent critical review r85, no actionable source finding. Candidate uncompiled and unexecuted.',
    head=manifest['head'], branch=manifest['branch'],
    limitations=['No runtime, performance, resource, crash or actual close-failure qualification.',
                 'Proposed native ACK loss follows successful SQLite connection close.',
                 'Retained ReadyContext follow-up is outside this review.',
                 'ROOT73332 r84 runtime is separate and does not exercise r85.'],
    files=[dict(path=n, **pin(p)) for n, p in sorted(entries.items())])
dest = root / 'docs/continuation/worktrees-partial-vfs'
archive = dest / 'ordinary-fresh-private-ready-source-review-20261028-r85.tar.gz'
inventory = dest / 'ordinary-fresh-private-ready-source-review-inventory-20261028-r85.json'
assert not archive.exists() and not inventory.exists()
data = json.dumps(record, indent=2).encode('utf-8')
with tarfile.open(archive, 'x:gz') as tar:
    info = tarfile.TarInfo('manifest.json')
    info.size = len(data)
    tar.addfile(info, io.BytesIO(data))
    for n, p in sorted(entries.items()):
        tar.add(p, arcname=n, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(entries) + 1
    for e in record['files']:
        data = tar.extractfile(e['path']).read()
        assert len(data) == e['bytes'] and hashlib.sha256(data).hexdigest() == e['sha256']
record['archive'] = dict(path=archive.name, **pin(archive))
with inventory.open('x', encoding='utf-8') as f:
    json.dump(record, f, indent=2)
print(json.dumps(dict(archive=str(archive), files=len(entries) + 1, **pin(archive))))
