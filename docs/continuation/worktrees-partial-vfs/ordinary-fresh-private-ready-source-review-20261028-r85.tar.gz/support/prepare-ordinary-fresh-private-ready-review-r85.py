from pathlib import Path
import datetime, difflib, hashlib, json, subprocess

root = Path('D:/Layrs/layrs')
tmp = Path('D:/Layrs/tmp')
prior = root / '.layrs-local/validation/provider-ordinary-fresh-family-20261028-r84/source'
p = 'crates/layrs-store-local/src/projection/'
v = p + 'provider/'
s = v + 'bootstrap/preparation/activation/'
changed = [v + x for x in [
    'destination_ready.rs', 'destination_ready/ordinary.rs',
    'destination_ready/ordinary_tests.rs', 'managed_export.rs',
    'managed_export/private_ready_reopen.rs', 'managed_ready_reopen.rs',
    'managed_ready_reopen/ordinary_source.rs',
    'managed_ready_reopen/ordinary_private_ready.rs',
]] + [p + x for x in ['shared.rs', 'shared/content.rs']] + [s + x for x in [
    'session.rs', 'session/managed_ordinary_source_publication_tests.rs',
    'session/managed_ordinary_fresh_private_ready_tests.rs',
]]
old = json.loads((tmp / 'provider-ordinary-fresh-family-review-r82-inputs.json').read_text(encoding='utf-8'))
context = [x['path'] for x in old['files']] + [v + x for x in [
    'ordinary_destination.rs', 'ordinary_destination/checkout.rs',
    'managed_budget.rs', 'checkout_journal.rs',
    'bootstrap/preparation/activation/session/managed_ordinary_ready_tests.rs',
]]
paths = sorted(set(changed + context))
assert len(changed) == 13
for path in paths:
    assert (root / path).is_file(), path
head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD']).decode().strip()
assert head == 'f01f6b9518b71a3cfc309be3a2911c51599f2e79', head
branch = subprocess.check_output(['git', '-C', str(root), 'branch', '--show-current']).decode().strip()
assert branch == 'feature/worktrees-partial-vfs'
snapshot = tmp / 'provider-ordinary-fresh-private-ready-review-r85-source'
snapshot.mkdir(exist_ok=False)
files, diff = [], []
for path in paths:
    raw = (root / path).read_bytes()
    target = snapshot / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    files.append(dict(path=path, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), changed=path in changed))
    baseline = (prior / path).read_bytes() if (prior / path).is_file() else b''
    normal = lambda b: b.decode('utf-8').replace('\r\n', '\n')
    if path in changed:
        assert normal(baseline) != normal(raw), path
        diff.extend(difflib.unified_diff(normal(baseline).splitlines(True), normal(raw).splitlines(True), fromfile='r84/' + path, tofile='r85/' + path))
    else:
        assert normal(baseline) == normal(raw), ('unexpected context change', path)
diff_path = tmp / 'provider-ordinary-fresh-private-ready-review-r85.diff'
with diff_path.open('x', encoding='utf-8') as f:
    f.write(''.join(diff))
manifest = dict(head=head, branch=branch, baseline=str(prior), snapshot=str(snapshot),
    recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(), files=files, changed=changed,
    diffSha256=hashlib.sha256(diff_path.read_bytes()).hexdigest(),
    scope='Fresh unchanged B SourceStaging + complete protected C8 DestinationStaging -> private C Ready only; family Initializing and B Staging unchanged. C Exclusive from initial acquisition, separate actual Staging/Ready SQL branches, exact ManifestId reconstruction, full family validation, strict close/failure order, fresh physical proofs. Two ignored native recipes and extended family SQL recipe.',
    build='Uncompiled, unexecuted candidate. ROOT73332 is executing retained r84 source10/fresh family recipes. No build, SQL, tests, fixture opens or runtime authorized in review.',
    limits=['Native recipes propose SQLite close ACK loss, not actual native xClose/OS close failure.', 'SQL negative journal/manifest recipes are source only.', 'Retained ReadyContext audit is a separately documented follow-up; this review does not qualify it.'])
path = tmp / 'provider-ordinary-fresh-private-ready-review-r85-inputs.json'
with path.open('x', encoding='utf-8') as f:
    json.dump(manifest, f, indent=2)
print(json.dumps(dict(manifest=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), diffSha256=manifest['diffSha256'], files=len(files), changed=len(changed))))
