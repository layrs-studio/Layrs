from pathlib import Path
import datetime, hashlib, json, os, subprocess, time

out = Path('D:/Layrs/layrs/.layrs-local/validation/provider-family-publication-20261027-r22')
host = json.loads((out / 'host-disposition.json').read_text())
exe = Path(host['executable']['path'])
assert hashlib.sha256(exe.read_bytes()).hexdigest() == host['executable']['sha256']
release = json.loads((out / 'restore-cancel-source-release.json').read_text(encoding='utf-8-sig'))
name = 'projection::provider::bootstrap::preparation::activation::session::managed_restore_cancellation_tests::managed_admitted_restore_cancels_prejournal_and_partial_installations_then_retries'
assert release['decision'] == 'released' and release['recipe'] == name
assert release['child_seconds'] == 1200 and release['outer_seconds'] == 1260
assert release['reviewed_paths']
for record in release['reviewed_paths']:
    assert hashlib.sha256((out / 'source' / record['path']).read_bytes()).hexdigest() == record['sha256'].lower(), record['path']
parent = Path('C:/Users/ALEXA/AppData/Local/Temp/layrs-provider-restore-cancel-native-r22')
parent.mkdir(exist_ok=False)
env = os.environ.copy()
env.update(LAYRS_PROVIDER_SQLITE_TEST_HOST='audited-layrs-test-host-v1',
           LAYRS_VFS_TEST_PARENT=str(parent), TEMP=str(parent), TMP=str(parent))
report = dict(executable=host['executable']['sha256'], sourceRelease=release,
              fixtureParent=str(parent), startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              scope='Ten cancellation/retry cases on a genuine admitted destination. Real restore Staged fault plus six production installation-helper fault states under its active restore budget. Seven cancellation interruption points: installations cleared, checkout cleaning marked, checkout file removed, checkout directory removed, staging cleared, private budget committed, family reservation released. Bound/direct cancellation, clean terminal retry, malformed prejournal/wrong reservation/unexpected child/later invalid installation/hardlink refusals without effects, retry restore/inverse, imported provenance and fsck. No process crash, hot journal, source deletion, all-ACL/identity corruption matrix, inherited inverse or GC qualification.', results=[])
report_path = out / 'restore-cancel-native-results.json'
assert not report_path.exists()
report_path.write_text(json.dumps(report, indent=2))
path = out / (name.rsplit('::', 1)[1] + '.log')
started = time.monotonic()
print('START', name, flush=True)
with path.open('xb') as log:
    try:
        result = subprocess.run([str(exe), '--exact', name, '--ignored', '--nocapture', '--test-threads=1'],
                                env=env, stdout=log, stderr=subprocess.STDOUT,
                                creationflags=subprocess.CREATE_NO_WINDOW, timeout=1260)
        code = result.returncode
    except subprocess.TimeoutExpired:
        code = 'owned process timeout'
elapsed = round(time.monotonic() - started, 3)
if code == 0 and 'test result: ok. 1 passed;' not in path.read_text():
    code = 'expected exact test did not run'
report['results'].append(dict(test=name, exit=code, seconds=elapsed))
report_path.write_text(json.dumps(report, indent=2))
print('END', name, code, elapsed, flush=True)
if code != 0:
    raise SystemExit(1)
