from pathlib import Path
import datetime, difflib, hashlib, json, shutil, subprocess

root = Path('D:/Layrs/layrs')
tmp = Path('D:/Layrs/tmp')
prior = root / '.layrs-local/validation/provider-ordinary-admission10-20261028-r57'
out = root / '.layrs-local/validation/provider-ordinary-terminal-20261028-r60'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pin = lambda p: dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))
assert [r['exit'] for r in read(prior/'ordinary-admission10-results.json')['results']] == [0, 0, 0]
build = tmp/'provider-ordinary-terminal-build-r60.log'
check = tmp/'provider-ordinary-terminal-check-r60.log'
for p in [build, check]:
    raw = p.read_bytes()
    text = raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert 'Finished `' in text and 'error[' not in text
manifest_path = tmp/'provider-ordinary-terminal-review-r59-inputs.json'
assert sha(manifest_path) == '516a36965bf189c017b92b828c7fe20d43295da20ea42ccf04f0d97c9da73f93'
manifest = read(manifest_path)
review58 = tmp/'provider-ordinary-terminal-critical-review-r58.json'
review59 = tmp/'provider-ordinary-terminal-correction-review-r59.json'
correction = read(review59)
assert correction['new_findings'] == []
assert correction['r58_f1']['status'] == 'resolved_source_only'
assert correction['integrity']['stable'] and not correction['integrity']['mismatches']
assert sha(review58) == correction['integrity']['prior_report_sha256_begin_and_end']
head = subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()
assert head == manifest['head']
for e in manifest['files']:
    assert sha(root/e['path']) == e['sha256']
    assert sha(tmp/'provider-ordinary-terminal-review-r59-source'/e['path']) == e['sha256']
audit = tmp/'provider-ordinary-terminal-host-audit-r60.py'
text = (tmp/'provider-ordinary-admission10-host-audit-r57.py').read_text(encoding='utf-8')
text = text.replace('r57','r60').replace('provider-ordinary-admission10-20261028-', 'provider-ordinary-terminal-20261028-')
text = text.replace('Ordinary8->10 admission SQL and retained physical handoff.', 'Fresh Ordinary C8/C10 read-only inspection and C10 autonomous public capture/restore; exact SQL terminal suffix fence.')
with audit.open('x',encoding='utf-8') as f: f.write(text)
subprocess.run(['py',str(audit),'r60'],check=True)
host = read(out/'host-disposition.json')
assert len(host['sourceClosure']) == 652
expected = {e['path'] for e in manifest['files']}
sql_test = 'crates/layrs-store-local/src/projection/provider/destination_ready/ordinary_tests.rs'
expected.add(sql_test)
changed = []
diffs = []
for e in host['sourceClosure']:
    relative = Path(e['path']).relative_to(root)
    p = relative.as_posix()
    assert sha(out/'source'/relative) == e['sha256'] == sha(root/relative)
    before = prior/'source'/relative
    old = before.read_bytes().replace(b'\r\n',b'\n') if before.exists() else b''
    new = (out/'source'/relative).read_bytes().replace(b'\r\n',b'\n')
    if old != new:
        changed.append(p)
        diffs.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='r57/'+p,tofile='r60/'+p))
assert set(changed) == expected, changed
diff = out/'changes-r57-r60.diff'
with diff.open('x',encoding='utf-8') as f: f.write(''.join(diffs))
runner = tmp/'provider-ordinary-terminal-run-r60.py'
text = (tmp/'provider-ordinary-admission10-run-r57.py').read_text(encoding='utf-8')
text = text.replace('r57','r60').replace('provider-ordinary-admission10','provider-ordinary-terminal').replace('ordinary-admission10-source-release','ordinary-terminal-source-release').replace('ordinary-admission10-results','ordinary-terminal-results')
with runner.open('x',encoding='utf-8') as f: f.write(text)
recipes = [
    dict(name='projection::provider::destination_ready::ordinary_tests::ordinary_autonomy_keeps_uncopied_selected_base_and_current_representations_through_admission10',ignored=True,child_seconds=120,outer_seconds=180,scope='Existing full C10 SQL plus actual terminal detachment, coherent capture suffix accepted by generic reader and refused without repair by exact terminal inventory.'),
    dict(name='projection::provider::bootstrap::preparation::activation::session::managed_ordinary_autonomy_tests::managed_ordinary_c10_reopens_and_captures_restores_after_all_holders_and_ancestors_release',ignored=True,child_seconds=3600,outer_seconds=3660,scope='Fresh C10 resolution and public capture/restore after holder teardown, with A/B checkout paths moved and B private database denied by Windows handle. Proposed unmeasured bound.')]
bindings = {name:pin(p) for name,p in dict(runner=runner,host_audit=audit,build=build,workspace_check=check,review58=review58,review59=review59,manifest59=manifest_path,diff=diff,prior_release=prior/'ordinary-admission10-source-release.json',prior_results=prior/'ordinary-admission10-results.json',release_script=Path(__file__)).items()}
saved=out/'bound-inputs'
saved.mkdir(exist_ok=False)
for name,e in bindings.items(): shutil.copyfile(e['path'],saved/(name+'-'+Path(e['path']).name))
release=dict(decision='released',revision='r60',recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_head=head,
    reviewer='ROOT acceptance of r58 production review and r59 corrected recipe review; ROOT integrated SQL test reviewed separately.',
    artifact_audit=host['executable'],reviewed_paths=[dict(path=p,bytes=(root/p).stat().st_size,sha256=sha(root/p)) for p in sorted(expected)],
    source_review='Eight sources exactly match frozen r59. ROOT SQL test is ninth changed source; no product delta outside reviewed eight. All 652 inputs retained and matched.',
    inherited_evidence='r56 first15 recipes PASS, r57 corrected SQL and two retained native admission recipes PASS. These are prior revision evidence, not executions of r60.',
    limitations=['No runtime results at release time. This authorizes only the two exact recipes under retained host, fresh disposable C parent, serial stop on first failure.',
      'No actual close/rollback failure, crash or owner-loss recovery qualification. Fresh C8 admission writer is absent and C8 inspection has no native recipe here.',
      'No physical D-to-E chain or general deletion/nested-directory native coverage. Proposed time bounds are not worst-case guarantees.'],
    recipes=recipes,input_bindings=bindings)
path=out/'ordinary-terminal-source-release.json'
with path.open('x',encoding='utf-8') as f: json.dump(release,f,indent=2)
print(json.dumps(dict(release=pin(path),recipes=len(recipes),changed=changed)))
