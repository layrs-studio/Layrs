from pathlib import Path
import datetime, hashlib, json, shutil, sys

assert sys.argv[1:] == ['--root-accept-reviewed-source10']
root = Path('D:/Layrs/layrs')
tmp = Path('D:/Layrs/tmp')
prior = root / '.layrs-local/validation/provider-ordinary-staging-box-20261028-r79'
out = root / '.layrs-local/validation/provider-ordinary-source10-20261028-r81'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pin = lambda p: dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))
host = read(prior / 'host-disposition.json')
results = read(prior / 'ordinary-staging-box-results.json')
assert [r['exit'] for r in results['results']] == [0, 0]
assert len(host['sourceClosure']) == 662
for e in [host['executable'], host['pdb']]:
    assert pin(Path(e['path'])) == e
for e in host['sourceClosure']:
    p = prior / 'source' / Path(e['path']).relative_to(root)
    assert p.stat().st_size == e['bytes'] and sha(p) == e['sha256']
manifest_path = tmp / 'provider-ordinary-source10-export-review-r74-inputs.json'
manifest = read(manifest_path)
review_path = tmp / 'provider-ordinary-source10-export-critical-review-r74.json'
review = read(review_path)
assert not review['findings']
assert review['integrity']['manifest']['sha256'] == sha(manifest_path)
assert review['integrity']['fileCount'] == len(manifest['files']) == 18
for e in manifest['files']:
    p = prior / 'source' / e['path']
    assert p.stat().st_size == e['bytes'] and sha(p) == e['sha256'], e['path']
recipe_name = 'projection::provider::bootstrap::preparation::activation::session::managed_ordinary_source10_export_tests::managed_ordinary_source10_exports_nested_and_deleted_paths_to_d10_then_reopens'
test_path = prior / 'source/crates/layrs-store-local/src/projection/provider/bootstrap/preparation/activation/session/managed_ordinary_source10_export_tests.rs'
source = test_path.read_text(encoding='utf-8')
assert recipe_name.rsplit('::', 1)[1] in source and '5400' in source
out.mkdir(exist_ok=False)
shutil.copytree(prior / 'source', out / 'source')
shutil.copyfile(prior / 'host-disposition.json', out / 'host-disposition.json')
runner = tmp / 'provider-ordinary-source10-run-r81.py'
text = (tmp / 'provider-ordinary-staging-box-run-r79.py').read_text(encoding='utf-8')
text = text.replace('r79', 'r81').replace('ordinary-staging-box', 'ordinary-source10')
text = text.replace("recipe['outer_seconds'] <= 3660", "recipe['outer_seconds'] == 5460 and recipe['child_seconds'] == 5400")
with runner.open('x', encoding='utf-8') as f:
    f.write(text)
bindings = {k: pin(p) for k, p in dict(
    runner=runner, release_script=Path(__file__),
    critical_manifest=manifest_path, critical_review=review_path,
    critical_diff=tmp / 'provider-ordinary-source10-export-review-r74.diff',
    prior_release=prior / 'ordinary-staging-box-source-release.json',
    prior_results=prior / 'ordinary-staging-box-results.json',
    build=tmp / 'provider-ordinary-staging-box-build-r78.log',
    workspace_check=tmp / 'provider-ordinary-staging-box-check-r78.log',
).items()}
saved = out / 'bound-inputs'
saved.mkdir()
for name, e in bindings.items():
    shutil.copyfile(e['path'], saved / (name + '-' + Path(e['path']).name))
release = dict(
    decision='released', revision='r81',
    recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    artifact_audit=host['executable'],
    reviewer='ROOT acceptance of unchanged r74 independently reviewed recipe against retained r79 executable/source closure; no new build or live-source qualification.',
    source_review='All 662 retained source inputs match their compiled audit; all 18 r74 reviewed paths match retained bytes exactly. r78 build/check passed and r79 two Staging natives passed. Current family-publication edits are excluded.',
    limitations=[
        'Prior r80 sandbox attempt refused before fixture creation on pinned C:/Users/ALEXA (os error 5); r81 uses a new disposable parent under required host access. 5400-second child and 5460-second outer bounds are proposed, not measured completion guarantees.',
        'One fresh native chain C10 to D10 with nested addition, positive deletion and public reopens. No D-to-E or ancestor-unavailable D qualification.',
        'No actual OS close failure, rollback failure, crash or owner-loss recovery.',
        'Uses frozen r79 executable and source, not current in-progress family-publication edits. Full programme remains incomplete.'
    ],
    recipes=[dict(name=recipe_name, ignored=True, child_seconds=5400, outer_seconds=5460,
                  scope='Released C10 source, explicitly granted nested addition, positive README deletion, complete export to D10, inherited captures/bytes and fresh public C/D reopens.')],
    input_bindings=bindings,
)
p = out / 'ordinary-source10-source-release.json'
with p.open('x', encoding='utf-8') as f:
    json.dump(release, f, indent=2)
print(json.dumps(dict(release=pin(p), recipes=len(release['recipes']), executable=host['executable'])))
