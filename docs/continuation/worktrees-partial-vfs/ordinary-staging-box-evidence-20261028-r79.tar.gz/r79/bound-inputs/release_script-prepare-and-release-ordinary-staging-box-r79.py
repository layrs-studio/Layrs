from pathlib import Path
import datetime,difflib,hashlib,json,shutil,subprocess,sys
assert sys.argv[1:]==['--root-accept-boxed-data']
root=Path('D:/Layrs/layrs');tmp=Path('D:/Layrs/tmp')
prior=root/'.layrs-local/validation/provider-ordinary-staging-diagnostic-20261028-r77'
out=root/'.layrs-local/validation/provider-ordinary-staging-box-20261028-r79'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pin=lambda p:dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
path=Path('crates/layrs-store-local/src/projection/provider/managed_export/staging_reopen.rs')
old=(prior/'source'/path).read_text(encoding='utf-8');new=(root/path).read_text(encoding='utf-8')
assert new.count('CauseResult<Box<Validated>>')==2
assert new.count('Ok(Box::new(Validated {')==1
comment='    // Carry owned DATA through the nested reader/close results by pointer.\n    // Keeping the complete records inline duplicates large return slots in\n    // each debug reader frame. Proof borrows remain inside validate\'s scopes;\n    // all three positive closes still precede returning this owned value.\n'
assert comment in new
stripped=new.replace(comment,'').replace('CauseResult<Box<Validated>>','CauseResult<Validated>').replace('Ok(Box::new(Validated {','Ok(Validated {').replace('            capacity,\n        }))','            capacity,\n        })')
assert stripped==old,'only boxed owned DATA return representation may change'
prior_result=read(prior/'ordinary-staging-diagnostic-results.json')
assert [r['exit'] for r in prior_result['results']]==[0,101]
failure=prior/'managed_ordinary_fresh_staging_refuses_changed_b_image_then_promotes_exact_ready_after_all_holders_release.log'
log=failure.read_text(encoding='utf-8')
assert 'ORDINARY_STAGING_PHASE=validate/observation' in log and 'has overflowed its stack' in log
assert 'ORDINARY_STAGING_PHASE=open/complete' not in log
build=tmp/'provider-ordinary-staging-box-build-r78.log';check=tmp/'provider-ordinary-staging-box-check-r78.log'
for p in [build,check]:
    raw=p.read_bytes();text=raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert 'Finished `' in text and 'error[' not in text
head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()
assert head=='8dbeba239a7bf08abc0cf9430ccf6621582c9cbb'
audit=tmp/'provider-ordinary-staging-box-host-audit-r79.py'
text=(tmp/'provider-ordinary-staging-diagnostic-host-audit-r77.py').read_text(encoding='utf-8').replace('r77','r79').replace('provider-ordinary-staging-diagnostic','provider-ordinary-staging-box')
text=text.replace('Diagnostic build after retained r72 stack overflow, with test-only phase traces, separately reviewed Ready quiescence guard and compiled but unexecuted source10 recipe.', 'One-file private Box<Validated> return representation after r77 confirmed overflow at nested validated read. Same protocol and phase traces; native qualification pending.')
with audit.open('x',encoding='utf-8') as f:f.write(text)
subprocess.run(['py',str(audit),'r79'],check=True)
host=read(out/'host-disposition.json');assert len(host['sourceClosure'])==662
changes=[]
for e in host['sourceClosure']:
    rel=Path(e['path']).relative_to(root)
    assert sha(root/rel)==e['sha256']==sha(out/'source'/rel)
    if (out/'source'/rel).read_text(encoding='utf-8')!=(prior/'source'/rel).read_text(encoding='utf-8'):changes.append(rel.as_posix())
assert changes==[path.as_posix()],changes
dp=out/'changes-r77-r79.diff'
with dp.open('x',encoding='utf-8') as f:f.write(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='r77/'+path.as_posix(),tofile='r79/'+path.as_posix())))
runner=tmp/'provider-ordinary-staging-box-run-r79.py'
text=(tmp/'provider-ordinary-staging-diagnostic-run-r77.py').read_text(encoding='utf-8').replace('r77','r79').replace('ordinary-staging-diagnostic','ordinary-staging-box')
with runner.open('x',encoding='utf-8') as f:f.write(text)
native='projection::provider::bootstrap::preparation::activation::session::managed_ordinary_fresh_staging_tests::'
recipes=[dict(name=native+'managed_ordinary_fresh_staging_refuses_changed_b_image_then_promotes_exact_ready_after_all_holders_release',ignored=True,child_seconds=3600,outer_seconds=3660,scope='Fresh unchanged Staging after true holder release, real image drift refusal, successful Ready commit/positive close/fresh readback; phase traces retained and normal stack limit.'),dict(name=native+'managed_ordinary_fresh_staging_withheld_b_close_ack_reopens_actual_ready_after_explicit_holder_release',ignored=True,child_seconds=3600,outer_seconds=3660,scope='Separate fresh fixture; successful physical B close then withheld ACK, zero later probes and retained cause/pins until explicit release; separate Ready handoff without publishing.')]
bindings={k:pin(p) for k,p in dict(runner=runner,host_audit=audit,release_script=Path(__file__),build=build,workspace_check=check,diff=dp,prior_release=prior/'ordinary-staging-diagnostic-source-release.json',prior_results=prior/'ordinary-staging-diagnostic-results.json',prior_failure=failure,prior_stack_chain=tmp/'ordinary-r72-callchain-summary.json',prior_stack_graph=tmp/'ordinary-r72-callchain-graph.json').items()}
saved=out/'bound-inputs';saved.mkdir(exist_ok=False)
for name,e in bindings.items():shutil.copyfile(e['path'],saved/(name+'-'+Path(e['path']).name))
release=dict(decision='released',revision='r79',recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_head=head,artifact_audit=host['executable'],reviewer='ROOT focused self-review of mechanically verified small boxing delta; no new independent critical review claimed. Prior r70 protocol review and r73/r74 unchanged behavior reviews retained via baseline.',source_review='All662 live/retained inputs match. Exactly one path changed; stripping only two private return type changes, Box construction and explanatory comment yields exact r77 source. Proof/owner/transaction/close order unchanged; Box contains owned DATA only. Build/check r78 PASS.',limitations=['r72/r77 failures retained; r77 proves setup/drift refusal precede overflow at validate/observation. No native fix result at release.', 'No larger stack or skipped validation; heap placement may reduce frame pressure but must pass the native tests.', 'ACK test withholds acknowledgment after successful physical close, not real native close failure or crash recovery.', 'Source10 recipe remains compiled but unexecuted; full programme incomplete.'],recipes=recipes,input_bindings=bindings)
p=out/'ordinary-staging-box-source-release.json'
with p.open('x',encoding='utf-8') as f:json.dump(release,f,indent=2)
print(json.dumps(dict(release=pin(p),changed=len(changes),recipes=len(recipes))))
