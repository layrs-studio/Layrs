from pathlib import Path
import datetime, difflib, hashlib, json, shutil, subprocess, sys

assert sys.argv[1:] == ['--root-accept-source-review']
root = Path('D:/Layrs/layrs')
tmp = Path('D:/Layrs/tmp')
prior = root/'.layrs-local/validation/provider-ordinary-fresh-admission-20261028-r66'
out = root/'.layrs-local/validation/provider-ordinary-fresh-publication-20261028-r69'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pin = lambda p: dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
manifest_path = tmp/'provider-ordinary-fresh-publication-review-r67-inputs.json'
assert sha(manifest_path) == '3a658f04430e640b8bcd7db97f5a00beeeef2ded66ff20e90f5576af50fc51c5'
manifest = read(manifest_path)
review_path = tmp/'provider-ordinary-fresh-publication-critical-review-r67.json'
review = read(review_path)
assert review['findings'] == [] and review['mode'] == 'source-only'
assert review['integrity']['manifest']['sha256'] == sha(manifest_path)
assert review['integrity']['ending']['all_snapshot_and_live_hashes_and_sizes_match']
assert review['integrity']['ending']['all_supplemental_hashes_match']
head = subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()
assert head == manifest['head']
for e in manifest['files']:
    assert sha(root/e['path']) == e['sha256'] == sha(out/'source'/e['path'])
for e in review['integrity']['supplemental_live_dependencies']:
    assert sha(root/'crates/layrs-store-local/src'/e['path']) == e['sha256']
prior_result = read(prior/'ordinary-fresh-admission-results.json')
assert [r['exit'] for r in prior_result['results']] == [0,0,0,0,0], 'r66 qualification incomplete or failed'
host = read(out/'host-disposition.json')
assert len(host['sourceClosure']) == 659
for e in [host['executable'],host['pdb']]:
    assert pin(Path(e['path'])) == e
changed = []
diffs = []
for e in host['sourceClosure']:
    relative = Path(e['path']).relative_to(root)
    path = relative.as_posix()
    assert sha(root/relative) == e['sha256'] == sha(out/'source'/relative)
    old = (prior/'source'/relative).read_bytes().replace(b'\r\n',b'\n') if (prior/'source'/relative).exists() else b''
    new = (out/'source'/relative).read_bytes().replace(b'\r\n',b'\n')
    if old != new:
        changed.append(path)
        diffs.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='r66/'+path,tofile='r69/'+path))
assert set(changed) == set(manifest['changed']), changed
diff = out/'changes-r66-r69.diff'
with diff.open('x',encoding='utf-8') as f: f.write(''.join(diffs))
runner = tmp/'provider-ordinary-fresh-publication-run-r69.py'
text = (tmp/'provider-ordinary-fresh-admission-run-r66.py').read_text(encoding='utf-8')
text = text.replace('r66','r69').replace('provider-ordinary-fresh-admission','provider-ordinary-fresh-publication').replace('ordinary-fresh-admission-source-release','ordinary-fresh-publication-source-release').replace('ordinary-fresh-admission-results','ordinary-fresh-publication-results')
with runner.open('x',encoding='utf-8') as f: f.write(text)
sql = 'projection::provider::destination_ready::'
native = 'projection::provider::bootstrap::preparation::activation::session::managed_ordinary_fresh_publication_tests::'
recipes = [
    dict(name=sql+'ordinary_tests::ordinary_source_publication_partitions_receipts_fences_ready_and_replays_historical_published',ignored=True,child_seconds=120,outer_seconds=180,scope='Existing exact Ordinary source-publication SQL regression; genuine admission/outgoing, receipt partition, frontier and historical replay.'),
    dict(name=sql+'autonomous::tests::autonomous_managed_ready_survives_source_removal_and_reads_ro',ignored=True,child_seconds=120,outer_seconds=180,scope='Existing autonomous Provider reader compatibility after retaining private metadata floor.'),
    dict(name=sql+'autonomous::tests::autonomous_managed_ready_rejects_suffix_journal_phase_and_debit_corruption',ignored=True,child_seconds=120,outer_seconds=180,scope='Existing autonomous Ready suffix/journal/family/debit refusals remain strict.'),
    dict(name=native+'managed_ordinary_fresh_publication_advances_released_ready_and_replays_published_without_writer',ignored=True,child_seconds=3600,outer_seconds=3660,scope='True SourceReady stop and total holder teardown; fresh exclusive B/shared C; successful source commit/close/fresh readback, exact effects, no-writer replay.'),
    dict(name=native+'managed_ordinary_fresh_publication_withheld_b_close_ack_resolves_actual_published_with_b_without_writer',ignored=True,child_seconds=3600,outer_seconds=3660,scope='Withheld ACK after successful physical B close; zero postfailure observed probes; explicit B-unavailable refusal then two-pass writer-free actual Published resolution.')]
build = tmp/'provider-ordinary-fresh-publication-build-r68.log'
check = tmp/'provider-ordinary-fresh-publication-check-r68.log'
for p in [build,check]:
    raw = p.read_bytes()
    text = raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert 'Finished `' in text and 'error[' not in text
bindings = {name:pin(p) for name,p in dict(runner=runner,
    host_audit=tmp/'provider-ordinary-fresh-publication-host-audit-r69.py',
    artifact_preparation=tmp/'prepare-ordinary-fresh-publication-artifacts-r69.py',
    build=build,workspace_check=check,review67=review_path,manifest67=manifest_path,
    review_diff=tmp/'provider-ordinary-fresh-publication-review-r67.diff',diff=diff,
    prior_release=prior/'ordinary-fresh-admission-source-release.json',
    prior_results=prior/'ordinary-fresh-admission-results.json',release_script=Path(__file__)).items()}
saved = out/'bound-inputs'
saved.mkdir(exist_ok=False)
for name,e in bindings.items(): shutil.copyfile(e['path'],saved/(name+'-'+Path(e['path']).name))
release = dict(decision='released',revision='r69',recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_head=head,
    reviewer='ROOT acceptance after reading completed r67 source review; execution limited to five exact recipes.',
    artifact_audit=host['executable'],reviewed_paths=manifest['files'],
    source_review='All16 live/retained source inputs match r67, all10 supplemental dependency hashes match; all659 build source inputs match. Exactly8 paths change from r66; build/check r68 PASS.',
    inherited_evidence='r66 five exact recipes passed. This does not qualify new Ready-to-Published behavior; new recipes below remain unexecuted at release.',
    limitations=['Serial fresh C parent, stop first failure, no prior fixture reopening.',
        'Clean original holder teardown is not crash recovery; withheld ACK follows physically successful B close.',
        'No native fresh Staging/mismatched-receipt/later-B-suffix replay, actual OS close or rollback fault qualification.',
        'One README, no general positive nested/deletion or full programme qualification. Timings are observations, not guaranteed bounds.'],
    recipes=recipes,input_bindings=bindings)
path = out/'ordinary-fresh-publication-source-release.json'
with path.open('x',encoding='utf-8') as f: json.dump(release,f,indent=2)
print(json.dumps(dict(release=pin(path),recipes=len(recipes),changed=len(changed))))
