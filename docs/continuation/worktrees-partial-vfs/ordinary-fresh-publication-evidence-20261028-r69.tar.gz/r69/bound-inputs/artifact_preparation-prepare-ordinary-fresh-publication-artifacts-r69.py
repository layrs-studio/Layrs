from pathlib import Path
import hashlib, json, subprocess

root = Path('D:/Layrs/layrs')
tmp = Path('D:/Layrs/tmp')
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest_path = tmp/'provider-ordinary-fresh-publication-review-r67-inputs.json'
assert sha(manifest_path) == '3a658f04430e640b8bcd7db97f5a00beeeef2ded66ff20e90f5576af50fc51c5'
manifest = read(manifest_path)
for e in manifest['files']:
    assert sha(root/e['path']) == e['sha256']
for name in ['provider-ordinary-fresh-publication-build-r68.log','provider-ordinary-fresh-publication-check-r68.log']:
    raw = (tmp/name).read_bytes()
    text = raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert 'Finished `' in text and 'error[' not in text
audit = tmp/'provider-ordinary-fresh-publication-host-audit-r69.py'
text = (tmp/'provider-ordinary-fresh-admission-host-audit-r66.py').read_text(encoding='utf-8')
text = text.replace('r66','r69').replace('provider-ordinary-fresh-admission','provider-ordinary-fresh-publication')
old = 'Fresh B/C ownership and Ordinary C8-to-C10 admission, strict nested error cleanup, explicit resolution and corrected autonomous public C10 recipe.'
new = 'Fresh B Exclusive then C Shared, actual Ordinary Ready-to-Published, strict nested failure-stop, positive source close and writer-free actual Published replay/resolution.'
assert old in text
text = text.replace(old,new)
with audit.open('x',encoding='utf-8') as f: f.write(text)
subprocess.run(['py',str(audit),'r69'],check=True)
out = root/'.layrs-local/validation/provider-ordinary-fresh-publication-20261028-r69'
host = read(out/'host-disposition.json')
assert len(host['sourceClosure']) == 659
for e in host['sourceClosure']:
    relative = Path(e['path']).relative_to(root)
    assert sha(root/relative) == e['sha256'] == sha(out/'source'/relative)
print(json.dumps(dict(artifactDirectory=str(out),sourceFiles=659,decision='Binding only; ROOT comparison and exact source release still required.')))
