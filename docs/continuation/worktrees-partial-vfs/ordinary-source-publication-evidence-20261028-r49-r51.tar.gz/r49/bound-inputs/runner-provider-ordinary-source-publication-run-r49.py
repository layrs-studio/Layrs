from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time

revision = sys.argv[1]
assert revision == 'r49'
out = Path('D:/Layrs/layrs/.layrs-local/validation/provider-family-publication-20261027-' + revision)
host = json.loads((out / 'host-disposition.json').read_bytes())
exe = Path(host['executable']['path'])
assert hashlib.sha256(exe.read_bytes()).hexdigest() == host['executable']['sha256']
release = json.loads((out / 'ordinary-source-publication-source-release.json').read_bytes())
assert release['decision'] == 'released' and release['reviewed_paths'] and release['recipes']
for record in release['reviewed_paths']:
    assert hashlib.sha256((out / 'source' / record['path']).read_bytes()).hexdigest() == record['sha256'].lower(), record['path']
parent = Path('C:/Users/ALEXA/AppData/Local/Temp/layrs-provider-ordinary-source-publication-' + revision)
parent.mkdir(exist_ok=False)
env = os.environ.copy()
env.update(LAYRS_PROVIDER_SQLITE_TEST_HOST='audited-layrs-test-host-v1',
           LAYRS_VFS_TEST_PARENT=str(parent), TEMP=str(parent), TMP=str(parent))
report = dict(executable=host['executable']['sha256'], sourceRelease=release,
              fixtureParent=str(parent), startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              scope='Ordinary B Ready/Published exact SQL and same-owner physical commits under actual C8 Ready/family Ready; original B ingress unchanged, positive terminal B owner close. Error-only cleanup and token invalidation after deliberately invalid rollback. No C9/autonomy, historical physical handoff, actual OS close/rollback failure, crash or owner loss.', results=[])
report_path = out / 'ordinary-source-publication-results.json'
assert not report_path.exists()
report_path.write_text(json.dumps(report, indent=2), encoding='utf-8')
for index, recipe in enumerate(release['recipes']):
    name = recipe['name']
    assert name.startswith('projection::') and recipe['outer_seconds'] <= 3660
    path = out / (name.rsplit('::', 1)[1] + '.log')
    fixture = parent / f'recipe-{index + 1:02d}'
    fixture.mkdir(exist_ok=False)
    env.update(LAYRS_VFS_TEST_PARENT=str(fixture), TEMP=str(fixture), TMP=str(fixture))
    args = [str(exe), '--exact', name, '--nocapture', '--test-threads=1']
    if recipe['ignored']:
        args.append('--ignored')
    print('START', name, flush=True)
    started = time.monotonic()
    with path.open('xb') as log:
        try:
            result = subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT,
                                    creationflags=subprocess.CREATE_NO_WINDOW,
                                    timeout=recipe['outer_seconds'])
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = 'owned process timeout'
    elapsed = round(time.monotonic() - started, 3)
    if code == 0 and 'test result: ok. 1 passed;' not in path.read_text(encoding='utf-8'):
        code = 'expected exact test did not run'
    report['results'].append(dict(test=name, exit=code, seconds=elapsed, fixtureParent=str(fixture)))
    report_path.write_text(json.dumps(report, indent=2), encoding='utf-8')
    print('END', name, code, elapsed, flush=True)
    if code != 0:
        raise SystemExit(1)
