from pathlib import Path
import datetime, difflib, hashlib, json, subprocess
import re

base=Path('D:/Layrs/layrs')
tmp=Path('D:/Layrs/tmp')
root=base / '.layrs-local/validation'
out=root / 'provider-family-publication-20261027-r49'
prior=root / 'provider-family-publication-20261027-r47'
read=lambda p: json.loads(p.read_bytes())
sha=lambda b: hashlib.sha256(b).hexdigest()
pin=lambda p: dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
manifest_path=tmp / 'provider-ordinary-source-publication-review-inputs-r48.json'
report_path=tmp / 'provider-ordinary-source-publication-critical-review-r48.json'
assert pin(manifest_path)['sha256']=='be48500220fdd4f84a8c5c94d17960095afde65734c6928e5a16a2fdc0ccb976'
manifest=read(manifest_path)
report=read(report_path)
assert report['conclusion']['status']=='source_review_complete_no_actionable_findings' and not report['findings']
assert report['integrity']['end']['source_sha256_matches']==24
source_path='crates/layrs-store-local/src/projection/shared/provider_import/source.rs'
test_path='crates/layrs-store-local/src/projection/provider/bootstrap/preparation/activation/session/managed_admission_tests.rs'
corrected={source_path,test_path}
original_block='''        // An earlier proof includes the previous outgoing row and MUST NOT be
        // reused after B CAS. Reinterpret genuine admission in this snapshot.
        let admitted = read_admitted_import(self.connection, self.marker, cancel)?;
        let fresh = OrdinarySourceInputs::new(
            self.connection,
            self.marker,
            &admitted,
            self.closure,
            self.retained,
        );
        fresh.require_family_identity(family, &actual, cancel)?;'''
fixed_block='''        // The driver supplies a fresh proof after every B CAS. require_private
        // reinterprets it in this snapshot and rejects a stale outgoing row;
        // shared code never bypasses the provider-private admission entry.
        self.require_family_identity(family, &actual, cancel)?;'''
fixed_test='''        access.connection.execute_batch("BEGIN IMMEDIATE").unwrap();
        access.connection.execute("UPDATE projection_provider_transitions SET digest=?1", [format!("blake3:{}", "0".repeat(64))]).unwrap();'''
old_test='''        access.connection.execute_batch("BEGIN IMMEDIATE; UPDATE projection_provider_transitions SET digest='invalid-uncommitted-digest'").unwrap();'''
originals={}
correction_diff=[]
def reviewed_source(path):
    # Reconstruct the complete reviewed text from the retained baseline and
    # hash-bound unified diff, including rustfmt's exact presentation.
    baseline=(prior/'source'/path).read_text(encoding='utf-8').splitlines(True)
    lines=(tmp/'provider-ordinary-source-publication-review-r48.diff').read_text(encoding='utf-8').splitlines(True)
    start=lines.index('+++ source-publication/'+path+'\n')+1
    result=[];cursor=0;i=start
    while i<len(lines) and not lines[i].startswith('--- '):
        match=re.match(r'@@ -(\d+)(?:,\d+)? \+\d+(?:,\d+)? @@',lines[i])
        assert match,(path,lines[i])
        target=max(0,int(match[1])-1)
        result.extend(baseline[cursor:target]);cursor=target;i+=1
        while i<len(lines) and not lines[i].startswith(('@@ ','--- ')):
            line=lines[i];kind=line[0];body=line[1:]
            if kind in ' -':
                assert baseline[cursor]==body,(path,cursor)
                cursor+=1
            if kind in ' +':result.append(body)
            assert kind in ' +-'
            i+=1
    result.extend(baseline[cursor:])
    return ''.join(result).encode('utf-8')
for entry in manifest['files']:
    p=entry['path']; raw=(base/p).read_bytes(); original=raw
    if p in corrected:
        current=raw.decode('utf-8'); restored=current
        if p==source_path:
            assert current.count(fixed_block)==1
            restored=restored.replace('managed_admission::VerifiedAdmittedImport,','managed_admission::{read_admitted_import, VerifiedAdmittedImport},').replace(fixed_block,original_block)
        else:
            assert current.count(fixed_test)==1
            restored=restored.replace(fixed_test,old_test)
        original=reviewed_source(p)
        restored=original.decode('utf-8')
        correction_diff.extend(difflib.unified_diff(restored.splitlines(True),current.splitlines(True),fromfile='reviewed-r48/'+p,tofile='r49/'+p))
    assert sha(original)==entry['sha256'] and len(original)==entry['bytes'],p
    originals[p]=original
for name in ['ordinary-source-publication-build-r49.log','ordinary-source-publication-check-r49.log']:
    raw=(tmp/name).read_bytes()
    text=raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert 'Finished `' in text,name
audit=tmp / 'provider-family-publication-host-audit-r49.py'
with audit.open('x',encoding='utf-8') as f:
    f.write((tmp/'provider-family-publication-host-audit-r46.py').read_text(encoding='utf-8').replace('r46','r49'))
subprocess.run(['py',str(audit),'r49'],check=True)
host=read(out/'host-disposition.json')
allowed=set(originals)
for entry in host['sourceClosure']:
    p=Path(entry['path']).relative_to(base)
    assert sha((out/'source'/p).read_bytes())==entry['sha256']==sha((base/p).read_bytes()),str(p)
    if p.as_posix() not in allowed:
        assert (prior/'source'/p).read_bytes().replace(b'\r\n',b'\n')==(out/'source'/p).read_bytes().replace(b'\r\n',b'\n'),str(p)
for p,data in originals.items():
    saved=out/'reviewed-r48-source'/p
    saved.parent.mkdir(parents=True,exist_ok=True)
    saved.write_bytes(data)
with (out/'corrections-r48-r49.diff').open('x',encoding='utf-8') as f:
    f.write(''.join(correction_diff))
proposal=read(tmp/'provider-ordinary-source-publication-proposed-recipes-r48.json')
recipes=proposal['recipes']; assert len(recipes)==18
exe=Path(host['executable']['path']).read_bytes()
for recipe in recipes:
    assert recipe['name'].encode() in exe,recipe['name']
runner=tmp/'provider-ordinary-source-publication-run-r49.py'
script=(tmp/'provider-ordinary-ready-run.py').read_text(encoding='utf-8')
script=script.replace("assert revision in [f'r{n}' for n in range(42, 50)]","assert revision == 'r49'")
script=script.replace('ordinary-ready-source-release.json','ordinary-source-publication-source-release.json').replace('ordinary-ready-results.json','ordinary-source-publication-results.json')
script=script.replace('layrs-provider-ordinary-ready-','layrs-provider-ordinary-source-publication-').replace("recipe['outer_seconds'] <= 3060","recipe['outer_seconds'] <= 3660")
start=script.index("              scope='");end=script.index(', results=[])',start)
script=script[:start]+"              scope='Ordinary B Ready/Published exact SQL and same-owner physical commits under actual C8 Ready/family Ready; original B ingress unchanged, positive terminal B owner close. Error-only cleanup and token invalidation after deliberately invalid rollback. No C9/autonomy, historical physical handoff, actual OS close/rollback failure, crash or owner loss.'"+script[end:]
with runner.open('x',encoding='utf-8') as f:f.write(script)
bindings={label:pin(path) for label,path in dict(runner=runner,host_audit=audit,review_manifest=manifest_path,review=report_path,review_diff=tmp/'provider-ordinary-source-publication-review-r48.diff',recipes=tmp/'provider-ordinary-source-publication-proposed-recipes-r48.json',corrections=out/'corrections-r48-r49.diff',build=tmp/'ordinary-source-publication-build-r49.log',check=tmp/'ordinary-source-publication-check-r49.log',failed_build=tmp/'ordinary-source-publication-build-r48.log',release_script=Path(__file__)).items()}
old_release=read(prior/'ordinary-ready-family-source-release.json')
paths=sorted({e['path'] for e in old_release['reviewed_paths']}|allowed)
release=dict(decision='released',revision='r49',recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=base,text=True).strip(),reviewer='Independent critical source review r48; ROOT narrow compile/test fixture corrections and exact artifact binding',runtime_executed_by_reviewer=False,
    scope='B Ready/Published SQL and same-owner physical driver; C stays C8 Ready and unadmitted.',
    corrections=['Shared reader uses already-fresh driver-provided proof, revalidated by require_private; removes inaccessible provider-private import and rejects stale proof instead of replacing it.','Cleanup fixture supplies wrong digest of schema-valid length71 so corruption is reached inside transaction.'],
    artifact_audit=dict(host=pin(out/'host-disposition.json'),executable=host['executable'],pdb=host['pdb'],codeView=host['codeView']),
    input_bindings=bindings,recipes=recipes,reviewed_paths=[dict(path=p,sha256=sha((out/'source'/p).read_bytes())) for p in paths],
    limitations=report['evidence_gaps'],unresolved_findings=[])
with (out/'ordinary-source-publication-source-release.json').open('x',encoding='utf-8') as f:json.dump(release,f,indent=2)
saved=out/'bound-inputs';saved.mkdir(exist_ok=False)
for label,e in bindings.items():(saved/(label+'-'+Path(e['path']).name)).write_bytes(Path(e['path']).read_bytes())
with (saved/'inventory.json').open('x',encoding='utf-8') as f:json.dump(bindings,f,indent=2)
print(json.dumps(dict(release=pin(out/'ordinary-source-publication-source-release.json'),sources=len(host['sourceClosure']),paths=len(paths),recipes=len(recipes))))
