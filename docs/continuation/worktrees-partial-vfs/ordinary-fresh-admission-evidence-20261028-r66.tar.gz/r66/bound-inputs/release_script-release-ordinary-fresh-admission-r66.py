from pathlib import Path
import datetime, difflib, hashlib, json, shutil, subprocess, sys

assert sys.argv[1:]==['--root-accept-source-review'], 'ROOT must first read and accept the completed r65 review'
root=Path('D:/Layrs/layrs');tmp=Path('D:/Layrs/tmp')
prior=root/'.layrs-local/validation/provider-ordinary-terminal-20261028-r60'
out=root/'.layrs-local/validation/provider-ordinary-fresh-admission-20261028-r66'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pin=lambda p:dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
manifest_path=tmp/'provider-ordinary-fresh-admission-review-r65-inputs.json'
assert sha(manifest_path)=='0af2628d4b38d6df1cba08f4a55df3718143eb5977523b2c658ec158febe8cf5'
manifest=read(manifest_path)
review65=tmp/'provider-ordinary-fresh-admission-correction-review-r65.json'
review=read(review65)
assert review['verdict']['status']=='bounded_source_correction_verified'
assert review['verdict']['r61_f1']=='resolved_by_source_inspection'
assert review['verdict']['new_concrete_findings']==0 and review['findings']==[]
assert review['integrity']['mismatches']==[]
assert review['integrity']['expected']['manifest_sha256']==sha(manifest_path)
head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()
assert head==manifest['head']
for e in manifest['files']:
    assert sha(root/e['path'])==e['sha256']==sha(out/'source'/e['path'])
host=read(out/'host-disposition.json');assert len(host['sourceClosure'])==657
for e in [host['executable'],host['pdb']]:
    assert pin(Path(e['path']))==e
changed=[];diffs=[]
for e in host['sourceClosure']:
    relative=Path(e['path']).relative_to(root);p=relative.as_posix()
    assert sha(root/relative)==e['sha256']==sha(out/'source'/relative)
    old=(prior/'source'/relative).read_bytes().replace(b'\r\n',b'\n') if (prior/'source'/relative).exists() else b''
    new=(out/'source'/relative).read_bytes().replace(b'\r\n',b'\n')
    if old!=new:
        changed.append(p)
        diffs.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='r60/'+p,tofile='r66/'+p))
assert set(changed)=={e['path'] for e in manifest['files']},changed
assert [r['exit'] for r in read(prior/'ordinary-terminal-results.json')['results']]==[0,101]
diff=out/'changes-r60-r66.diff'
with diff.open('x',encoding='utf-8') as f:f.write(''.join(diffs))
runner=tmp/'provider-ordinary-fresh-admission-run-r66.py'
text=(tmp/'provider-ordinary-terminal-run-r60.py').read_text(encoding='utf-8')
text=text.replace('r60','r66').replace('provider-ordinary-terminal','provider-ordinary-fresh-admission').replace('ordinary-terminal-source-release','ordinary-fresh-admission-source-release').replace('ordinary-terminal-results','ordinary-fresh-admission-results')
with runner.open('x',encoding='utf-8') as f:f.write(text)
short='projection::provider::database_io::tests::strict_read::'
native='projection::provider::bootstrap::preparation::activation::session::'
recipes=[
    dict(name=short+'strict_nested_read_preserves_callback_failure_without_concluding_filesystem_probes',ignored=True,child_seconds=120,outer_seconds=180,scope='Actual nested RO success snapshots, failure-stop before FS probes, preserved primary and unchanged default reader classification.'),
    dict(name=short+'strict_nested_read_preserves_primary_and_actual_busy_close_without_concluding_probes',ignored=True,child_seconds=120,outer_seconds=180,scope='Actual inner sqlite3_close BUSY from deliberately retained statement; original callback cause remains, outer mandatory close, no concluding probes; child exits quarantined.'),
    dict(name=native+'managed_ordinary_autonomy_tests::managed_ordinary_c10_reopens_and_captures_restores_after_all_holders_and_ancestors_release',ignored=True,child_seconds=3600,outer_seconds=3660,scope='r60 failed assertion corrected to exact earlier family-root refusal; all final mutable reopen/B baseline checks retained; fresh fixture.'),
    dict(name=native+'managed_ordinary_fresh_admission_tests::managed_ordinary_fresh_admission_accepts_advanced_published_b_after_all_publication_holders_release',ignored=True,child_seconds=3600,outer_seconds=3660,scope='Fresh B then C owners, C8 inspection, unavailable source refusal, coherent B suffix, positive C8-to-C10 writer and fresh readback.'),
    dict(name=native+'managed_ordinary_fresh_admission_tests::managed_ordinary_fresh_admission_withheld_c_ack_resolves_without_b_reads_or_identity_checks',ignored=True,child_seconds=3600,outer_seconds=3660,scope='ACK withheld after actual successful C close; no observed post-failure FS/RO/source identity; later explicit source-free resolve with actual B-path probes refused.')]
build=tmp/'provider-ordinary-fresh-admission-build-r64.log';check=tmp/'provider-ordinary-fresh-admission-check-r64.log'
for p in [build,check]:
    raw=p.read_bytes();text=raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert 'Finished `' in text and 'error[' not in text
bindings={name:pin(p) for name,p in dict(runner=runner,host_audit=tmp/'provider-ordinary-fresh-admission-host-audit-r66.py',artifact_preparation=tmp/'prepare-ordinary-fresh-admission-artifacts-r66.py',build=build,workspace_check=check,failed_build62=tmp/'provider-ordinary-fresh-admission-build-r62.log',failed_build63=tmp/'provider-ordinary-fresh-admission-build-r63.log',review61=tmp/'provider-ordinary-fresh-admission-critical-review-r61.json',review65=review65,manifest65=manifest_path,diff=diff,prior_release=prior/'ordinary-terminal-source-release.json',prior_results=prior/'ordinary-terminal-results.json',release_script=Path(__file__)).items()}
saved=out/'bound-inputs';saved.mkdir(exist_ok=False)
for name,e in bindings.items():shutil.copyfile(e['path'],saved/(name+'-'+Path(e['path']).name))
release=dict(decision='released',revision='r66',recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_head=head,
    reviewer='ROOT explicit acceptance of completed r61 review and r65 correction review; scope limited to the five bound recipes.',
    artifact_audit=host['executable'],reviewed_paths=manifest['files'],source_review='All13 live/retained files exactly match r65; all657 source inputs matched. r62/r63 failed build logs retained; r64 build/check PASS.',
    inherited_evidence='r57 admission PASS and r60 full terminal SQL PASS are prior evidence, not new executions. r60 native FAIL retained; corrected recipe reruns from a new fixture.',
    limitations=['No runtime result at release time. Serial, fresh C parent, stop first failure; no prior fixture reopening.',
      'ACK withholding follows successful physical writer close. BUSY close recipe uses an intentionally unfinalized statement and process quarantine, not OS fault/crash recovery.',
      'Instrumented no-B resolution does not prove physical B absence while the borrowed source pins remain. Counter scope is named DB identity/snapshot/read/source-identity boundaries, not all OS I/O.',
      'No physical D-to-E chain, B10-source native scenario, general nested/deletion coverage or full programme acceptance. Native time limits are proposed bounds, not worst-case guarantees.'],
    recipes=recipes,input_bindings=bindings)
path=out/'ordinary-fresh-admission-source-release.json'
with path.open('x',encoding='utf-8') as f:json.dump(release,f,indent=2)
print(json.dumps(dict(release=pin(path),recipes=len(recipes),changed=len(changed))))
