from pathlib import Path
import hashlib, json, subprocess

root=Path('D:/Layrs/layrs');tmp=Path('D:/Layrs/tmp')
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest_path=tmp/'provider-ordinary-fresh-admission-review-r65-inputs.json'
assert sha(manifest_path)=='0af2628d4b38d6df1cba08f4a55df3718143eb5977523b2c658ec158febe8cf5'
manifest=read(manifest_path)
for e in manifest['files']:
    assert sha(root/e['path'])==e['sha256']
for name in ['provider-ordinary-fresh-admission-build-r64.log','provider-ordinary-fresh-admission-check-r64.log']:
    raw=(tmp/name).read_bytes()
    text=raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert 'Finished `' in text and 'error[' not in text
audit=tmp/'provider-ordinary-fresh-admission-host-audit-r66.py'
text=(tmp/'provider-ordinary-terminal-host-audit-r60.py').read_text(encoding='utf-8')
text=text.replace('r60','r66').replace('provider-ordinary-terminal-20261028-','provider-ordinary-fresh-admission-20261028-')
text=text.replace('Fresh Ordinary C8/C10 read-only inspection and C10 autonomous public capture/restore; exact SQL terminal suffix fence.',
                  'Fresh B/C ownership and Ordinary C8-to-C10 admission, strict nested error cleanup, explicit resolution and corrected autonomous public C10 recipe. Binding only; no runtime result.')
with audit.open('x',encoding='utf-8') as f:f.write(text)
subprocess.run(['py',str(audit),'r66'],check=True)
out=root/'.layrs-local/validation/provider-ordinary-fresh-admission-20261028-r66'
host=read(out/'host-disposition.json')
assert len(host['sourceClosure'])==657
for e in host['sourceClosure']:
    relative=Path(e['path']).relative_to(root)
    assert sha(root/relative)==e['sha256']==sha(out/'source'/relative)
print(json.dumps(dict(artifactDirectory=str(out),sourceFiles=657,decision='Binding only; r65 correction review and ROOT release still required.')))
