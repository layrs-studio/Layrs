use layrs_lens_sdk::{
    AnalysisInput, AnalysisOutput, Analyzer, AnalyzerContract, ArtifactKind, ArtifactMetadata,
    DiffKind, DiffModel, InspectorField, InspectorValueType, LensCapability,
    LensFileResolutionInput, LensManifest, LensReconcileContent, LensReconcileInput,
    LensReconcileResult, LensResult, MetadataValue, PreviewKind, PreviewModel, ResolutionMethod,
    ResolutionMethods, ViewerContract, content_hash,
};

pub const RAW_LENS_ID: &str = "layrs.raw";
pub const RAW_LENS_VERSION: &str = "1.0.0";
pub const RAW_LENS_DIGEST: &str =
    "sha256:1cc07635972c4402981d6f7df708af8b7a001a850ebd3dea1fed7f4eb47453aa";
const LEGACY_ANALYSIS_RECONCILE_SUMMARY: &str =
    "Legacy analysis reconcile status is non-authoritative; use reconcile_raw";

#[derive(Debug, Default, Clone, Copy)]
pub struct RawLens;

impl Analyzer for RawLens {
    fn manifest(&self) -> LensManifest {
        manifest()
    }

    fn analyze(&self, input: AnalysisInput<'_>) -> LensResult<AnalysisOutput> {
        Ok(analyze(input))
    }
}

pub fn manifest() -> LensManifest {
    let mut viewer = ViewerContract::new(
        "layrs.viewer.raw",
        "RawArtifactViewer",
        vec![PreviewKind::Raw],
        vec![DiffKind::Binary],
    );
    viewer.inspector_fields = vec![
        InspectorField {
            key: "byte_len".to_string(),
            label: "Size".to_string(),
            value_type: InspectorValueType::Number,
        },
        InspectorField {
            key: "content_hash".to_string(),
            label: "Hash".to_string(),
            value_type: InspectorValueType::String,
        },
        InspectorField {
            key: "media_type".to_string(),
            label: "Type".to_string(),
            value_type: InspectorValueType::String,
        },
    ];

    let mut manifest = LensManifest::new(
        RAW_LENS_ID,
        "Raw",
        RAW_LENS_VERSION,
        AnalyzerContract {
            supported_media_types: vec!["application/octet-stream".to_string()],
            file_extensions: Vec::new(),
            capabilities: vec![
                LensCapability::View,
                LensCapability::Diff,
                LensCapability::Reconcile,
                LensCapability::Metadata,
                LensCapability::Preview,
            ],
        },
        viewer,
    )
    .with_digest(RAW_LENS_DIGEST);
    manifest.resolution_methods = resolution_methods();
    manifest
}

pub fn resolution_methods() -> ResolutionMethods {
    ResolutionMethods::file(raw_file_resolution_methods())
}

pub fn analyze(input: AnalysisInput<'_>) -> AnalysisOutput {
    let media_type = input.media_type.unwrap_or("application/octet-stream");

    let mut metadata = ArtifactMetadata::new(
        input.artifact_id,
        RAW_LENS_ID,
        ArtifactKind::Raw,
        media_type,
        input.bytes,
    );
    metadata.fields.insert(
        "hash_algorithm".to_string(),
        MetadataValue::String("fnv1a64".to_string()),
    );

    if let Some(path) = input.path {
        metadata.fields.insert(
            "path".to_string(),
            MetadataValue::String(path.to_string_lossy().into_owned()),
        );
    }

    let mut preview = PreviewModel::new(PreviewKind::Raw, "Raw artifact", media_type);
    preview.fields.insert(
        "byte_len".to_string(),
        MetadataValue::Unsigned(input.bytes.len() as u64),
    );
    preview.fields.insert(
        "content_hash".to_string(),
        MetadataValue::String(metadata.content_hash.clone()),
    );

    let mut output = AnalysisOutput::new(metadata);
    // Legacy analysis output cannot express canonical three-way results; use reconcile_raw.
    output.reconcile.summary = LEGACY_ANALYSIS_RECONCILE_SUMMARY.to_string();
    output.preview = Some(preview);
    output.diff = input
        .previous_bytes
        .map(|previous| diff_binary(previous, input.bytes));
    output
}

pub fn diff_binary(previous: &[u8], current: &[u8]) -> DiffModel {
    let previous_hash = content_hash(previous);
    let current_hash = content_hash(current);
    let changed = previous_hash != current_hash;
    let mut diff = DiffModel::new(
        DiffKind::Binary,
        if changed {
            "Binary content changed"
        } else {
            "No binary changes"
        },
    );
    diff.fields.insert(
        "previous_byte_len".to_string(),
        MetadataValue::Unsigned(previous.len() as u64),
    );
    diff.fields.insert(
        "current_byte_len".to_string(),
        MetadataValue::Unsigned(current.len() as u64),
    );
    diff.fields.insert(
        "previous_hash".to_string(),
        MetadataValue::String(previous_hash),
    );
    diff.fields.insert(
        "current_hash".to_string(),
        MetadataValue::String(current_hash),
    );
    diff.fields
        .insert("changed".to_string(), MetadataValue::Bool(changed));
    diff
}

pub fn reconcile_raw(input: LensReconcileInput<'_>) -> LensReconcileResult {
    if same_side(input.ours, input.theirs) {
        return LensReconcileResult::auto_resolved(
            "Raw sides are identical",
            content_from_side(input.ours),
        );
    }
    if same_side(input.base, input.ours) {
        return LensReconcileResult::auto_resolved(
            "Existing side is unchanged; taking incoming",
            content_from_side(input.theirs),
        );
    }
    if same_side(input.base, input.theirs) {
        return LensReconcileResult::auto_resolved(
            "Incoming side is unchanged; keeping existing",
            content_from_side(input.ours),
        );
    }

    LensReconcileResult::conflicted(
        "Raw content changed differently on both sides",
        content_from_side(input.ours),
        Vec::new(),
        Vec::new(),
    )
    .with_file_methods(raw_file_resolution_methods())
}

pub fn resolve_raw_conflict(
    input: LensFileResolutionInput<'_>,
) -> LensResult<LensReconcileContent> {
    match input.method {
        ResolutionMethod::Existing => Ok(content_from_side(input.existing)),
        ResolutionMethod::Incoming => Ok(content_from_side(input.incoming)),
        method => Err(layrs_lens_sdk::LensError::new(
            "unsupported_raw_resolution",
            format!(
                "Raw file resolution `{}` is not supported. Use existing or incoming.",
                method.as_str()
            ),
        )),
    }
}

fn same_side(
    left: layrs_lens_sdk::LensReconcileSide<'_>,
    right: layrs_lens_sdk::LensReconcileSide<'_>,
) -> bool {
    left.exists == right.exists && (!left.exists || left.bytes == right.bytes)
}

fn content_from_side(side: layrs_lens_sdk::LensReconcileSide<'_>) -> LensReconcileContent {
    if side.exists {
        LensReconcileContent::present(side.bytes.to_vec())
    } else {
        LensReconcileContent::absent()
    }
}

fn raw_file_resolution_methods() -> Vec<ResolutionMethod> {
    vec![ResolutionMethod::Existing, ResolutionMethod::Incoming]
}

#[cfg(test)]
mod tests {
    use super::*;
    use layrs_lens_sdk::{
        LENS_CONTRACT_VERSION, LensReconcileInput, LensReconcileResultStatus, LensReconcileSide,
        ReconcileStatus,
    };

    #[test]
    fn manifest_matches_raw_golden_contract() {
        let manifest = manifest();
        let pin = manifest.pin().expect("built-in Lens pin");

        assert_eq!(manifest.contract_version, LENS_CONTRACT_VERSION);
        assert_eq!(manifest.id, RAW_LENS_ID);
        assert_eq!(manifest.version, RAW_LENS_VERSION);
        assert_eq!(manifest.digest.as_deref(), Some(RAW_LENS_DIGEST));
        assert_eq!(pin.lens_id, RAW_LENS_ID);
        assert_eq!(pin.version, RAW_LENS_VERSION);
        assert_eq!(pin.digest, RAW_LENS_DIGEST);
        assert_eq!(
            manifest.analyzer.supported_media_types,
            vec!["application/octet-stream"]
        );
        assert!(manifest.analyzer.file_extensions.is_empty());
        assert_eq!(
            manifest.analyzer.capabilities,
            vec![
                LensCapability::View,
                LensCapability::Diff,
                LensCapability::Reconcile,
                LensCapability::Metadata,
                LensCapability::Preview,
            ]
        );
        assert_eq!(manifest.viewer.preview_kinds, vec![PreviewKind::Raw]);
        assert_eq!(manifest.viewer.diff_kinds, vec![DiffKind::Binary]);
        assert!(manifest.viewer.reconcile_statuses.is_empty());
        assert_eq!(
            manifest.resolution_methods.file,
            vec![ResolutionMethod::Existing, ResolutionMethod::Incoming]
        );
        assert!(manifest.resolution_methods.block.is_empty());
    }

    #[test]
    fn preview_and_diff_remain_available_offline() {
        let output = analyze(AnalysisInput::new("artifact", b"same").with_previous_bytes(b"same"));

        assert_eq!(output.preview.expect("preview").kind, PreviewKind::Raw);
        assert_eq!(output.diff.expect("diff").kind, DiffKind::Binary);
        assert_eq!(output.reconcile.status, ReconcileStatus::Unsupported);
        assert_eq!(output.reconcile.summary, LEGACY_ANALYSIS_RECONCILE_SUMMARY);
    }

    #[test]
    fn raw_reconcile_auto_resolves_identical_sides() {
        let result = reconcile_case(b"base", b"same", b"same");

        assert_eq!(result.status, LensReconcileResultStatus::AutoResolved);
        assert_eq!(result.resolved.expect("resolved").bytes, b"same");
    }

    #[test]
    fn raw_reconcile_takes_source_when_target_unchanged() {
        let result = reconcile_case(b"base", b"base", b"source");

        assert_eq!(result.status, LensReconcileResultStatus::AutoResolved);
        assert_eq!(result.resolved.expect("resolved").bytes, b"source");
    }

    #[test]
    fn raw_reconcile_keeps_target_when_source_unchanged() {
        let result = reconcile_case(b"base", b"target", b"base");

        assert_eq!(result.status, LensReconcileResultStatus::AutoResolved);
        assert_eq!(result.resolved.expect("resolved").bytes, b"target");
    }

    #[test]
    fn raw_reconcile_conflicts_whole_file_without_markers() {
        let result = reconcile_case(b"base", b"target\x00bytes", b"source\x00bytes");

        assert_eq!(result.status, LensReconcileResultStatus::Conflicted);
        assert!(result.blocks.is_empty());
        assert!(result.segments.is_empty());
        assert_eq!(
            result.file_methods,
            vec![ResolutionMethod::Existing, ResolutionMethod::Incoming]
        );
        assert_eq!(result.conflict.expect("conflict").bytes, b"target\x00bytes");
    }

    #[test]
    fn raw_lens_resolves_file_methods_only() {
        let input = LensFileResolutionInput {
            method: ResolutionMethod::Incoming,
            base: LensReconcileSide::present(b"base", None),
            existing: LensReconcileSide::present(b"existing", None),
            incoming: LensReconcileSide::present(b"incoming", None),
        };

        let content = resolve_raw_conflict(input).expect("incoming");

        assert_eq!(content.bytes, b"incoming");
        assert!(
            resolve_raw_conflict(LensFileResolutionInput {
                method: ResolutionMethod::Both,
                base: LensReconcileSide::present(b"base", None),
                existing: LensReconcileSide::present(b"existing", None),
                incoming: LensReconcileSide::present(b"incoming", None),
            })
            .is_err()
        );
        assert!(
            resolve_raw_conflict(LensFileResolutionInput {
                method: ResolutionMethod::Manual,
                base: LensReconcileSide::present(b"base", None),
                existing: LensReconcileSide::present(b"existing", None),
                incoming: LensReconcileSide::present(b"incoming", None),
            })
            .is_err()
        );
    }

    fn reconcile_case(base: &[u8], ours: &[u8], theirs: &[u8]) -> LensReconcileResult {
        reconcile_raw(LensReconcileInput {
            path: None,
            media_type: Some("application/octet-stream"),
            base: LensReconcileSide::present(base, None),
            ours: LensReconcileSide::present(ours, None),
            theirs: LensReconcileSide::present(theirs, None),
            ours_label: "target",
            theirs_label: "source",
        })
    }
}
