from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,sys
assert sys.argv[1:]==['--root-accept-reviewed-family']
root=Path('D:/Layrs/layrs');tmp=Path('D:/Layrs/tmp')
prior=root/'.layrs-local/validation/provider-ordinary-staging-box-20261028-r79'
out=root/'.layrs-local/validation/provider-ordinary-fresh-family-20261028-r84'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pin=lambda p:dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
assert [r['exit'] for r in read(root/'.layrs-local/validation/provider-ordinary-source10-20261028-r81/ordinary-source10-results.json')['results']]==[101], 'r81 expected retained witness failure'
correction_path=tmp/'ordinary-source10-budget-correction-r84.json'
correction=read(correction_path)
assert pin(Path(correction['source']['path']))==correction['source']
assert pin(Path(correction['diff']['path']))==correction['diff']
manifest_path=tmp/'provider-ordinary-fresh-family-review-r82-inputs.json'
manifest=read(manifest_path)
report_path=tmp/'provider-ordinary-fresh-family-critical-review-r82.json'
report=read(report_path)
assert [f['id'] for f in report['findings']]==['R82-CV-01']
assert sha(manifest_path)=='62a903bad05b08a0820a2874f7f15e2b161f71bced02f1ae43b604c653c0252b'
frozen=tmp/'provider-ordinary-fresh-family-review-r82-source'
wording='crates/layrs-store-local/src/projection/provider/bootstrap/preparation/activation/session/managed_ordinary_fresh_family_tests.rs'
for e in manifest['files']:
 rel=e['path'];assert pin(frozen/rel)['sha256']==e['sha256']
 if rel!=wording:assert (root/rel).read_bytes()==(frozen/rel).read_bytes(),rel
old=(frozen/wording).read_text(encoding='utf-8');new=(root/wording).read_text(encoding='utf-8')
assert new==old.replace('//! ACK follows a successful OS close; no OS close failure, crash or owner-loss\n//! recovery is qualified. Positive deletion/nested checkout remain separate.','//! ACK follows an actual SQLite connection close returning success; native\n//! xClose/OS-close outcomes, crash and owner-loss recovery are not qualified.\n//! Positive deletion/nested checkout remain separate.').replace('requires actual successful physical family writer close','requires actual SQLite family writer connection close returning success')
build=tmp/'provider-ordinary-fresh-family-build-r83.log'
check=tmp/'provider-ordinary-fresh-family-check-r83.log'
for p in [build,check]:
 raw=p.read_bytes();text=raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
 assert 'Finished `' in text and 'error[' not in text
head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()
assert head=='f01f6b9518b71a3cfc309be3a2911c51599f2e79'
audit=tmp/'provider-ordinary-fresh-family-host-audit-r84.py'
text=(tmp/'provider-ordinary-staging-box-host-audit-r79.py').read_text(encoding='utf-8').replace('r79','r84').replace('provider-ordinary-staging-box','provider-ordinary-fresh-family')
text=text.replace('One-file private Box<Validated> return representation after r77 confirmed overflow at nested validated read. Same protocol and phase traces; native qualification pending.','Fresh actual-B-backed family publication candidate reviewed r82; only ROOT comment/assertion wording correction afterward. Build/check r83 PASS, plus source10 test-witness correction; new runtime qualification pending.')
assert audit.read_text(encoding='utf-8')==text, 'retained host audit must match exact intended script'
host=read(out/'host-disposition.json');assert len(host['sourceClosure'])==666
for e in [host['executable'],host['pdb']]:assert pin(Path(e['path']))==e
changes=[]
for e in host['sourceClosure']:
 rel=Path(e['path']).relative_to(root)
 assert sha(root/rel)==e['sha256']==sha(out/'source'/rel)
 if not (prior/'source'/rel).is_file() or (prior/'source'/rel).read_text(encoding='utf-8')!=(out/'source'/rel).read_text(encoding='utf-8'):changes.append(rel.as_posix())
assert set(changes)==set(manifest['changed']+['crates/layrs-store-local/src/projection/provider/bootstrap/preparation/activation/session/managed_ordinary_source10_export_tests.rs']),changes
runner=tmp/'provider-ordinary-fresh-family-run-r84.py'
text=(tmp/'provider-ordinary-staging-box-run-r79.py').read_text(encoding='utf-8').replace('r79','r84').replace('ordinary-staging-box','ordinary-fresh-family')
text=text.replace("recipe['outer_seconds'] <= 3660", "(recipe['outer_seconds'] <= 3660 or (recipe['outer_seconds'] == 5460 and recipe['child_seconds'] == 5400 and name.endswith('managed_ordinary_source10_exports_nested_and_deleted_paths_to_d10_then_reopens')))")
with runner.open('x',encoding='utf-8') as f:f.write(text)
recipes=[]
sql='projection::provider::destination_ready::'
for name,scope in [
 ('autonomous::tests::autonomous_managed_ready_survives_source_removal_and_reads_ro','Unchanged Provider terminal reader after internal private-parts extraction; exact Ready, complete protected installation and readonly source-independent interpretation.'),
 ('autonomous::tests::autonomous_managed_ready_rejects_suffix_journal_phase_and_debit_corruption','Provider terminal rejection regression for suffix, journal, member and debit corruption.'),
 ('ordinary_tests::ordinary_autonomy_keeps_uncopied_selected_base_and_current_representations_through_admission10','Ordinary autonomous terminal/admission union and exact representation regression after extraction.'),
 ('ordinary_tests::ordinary_family_publication_authenticates_actual_ready_changes_one_row_and_replays_readonly','Extended r82 provisional/complete reader distinctions, reordered exact union, substitution/duplicate rejection, missing retained B root, phase/corruption/query-only controls.')]:
 recipes.append(dict(name=sql+name,ignored=True,child_seconds=120,outer_seconds=180,scope=scope))
native='projection::provider::bootstrap::preparation::activation::session::managed_ordinary_fresh_family_tests::'
for name,scope in [
 ('managed_ordinary_fresh_family_refuses_changed_b_image_then_updates_only_member_and_replays_without_writer','Genuine PrivateReady teardown; B image drift refused, exact Updated one-member CAS, fresh readback, released-holder AlreadyReady without writer, separate Staging handoff inspection.'),
 ('managed_ordinary_fresh_family_withheld_catalog_close_ack_reopens_ready_after_explicit_holder_release','Separate fresh fixture, withheld acknowledgment after SQLite connection close returns success; no later observed probes, retained cause/pins/owners, explicit release then fresh no-writer AlreadyReady.')]:
 recipes.append(dict(name=native+name,ignored=True,child_seconds=3600,outer_seconds=3660,scope=scope))
recipes.insert(4,dict(name='projection::provider::bootstrap::preparation::activation::session::managed_ordinary_source10_export_tests::managed_ordinary_source10_exports_nested_and_deleted_paths_to_d10_then_reopens',ignored=True,child_seconds=5400,outer_seconds=5460,scope='Corrected committed-budget settlement witness; full C10-to-D10 nested addition/deletion export, admission and public reopens. Separate fresh parent.'))
bindings={k:pin(p) for k,p in dict(root_source10_correction=correction_path,root_source10_diff=tmp/'ordinary-source10-budget-correction-r84.diff',source10_review=tmp/'provider-ordinary-source10-export-critical-review-r74.json',r81_results=root/'.layrs-local/validation/provider-ordinary-source10-20261028-r81/ordinary-source10-results.json',runner=runner,host_audit=audit,release_script=Path(__file__),build=build,workspace_check=check,critical_manifest=manifest_path,critical_review=report_path,critical_diff=tmp/'provider-ordinary-fresh-family-review-r82.diff',review_archive=root/'docs/continuation/worktrees-partial-vfs/ordinary-fresh-family-source-review-20261028-r82.tar.gz',prior_release=prior/'ordinary-staging-box-source-release.json').items()}
saved=out/'bound-inputs';saved.mkdir(exist_ok=False)
for name,e in bindings.items():shutil.copyfile(e['path'],saved/(name+'-'+Path(e['path']).name))
release=dict(decision='released',revision='r84',recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_head=head,artifact_audit=host['executable'],reviewer='Independent change-critical-verifier r82; ROOT integrated acceptance and mechanically checked wording-only fix R82-CV-01.',source_review='All666 live/retained source inputs match. Exactly14 paths differ from retained r79: reviewed r82, comment/assertion text correction and independently r74-reviewed source10 recipe with ROOT bounded budget-settlement witness correction. Build/workspace check r83 PASS. No protocol or integrity finding in bounded source review.',limitations=['New candidate unexecuted at release. Source review is not runtime evidence.','Fresh-family child3600/outer3660 and source10 child5400/outer5460 proposed; successful completion times unmeasured.','SQLite connection-close success does not prove native xClose/OS-close success; ACK withholding is not native close failure or crash/owner-loss recovery.','New native fixtures are flat README; no fresh-family positive deletion/nested checkout claim.','Fresh-family recipes have no source Ready/Published or C admission effects; the separate source10 recipe explicitly exercises its complete export/admission leg. Full programme remains open.'],recipes=recipes,input_bindings=bindings)
p=out/'ordinary-fresh-family-source-release.json'
with p.open('x',encoding='utf-8') as f:json.dump(release,f,indent=2)
print(json.dumps(dict(release=pin(p),source_inputs=len(host['sourceClosure']),changed=len(changes),recipes=len(recipes))))
