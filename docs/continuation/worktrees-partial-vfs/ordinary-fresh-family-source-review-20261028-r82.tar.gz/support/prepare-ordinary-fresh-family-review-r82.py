from pathlib import Path
import datetime,difflib,hashlib,json,subprocess
root=Path('D:/Layrs/layrs');tmp=Path('D:/Layrs/tmp')
prior=root/'.layrs-local/validation/provider-ordinary-staging-box-20261028-r79/source'
p='crates/layrs-store-local/src/projection/'
v=p+'provider/'
s=v+'bootstrap/preparation/activation/'
changed=[v+x for x in [
 'destination_ready.rs','destination_ready/autonomous.rs',
 'destination_ready/autonomous/family_read.rs','destination_ready/autonomous/ordinary_family_publication.rs',
 'destination_ready/ordinary_tests.rs','managed_export.rs','managed_export/family_reopen.rs',
 'managed_ready_reopen.rs','managed_ready_reopen/ordinary_source.rs','managed_ready_reopen/ordinary_family.rs',
]]+[s+x for x in ['session.rs','session/managed_ordinary_source_publication_tests.rs','session/managed_ordinary_fresh_family_tests.rs']]
context=[v+x for x in [
 'destination_ready/ordinary.rs','destination_ready/autonomous/inventory.rs',
 'destination_ready/historical.rs','managed_export/staging_reopen.rs',
 'managed_export/ready.rs','managed_export/ready_data.rs','managed_export/reserve_plan.rs',
 'managed_export/reservation.rs','managed_export/content.rs','managed_export/image.rs',
 'managed_ready_reopen/ordinary_publication.rs','managed_ready_reopen/pins.rs',
 'database_io.rs','database_io/bare.rs','database_io/sidecars.rs',
 'ordinary_transition/publication.rs','admitted_ordinary.rs',
 'import_validation/source.rs','process_profile/tests/child.rs',
 'database_io/tests/fresh_ordinary_support.rs',
]]+[p+'shared/'+x for x in ['admitted_catalog.rs','admitted_catalog/export.rs','admitted_catalog/export_publication.rs','admitted_catalog/terminal_ready.rs']]+[s+'session/'+x for x in ['managed_ordinary_family_ready_tests.rs','managed_ordinary_installing_tests.rs','managed_ordinary_fresh_staging_tests.rs']]
for path in changed+context: assert (root/path).is_file(),path
snapshot=tmp/'provider-ordinary-fresh-family-review-r82-source'
snapshot.mkdir(exist_ok=False)
files,diff=[],[]
for path in sorted(set(changed+context)):
 raw=(root/path).read_bytes();target=snapshot/path
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 files.append(dict(path=path,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),changed=path in changed))
 if path in changed:
  old=(prior/path).read_bytes() if (prior/path).is_file() else b''
  diff.extend(difflib.unified_diff(old.decode().replace('\r\n','\n').splitlines(True),raw.decode().replace('\r\n','\n').splitlines(True),fromfile='r79/'+path,tofile='r82/'+path))
diff_path=tmp/'provider-ordinary-fresh-family-review-r82.diff'
with diff_path.open('x',encoding='utf-8') as f:f.write(''.join(diff))
manifest=dict(head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip(),branch='feature/worktrees-partial-vfs',baseline=str(prior),recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=files,changed=changed,diffSha256=hashlib.sha256(diff_path.read_bytes()).hexdigest(),scope='Fresh B Staging plus C8 private Ready and family Initializing -> exact family Ready CAS, full actual-B-backed reconstruction, physically retained fresh B image and C CAS/checkout proofs. Terminal/autonomous Ready strict gates remain. Two separate ignored native recipes and extended family SQL recipe.',build='Not compiled or executed. ROOT40925 runs retained r79 executable source10 recipe r81; do not touch that session, build, or run any SQL/test/native.')
path=tmp/'provider-ordinary-fresh-family-review-r82-inputs.json'
with path.open('x',encoding='utf-8') as f:json.dump(manifest,f,indent=2)
print(json.dumps(dict(manifest=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),diffSha256=manifest['diffSha256'],files=len(files),changed=len(changed))))
