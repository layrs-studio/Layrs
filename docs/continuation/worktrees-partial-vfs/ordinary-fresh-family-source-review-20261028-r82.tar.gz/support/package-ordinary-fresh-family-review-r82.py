from pathlib import Path
import datetime,hashlib,io,json,tarfile
root=Path('D:/Layrs/layrs');tmp=Path('D:/Layrs/tmp')
prefix='provider-ordinary-fresh-family'
manifest_path=tmp/f'{prefix}-review-r82-inputs.json'
manifest=json.loads(manifest_path.read_bytes())
frozen=tmp/f'{prefix}-review-r82-source'
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
entries={}
for e in manifest['files']:
 p=frozen/e['path'];assert pin(p)=={k:e[k] for k in ['bytes','sha256']}
 entries['reviewed-source/'+e['path']]=p
for name in [f'{prefix}-review-r82-inputs.json',f'{prefix}-review-r82.diff',f'{prefix}-critical-review-r82.json',f'prepare-ordinary-fresh-family-review-r82.py']:
 entries['support/'+name]=tmp/name
entries['support/'+Path(__file__).name]=Path(__file__)
changed=[]
for e in manifest['files']:
 if pin(root/e['path'])!={k:e[k] for k in ['bytes','sha256']}:
  changed.append(e['path'])
assert len(changed)==1 and changed[0].endswith('managed_ordinary_fresh_family_tests.rs')
p=changed[0];old=(frozen/p).read_text();new=(root/p).read_text()
assert new==old.replace('//! ACK follows a successful OS close; no OS close failure, crash or owner-loss\n//! recovery is qualified. Positive deletion/nested checkout remain separate.','//! ACK follows an actual SQLite connection close returning success; native\n//! xClose/OS-close outcomes, crash and owner-loss recovery are not qualified.\n//! Positive deletion/nested checkout remain separate.').replace('requires actual successful physical family writer close','requires actual SQLite family writer connection close returning success')
entries['root-wording-correction/'+p]=root/p
record=dict(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='SOURCE ONLY fresh family Ready reconstruction/publication r82. Independent review plus ROOT mechanical correction of R82-CV-01 comment/assertion text; no behavioral changes after review.',limitations=['Candidate uncompiled and unexecuted. No runtime or release qualification.','SQLite successful connection close is not native xClose or OS-close proof.','ROOT40925 retained r79 source10 test is separate and does not exercise this candidate.'],files=[dict(path=n,**pin(p)) for n,p in sorted(entries.items())])
dest=root/'docs/continuation/worktrees-partial-vfs'
archive=dest/'ordinary-fresh-family-source-review-20261028-r82.tar.gz'
inventory=dest/'ordinary-fresh-family-source-review-inventory-20261028-r82.json'
assert not archive.exists() and not inventory.exists()
data=json.dumps(record,indent=2).encode()
with tarfile.open(archive,'x:gz') as tar:
 info=tarfile.TarInfo('manifest.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
 for n,p in sorted(entries.items()):tar.add(p,arcname=n,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for e in record['files']:
  data=tar.extractfile(e['path']).read()
  assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256']
record['archive']=dict(path=archive.name,**pin(archive))
with inventory.open('x',encoding='utf-8') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(archive=str(archive),files=len(entries)+1,**pin(archive))))
