"""Execute only after ROOT confirms terminal r84 and successful r87 builds.

This binds a new executable and exact source closure. It runs no SQL/native
recipe; execution uses a separate serial runner and fresh disposable roots.
"""
from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, sys

assert sys.argv[1:] == ['--root-accept-reviewed-private-ready']
root = Path('D:/Layrs/layrs')
tmp = Path('D:/Layrs/tmp')
prior = root / '.layrs-local/validation/provider-ordinary-fresh-family-20261028-r84'
out = root / '.layrs-local/validation/provider-ordinary-fresh-private-ready-20261028-r88'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pin = lambda p: dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))
normal = lambda p: p.read_text(encoding='utf-8').replace('\r\n', '\n')
fix_path = tmp / 'ordinary-private-ready-compile-correction-r87.json'
fix = read(fix_path)
assert pin(Path(fix['source']['path'])) == fix['source']
assert pin(Path(fix['diff']['path'])) == fix['diff']
fix_relative = 'crates/layrs-store-local/src/projection/provider/destination_ready/ordinary_tests.rs'
prior_result = read(prior / 'ordinary-fresh-family-results.json')
assert len(prior_result['results']) == 7 and all(r['exit'] == 0 for r in prior_result['results']), 'r84 must be terminal PASS before this release'
head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD']).decode().strip()
assert head == 'f01f6b9518b71a3cfc309be3a2911c51599f2e79'
reviews = []
for prefix, revision, digest in [
    ('provider-ordinary-fresh-private-ready', 'r85', 'ed6167d858eec42dda2038e75ed821d43a62071af4266114d82dee5e6a0b3c1f'),
    ('provider-ordinary-ready-ordering', 'r86', 'd9684350c299384cc3006d42c1a60efa45e58671d5a4a996de32a86ccce6275d'),
]:
    manifest_path = tmp / f'{prefix}-review-{revision}-inputs.json'
    report_path = tmp / f'{prefix}-critical-review-{revision}.json'
    manifest, report = read(manifest_path), read(report_path)
    assert sha(manifest_path) == digest
    assert not report['findings'], ('unresolved review finding', revision)
    assert sha(tmp / f'{prefix}-review-{revision}.diff') == manifest['diffSha256']
    frozen = tmp / f'{prefix}-review-{revision}-source'
    for e in manifest['files']:
        assert sha(frozen / e['path']) == e['sha256'], e['path']
        if revision == 'r86':
            if e['path'] == fix_relative:
                assert normal(root / e['path']) == normal(frozen / e['path']).replace(
                    'let checkout_journal::FileState::Published { inode } = state else {',
                    'let checkout_journal::FileState::Published { inode, .. } = state else {')
            else:
                assert sha(root / e['path']) == e['sha256'], ('live drift', e['path'])
    reviews.append((prefix, revision, manifest_path, report_path, manifest))
build = tmp / 'provider-ordinary-fresh-private-ready-build-r87b.log'
check = tmp / 'provider-ordinary-fresh-private-ready-check-r87b.log'
for path in [build, check]:
    raw = path.read_bytes()
    text = raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert 'Finished `' in text and 'error[' not in text, path
audit = tmp / 'provider-ordinary-fresh-private-ready-host-audit-r88.py'
text = normal(tmp / 'provider-ordinary-fresh-family-host-audit-r84.py').replace('r84', 'r88').replace('provider-ordinary-fresh-family', 'provider-ordinary-fresh-private-ready')
text = text.replace('Fresh actual-B-backed family publication candidate reviewed r82; only ROOT comment/assertion wording correction afterward. Build/check r83 PASS, plus source10 test-witness correction; new runtime qualification pending.',
                    'Fresh private Ready r85 and retained Ready failure-order correction r86, with test-only phase timers and ROOT one-line SQL test pattern compilation correction; build/check r87b PASS. New runtime qualification pending.')
with audit.open('x', encoding='utf-8') as f:
    f.write(text)
subprocess.run(['py', str(audit), 'r88'], check=True)
host = read(out / 'host-disposition.json')
assert len(host['sourceClosure']) == 669
changes = []
for e in host['sourceClosure']:
    rel = Path(e['path']).relative_to(root)
    assert sha(root / rel) == e['sha256'] == sha(out / 'source' / rel)
    if not (prior / 'source' / rel).is_file() or normal(prior / 'source' / rel) != normal(out / 'source' / rel):
        changes.append(rel.as_posix())
expected_changes = set(reviews[0][4]['changed']) | set(reviews[1][4]['changed'])
assert set(changes) == expected_changes and len(changes) == 17, changes
runner = tmp / 'provider-ordinary-fresh-private-ready-run-r88.py'
text = normal(tmp / 'provider-ordinary-fresh-family-run-r84.py').replace('r84', 'r88').replace('ordinary-fresh-family', 'ordinary-fresh-private-ready')
lines = text.splitlines(True)
for i, line in enumerate(lines):
    if "assert name.startswith('projection::')" in line:
        lines[i] = "    assert name.startswith('projection::') and recipe['outer_seconds'] <= 3660\n"
with runner.open('x', encoding='utf-8') as f:
    f.write(''.join(lines))
recipes = []
def recipe(name, child, scope):
    recipes.append(dict(name='projection::provider::' + name, ignored=True,
                        child_seconds=child, outer_seconds=child + 60, scope=scope))
for name, scope in [
    ('database_io::tests::strict_read::strict_nested_read_preserves_callback_failure_without_concluding_filesystem_probes', 'Strict nested error propagation and no concluding filesystem probes.'),
    ('database_io::tests::strict_read::strict_nested_read_preserves_primary_and_actual_busy_close_without_concluding_probes', 'Actual SQLite BUSY close preserves the primary failure and stops concluding probes; owned child retains handle until exit.'),
    ('destination_ready::ordinary_tests::ordinary_ready_writer_preserves_restore_history_replays_readonly_and_refuses_corruption', 'Private Ready SQL, exact history/suffix/readonly replay after boxed preparation change.'),
    ('destination_ready::ordinary_tests::ordinary_family_publication_authenticates_actual_ready_changes_one_row_and_replays_readonly', 'Extended actual Staging finalizable reader, exact ManifestId, journal completion, full family/refusal/query-only checks and separate Ready branch.'),
]:
    recipe(name, 120, scope)
n = 'bootstrap::preparation::activation::session::'
for name, scope in [
    ('managed_ordinary_fresh_private_ready_refuses_changed_b_and_c_then_appends_exact_suffix_and_replays_without_writer', 'Fresh B/C exclusive owners, complete actual Staging journal, B/C drift refusal, exact private Ready only, fresh no-writer replay and family handoff inspection; monotonic phase timings.'),
    ('managed_ordinary_fresh_private_ready_withheld_sqlite_close_ack_reopens_ready_after_explicit_holder_release', 'Separate fresh fixture, withheld ACK after SQLite close success, retained primary/holders, no later observed probes, explicit release and fresh Ready replay; phase timings.'),
]:
    recipe(n + 'managed_ordinary_fresh_private_ready_tests::' + name, 3600, scope)
recipe(n + 'managed_ordinary_ready_tests::managed_ordinary_ready_replays_withheld_private_close_ack_without_promoting_b_or_family', 3000,
       'Retained private Ready ACK regression: positive read-control routes, original error, zero observed post-ACK probes, pins/full witnesses and same-owner no-writer replay.')
recipe(n + 'managed_ordinary_family_ready_tests::managed_ordinary_family_ready_updates_then_replays_read_only_without_promoting_b_or_admitting_c', 3000,
       'Retained family Updated success, acknowledged SQLite close and fresh catalog readback; only member changes and no-writer replay.')
recipe(n + 'managed_ordinary_family_ready_tests::managed_ordinary_family_ready_replays_withheld_catalog_close_ack_without_promoting_b_or_admitting_c', 3000,
       'Retained family ACK regression with original error, zero later observed probes, preserved pins/witnesses and same-owner replay.')
bindings = dict(runner=pin(runner), host_audit=pin(audit), release_script=pin(Path(__file__)),
                build=pin(build), workspace_check=pin(check), prior_results=pin(prior / 'ordinary-fresh-family-results.json'),
                root_compile_fix=pin(fix_path), root_compile_diff=pin(Path(fix['diff']['path'])),
                failed_build=pin(tmp / 'provider-ordinary-fresh-private-ready-build-r87.log'),
                prior_release=pin(prior / 'ordinary-fresh-family-source-release.json'),
                phase_analyzer=pin(tmp / 'analyze-native-phase-log.py'),
                r86_review_archive=pin(root / 'docs/continuation/worktrees-partial-vfs/ordinary-ready-ordering-source-review-20261028-r86.tar.gz'),
                r85_review_archive=pin(root / 'docs/continuation/worktrees-partial-vfs/ordinary-fresh-private-ready-source-review-20261028-r85.tar.gz'))
for prefix, revision, manifest_path, report_path, _ in reviews:
    bindings[revision + '_manifest'] = pin(manifest_path)
    bindings[revision + '_critical_review'] = pin(report_path)
    bindings[revision + '_diff'] = pin(tmp / f'{prefix}-review-{revision}.diff')
saved = out / 'bound-inputs'
saved.mkdir(exist_ok=False)
for name, entry in bindings.items():
    shutil.copyfile(entry['path'], saved / (name + '-' + Path(entry['path']).name))
release = dict(decision='released', revision='r88', recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_head=head, artifact_audit=host['executable'],
    reviewer='Independent critical source reviews r85/r86 plus ROOT integrated acceptance and mechanical verification of the one-line SQL test compilation correction.',
    source_review='All669 live/retained inputs match. Exactly17 source paths differ from retained r84, the union of reviewed r85/r86 changes plus the bound ROOT pattern correction within an already changed test file. Build/workspace check r87b PASS. Runtime pending at release.',
    limitations=['Source reviews do not establish runtime success or time/stack bounds.',
                 'Native recipes use flat README checkout. No fresh private positive deletion/nested or B10 claim.',
                 'ACK withholding after SQLite connection-close success is not an actual native xClose/OS close failure or crash/owner-loss test.',
                 'Phase timings are diagnostics; nested scopes overlap and END is not a success verdict.',
                 'The full Worktrees/partial-VFS programme remains open.'],
    recipes=recipes, input_bindings=bindings)
path = out / 'ordinary-fresh-private-ready-source-release.json'
with path.open('x', encoding='utf-8') as f:
    json.dump(release, f, indent=2)
print(json.dumps(dict(release=pin(path), source_inputs=len(host['sourceClosure']), changed=len(changes), recipes=len(recipes))))
