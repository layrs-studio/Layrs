# Metadata-only Provider transition collector: implementation proposal

This NEW three-file bundle implements the callable client collector and its
revalidation path. It is based on HEAD
`6b1f5632bd7f6092226d57e3c813033a82bcfc98`, branch
`feature/worktrees-partial-vfs`. It is not a checkout and has no Cargo project.
Nothing was applied to `D:/Layrs/layrs`. Both existing C13 proposal directories
were left untouched. ROOT99703/r98 processes were not queried or disturbed.

The collector performs real authenticated HTTPS work when called by a future
host. This task only authored source and inspected/formatted it. It did not
execute that HTTPS work, fixtures, tests, Cargo, a build, SQL, native operations,
process polling or a Git command/mutation. No compilation, runtime qualification,
independent verification, C13/C14 activation or completed conversion is claimed.

## Files and public interface

The full replacement files are under `files/<repo-relative>`:

* `crates/layrs-client-core/src/native_scm/remote/provider_observation.rs` NEW:
  implementation, public request/result DATA and bounds.
* `crates/layrs-client-core/src/native_scm/remote/provider_observation_tests.rs`
  NEW: counted local TLS fixtures calling the actual public APIs.
* `crates/layrs-client-core/src/native_scm/remote.rs`: one module declaration and
  one export block only. No `download_refresh.rs` change is needed.

Public import location is `layrs_client_core::native_scm::remote`. The existing
`native_scm::NativeRemote` re-export also receives these inherent methods:

```rust
NativeRemote::observe_provider_transition(
    &self,
    request: &ProviderTransitionObservationRequest<'_>,
) -> Result<ObservedProviderTransitionScope, NativeRemoteError>;

NativeRemote::revalidate_provider_transition_scope(
    &self,
    scope: &ObservedProviderTransitionScope,
) -> Result<(), NativeRemoteError>;
```

Source uses the existing transparent `RemoteResult<T>` alias. The collector is
called directly by the first method; the result is not an uncalled helper. The
second method performs new HTTP and validates the result's exact remote binding.

Exports added:

* `ProviderTransitionObservationStrategy::{PreservedEpoch,
  ReobservedExpandedScope}`.
* `ProviderTransitionSourceAnchor`: public DATA fields `store_id: StoreId`,
  `worktree_id: WorktreeId`, `source_prefix_id: ObjectId`, `generation: u64`,
  `snapshot_digest: String`, `snapshot_parent_digest: Option<String>`,
  `selection_generation: u64`, `selection_snapshot_digest: String`,
  `selection_digest: String`, `capture_count: u64`,
  `capture_head: Option<ObjectId>`, `effective_image_digest: String`.
  Snapshot/selection/image digests use Store's lowercase raw 64-hex form;
  prefix/capture commitments use the typed `blake3:` form. Generation, parent,
  selection-generation and capture-count/head shape are checked. These checks
  are syntax/consistency checks, never live source authentication.
* `ProviderTransitionDescriptor { path: RepoPath, manifest: FileManifest }`:
  canonical metadata DATA with no chunk bytes/payloads or availability claim.
* `ProviderTransitionObservationRequest<'a>`: borrowed `source`, `origin`,
  `space_id: &SpaceId`, `principal_id: &PrincipalId`,
  `original: &ProjectionSnapshot`, `original_selection: &ProjectionSelection`,
  `expanded_selection: &ProjectionSelection`,
  `explicit_absence_paths: &[RepoPath]`,
  `historical_descriptors: &[ProviderTransitionDescriptor]`, strategy, and
  `control: Option<&NativeTransferControl>`. Exact old/expanded selections must
  already be normalized. Expansion must be monotonic. Explicit absence anchors
  must be sorted, unique and selected; all are freshly classified. Historical
  descriptors must be sorted, unique, canonical and match original exact file
  targets. They are optional DATA; the host must supply any historical metadata
  its later reconciliation/preservation requires.
* `ObservedProviderTransitionScope`: owned, private fields and no public
  constructor, `Clone`, `Debug`, `Serialize` or `Deserialize`. Only a successful
  complete collector constructs it. Its getters expose read-only DATA, not a
  Store write capability or a server-held authority lease.

Result getter contract:

| Getter | Return |
| --- | --- |
| `source_anchor()` | `&ProviderTransitionSourceAnchor` |
| `origin()` | `&str`, normalized origin without trailing slash |
| `space_id()` | `&SpaceId` |
| `principal_id()` | `&PrincipalId` |
| `strategy()` | `ProviderTransitionObservationStrategy` |
| `original_snapshot()` | `&ProjectionSnapshot`, unchanged historical observation |
| `original_selection()` | `&ProjectionSelection` |
| `selection()` | `&ProjectionSelection`, normalized expanded intent |
| `snapshot()` | `&ProjectionSnapshot`, fresh selected structural DATA, never Materialized |
| `step_id()` | `&StepId` |
| `root_tree_id()` | `&TreeId` |
| `policy_set_id()` | `&ObjectId`, fresh observed policy |
| `authorization_epoch()` | `u64`, fresh observed epoch |
| `namespace()` | `&[layrs_sync::v3::ProjectionEntry]`, complete enumeration sorted by exact path |
| `access()` | `&[ProjectionAccessEntry]`, fresh exact rows for the entire enumerated namespace plus every old/selection/absence anchor |
| `denied_absence_paths()` | `&[RepoPath]`, selected unprotected unreadable target=None paths, separate from snapshot Absent rows |
| `protected_frontiers()` | `&[RepoPath]`, minimal original explicit Reserved Tree boundaries |
| `descriptors()` | `&[ProviderTransitionDescriptor]`, exactly readable selected visible File targets |
| `historical_descriptors()` | `&[ProviderTransitionDescriptor]`, supplied old metadata retained as history |
| `explicit_absence_paths()` | `&[RepoPath]` |

`access()` retains current exact denial/read-only DATA for original and excluded
paths as well as new paths. It includes rows beneath retained protected
frontiers even though such rows cannot become snapshot slots or descriptors.
Original revoked-content/dirty-work classification remains Store reconciliation's
responsibility. Nothing copies an old writable flag into the fresh observation.

## Actual request sequence

All network work precedes Store SQL/operation gates. No Store object, SQL handle,
operation guard or local source-validation callback enters the API.

1. Validate source DATA shape, configured HTTPS origin, bounded original
   snapshot/path semantics, normalized monotonic selections, absence anchors
   and historical descriptor identities before sending a request.
2. `GET /v3/spaces/{space}/bootstrap`. Require source principal and space.
   PreservedEpoch requires the exact old policy AND epoch. ReobservedExpandedScope
   permits fresh policy/epoch while retaining the old observation, requires a
   nondecreasing epoch, and refuses a policy change without epoch advancement.
3. `POST /v3/spaces/{space}/projection` with the exact original Step, expected
   policy/epoch, limit 200 and then each returned cursor, until terminal cursor.
   Require identical principal/space/Step/root/policy/epoch, contiguous offsets,
   unique paths, advancing nonempty cursors and no cursor cycles. Validate the
   whole bounded namespace, every structural parent and platform aliases BEFORE
   filtering selection. The root is compared on every page, including an empty
   namespace. Directory rights are never descendant grants.
4. Form a sorted unique union of ALL enumerated paths, ALL original snapshot
   paths, old/expanded exact and subtree selection anchors, and explicit absence
   anchors. For every <=200-path batch, perform the existing
   `GET /v3/auth/whoami` followed by
   `POST /v3/spaces/{space}/projection/access`. Require exact cardinality/order,
   principal, root and fixed Step/policy/epoch. Compare every enumerated target,
   executable mode and right with its page row; compare every old target/mode
   with the immutable historical root. Present access targets omitted from
   enumeration are refused. Explicit absences that are present are refused.
   This phase always runs, including for supplied cached manifests.
5. Construct the selected snapshot. Preserve explicit old protected Tree
   frontiers conservatively and suppress their descendant slots/descriptors.
   A directory's own denial does not imply its child is denied: ordinary
   directories remain structural Unavailable metadata with exact writable DATA;
   their independent read decision remains in `access()`. Unreadable leaves are
   Reserved. Readable absences alone become Absent, with exactly the observed
   writable flag. Denied absences remain separate; ambiguous denied-ancestor /
   visible-descendant coverage is refused rather than inventing a grant.
6. For EACH readable selected visible file, `POST
   /v3/spaces/{space}/fetch-plans` with exactly one rooted
   `FetchClaim::File { file_id, root: Step { step_id }, repo_path,
   preferred_manifest_ids }`. The target FileId comes from fresh exact access.
   Validate the complete plan shape, selection FileId/ManifestId, exact echoed
   claim and descriptor closure. Explicitly compare plan AND capability
   principal/epoch/space/client to the bootstrap binding; `fetch_plan` alone
   does not enforce `Binding.observed` epoch. Compare capability request/plan,
   origin and descriptor identity too. The server's internal `claim_digest` is
   opaque to the wire client: require one consistent digest across the closure
   and retain it unchanged on renewal; do not hash the wire claim as a substitute.
7. Reuse old canonical manifest metadata only if a fresh exact-path access AND
   fresh File plan select that exact ManifestId and all descriptor/chunk metadata
   agree. Otherwise use `download_object_from_store` with ONLY the selected
   FileManifest capability: `GET /v3/transfers/downloads` (possibly bounded ranges
   for that metadata object). Verify canonical bytes, ManifestId, FileId, target,
   descriptor length and exact unique chunk identities/lengths. No Chunk
   capability is ever downloaded. No `fetch_authorized_file`, `fetch_visit`,
   whole-file closure hydration or `expand_projection_selection` is called.
8. On an expired/unavailable manifest capability, the existing bounded transfer
   loop can request a fresh File plan with the SAME exact claim. Recheck the
   binding and require identical manifest selection, all closure descriptors,
   claims, opaque claim digests and range support. Token/plan/request/expiry can
   renew, but observation/descriptor identity cannot. Resume/cache support is
   the existing secret-free metadata-object implementation; capabilities remain
   local temporaries and never enter the returned DATA or a debug/log value.
9. Final `GET /v3/spaces/{space}/bootstrap`; reject any principal/space/policy/
   epoch drift. Cancellation checks surround HTTP through existing
   NativeTransferControl boundaries and bounded loops. No commit begins and the
   caller retains cancellation ownership for later revalidation.

The separate revalidation method checks origin first, then does bootstrap ->
projection page (limit 1 at the retained exact Step/root/policy/epoch) -> bootstrap.
It rejects any binding drift and retains the same cancellation control. It does
not recollect all metadata, acquire a Store gate, authenticate a local source or
hold a server transaction.

The successful two-file TLS recipe asserts this complete sequence:
bootstrap -> page -> page -> page -> whoami -> access -> File plan -> manifest
GET -> File plan -> manifest GET -> final bootstrap -> revalidation bootstrap ->
revalidation page -> revalidation final bootstrap. No Chunk GET is allowed.
These assertions are authored, not executed evidence.

## Bounds and trust limits

Namespace and exact-access union each have at most 100,000 paths, 4,096 bytes per
path, depth 128 and 8 MiB aggregate path text. Each collection is charged a
conservative 64 MiB prefix-index work budget before core index construction.
Cursor text has an additional 8 MiB aggregate bound. Pages and access requests
are <=200 entries; original/selection/absence/descriptor inputs are bounded
before large normalization/encoding. Canonical manifest metadata is <=64 MiB in
aggregate per old/fresh descriptor collection, with <=10,000 chunk references
per manifest and the existing stricter complete-plan/object limits. These are
logical bounds, not a measured peak RSS claim.

Enumeration trusts the authenticated service's terminal-page contract. The
current wire protocol has no signed total-entry commitment or server lease.
The client detects malformed pagination, absent structural parents and missing
known/explicit scope through independent exact-access correlation; it cannot
prove that a dishonest service omitted an otherwise unknown leaf from BOTH
namespace and access results. No cryptographic namespace completeness claim is
made beyond the actual authenticated endpoint semantics.

The final bootstrap fence is a before/after observation. Authority can change
after it and before a local commit; no continuous authority or remote atomicity
is promised. The new APIs remain opt-in and do not activate C13/C14, remount,
change bootstrap codecs, loosen old selection guards, write Store metadata or
grant content availability.

## Pending Store caller and denied-row contract

The missing production Provider8 conversion entry and Store acceptance adapter
remain outside this ownership. No Store/provider/shared file or private Store
type is introduced into the client API. No generic validator callback is called
or described as authority.

Required future host sequence:

1. Under the appropriate live source reader, authenticate the exact prefix and
   independently copy its identity, version, selection-row anchor, capture
   count/head, effective image commitment, original snapshot/selection and any
   historical descriptors needed for preserved/revoked work. Supply detached
   DATA to this request. Release every Store SQL/operation gate before HTTP.
2. Call `observe_provider_transition`. Perform any further remote acquisition
   outside the Store gates, then call `revalidate_provider_transition_scope`.
3. Reacquire the actual source holder/reader and local operation gates. Recheck
   EXACT equality with `scope.source_anchor()` for source prefix digest, Store
   and Worktree IDs, generation, snapshot digest/parent, selection generation /
   snapshot digest / selection digest, capture count/head and effective image
   digest. Recompute/check the source snapshot and selection commitments using
   Store's own codec/digest rules; also match origin, principal, space, Step,
   root, semantics and original snapshot/selection. A changed source refuses
   before any reservation, journal, SQL effect, native operation or remount.
   The client cannot test or authenticate this live match.
4. The pending client-neutral Store DATA bridge must accept exactly: the
   independently authenticated current source; the fresh `snapshot()` and
   `selection()`; converted `descriptors()` (path/FileManifest); exact separate
   denied-absence paths plus their complete exact-access coverage and policy/
   epoch binding; strategy; and owned historical/recovery metadata as required.
   Map into Store's current private `SourceObservationData`,
   `AuthorityObservationData::{PreservedEpoch, ReobservedExpandedScope}` and
   `ObservationCoverageData { denied_paths }` only inside that Store adapter.
   Existing `TransitionObservationData::normalize` is private DATA normalization,
   not an exported live acceptance API or proof of enumeration/authority.
5. Persist an exact denied-row/coverage commitment under the same accepted
   source + fresh observation binding before any replayable effects. Retain
   target=None/read=false as denial, never Absent or writable. Exact existing
   denied/read-only rows stay distinguishable through `access()`; a structural
   directory row's snapshot state must not be read as a grant to children.
   The current durable snapshot/bootstrap codecs do not represent denied
   absence, and this task does not change them. Until the durable transition
   writer and replay verifier accept these exact rows and commitments, that
   Store integration must explicitly refuse the case. Do not erase denials,
   reinterpret them as absences, or silently install the old initial snapshot.

Original revoked-content reconciliation, durable denied rows, source protection,
source/destination publication, Ready admission, replay and actual conversion
remain ROOT/C13 integration work. Client fixtures do not test source-anchor
acceptance, SQL gates, durable replay, native autonomy or a continuous lease.

## Source verification and self-review

`base-checks.json` records the pinned HEAD/branch, original physical checkout
hash, exact HEAD blob hash and supplied input hashes. `source-checks.json`
records all changed-file base/output hashes, authored test names and checks.
`manifest.sha256.json` seals the proposal files, patch and documentation.

Actual checks: inspected real signatures/visibility in core projection,
projection/page/access, fetch-plan validation, download/renewal/cancellation,
server claim digest generation and the private Store observation interface.
Used `rustfmt --edition 2021 --config skip_children=true`, then `rustfmt --check`
on all three proposal files: exit 0. Read Git objects directly, validated their
SHA1 identities, checked the exact HEAD tree and SHA256 baselines, generated
the unified patch and replayed each hunk in memory against that exact base.
New paths are absent in the base and checkout; the owned existing checkout
file's physical SHA256 remains unchanged. No Git command was used. ROOT may
concurrently edit unrelated tests; no whole-tree clean-state claim is made.

Self-review corrected the initial wire/internal claim-digest mismatch, retained
the cancellation control for revalidation, bounded cursor aggregates, checked
cross-view aliases/structural parents, rejected page/access rights drift and
kept denied absences outside the canonical snapshot. The actual diff was
reviewed for module visibility, source-anchor DATA semantics, cached grant
shortcuts, capability renewal binding, zero Chunk requests and ownership scope.
This is implementer self-review, not independent verification or typechecking.

All test functions are listed verbatim in `source-checks.json`; none was run.
They cover both strategies and policy history, historical mismatch/rollback,
bootstrap/page/access/manifest/renewal/final/revalidation drift, principal/space/
Step/root binding, duplicate/nonadvancing/cyclic pagination, structural omissions,
200-path batches, cached revoked/read-only files, genuine versus denied absence,
invalid absence write grants, protected frontiers, directory/child rights,
manifest substitution, plan/capability epoch drift, cancellation and zero Chunk
GETs through the real public APIs.
