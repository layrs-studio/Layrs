# ROOT source corrections after critical review

The original proposal and its exact review remain unchanged under
`D:/Layrs/tmp/provider-transition-observation-source-proposal/` and
`D:/Layrs/tmp/provider-transition-observation-critical-review.json`.
`reviewed-input/` retains its manifest, patch, metadata and review.

This candidate corrects POBS-001: the path-prefix iterator now chains the
`&str` sentinel `"/"`, matching `match_indices`' Item. This is the only production
code change relative to the reviewed candidate. No compilation is claimed.

ROOT also addressed the small authored-test coverage notes directly:

- The input test now includes 100001 sorted, unique valid absence paths and
  requires refusal before any HTTP. It covers the count bound; aggregate text,
  index-work and object-metadata boundary qualification remains separate.
- The cached-plan epoch test's name now states only its actual epoch check.
  It does not claim a cached alternate-manifest substitution case.
- Renewal cases retain the malformed-descriptor case and additionally change
  both manifest selection and capability descriptors consistently; other cases
  change all claim digests consistently or change range support. The fixture
  first asserts `ValidateV3` and `validate_fetch_descriptors` accept each of
  those second plans, then the collector must still refuse the renewal.
- Normal authenticated endpoints now require the expected fixture bearer.
  The fixture claim digest uses a separate opaque domain instead of the wire
  claim hash, protecting the collector's opaque-digest treatment.

There are still 21 authored test functions, with additional cases inside them.
No tests, TLS fixture, build, SQL, native operation or network work has run.
Rustfmt/check passes for the three Rust outputs. Main checkout is untouched.
The original critical review's source invariants still concern the old frozen
candidate; these small changes are ROOT implementation review, not a second
independent review or qualification. Compilation and actual test results remain
required before acceptance.

The original handoff remains the interface contract. Production conversion,
live prefix/image/source validation, denied-row durability, B protection, C Ready,
autonomy and Provider expansion are not implemented or accepted by this bundle.
