﻿import datetime, hashlib, json, os, pathlib, shutil, struct, sys, uuid

BASE = pathlib.Path('D:/Layrs/layrs')
revision = sys.argv[1] if len(sys.argv)>1 else 'r1'
assert revision in ['r1','r2','r3','r4','r5','r6','r7','r8','r9','r10','r11','r12','r13','r14','r15','r16','r17','r18','r19','r20','r21','r22','r23','r24','r25','r26','r27','r28','r29','r30']
OUT = BASE / ('.layrs-local/validation/provider-family-publication-20261027-'+revision)
OUT.mkdir(exist_ok=False)
HOST = BASE / '.layrs-local/validation/l5-store-stage1b-first-live-r3-bdd774e4086b4e519ebbd364368c2cc6/owned-test-host-supplement-r1'
EXE = BASE / 'target/debug/deps/layrs_store_local-c67321233121e545.exe'
PDB = EXE.with_suffix('.pdb')
def pin(p):
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(name, value):
    with (OUT/name).open('x',encoding='utf-8') as f: json.dump(value,f,indent=2)
for p in [EXE, PDB]: shutil.copyfile(p, OUT/p.name)
exe, pdb = EXE.read_bytes(), PDB.read_bytes()
pe=struct.unpack_from('<I',exe,0x3c)[0]
assert exe[pe:pe+4]==b'PE\0\0'
nsect=struct.unpack_from('<H',exe,pe+6)[0]; optsize=struct.unpack_from('<H',exe,pe+20)[0];opt=pe+24
assert struct.unpack_from('<H',exe,opt)[0]==0x20b
sections=[]
for i in range(nsect):
    off=opt+optsize+i*40;vsize,rva,size,raw=struct.unpack_from('<IIII',exe,off+8)
    sections.append((rva,max(vsize,size),raw))
def offset(rva):
    for base,size,raw in sections:
        if base<=rva<base+size:return raw+rva-base
    raise AssertionError(('unmapped RVA',rva))
debugrva,debuglen=struct.unpack_from('<II',exe,opt+112+6*8);records=[]
for off in range(offset(debugrva),offset(debugrva)+debuglen,28):
    kind,size,_,raw=struct.unpack_from('<IIII',exe,off+12)
    if kind==2 and exe[raw:raw+4]==b'RSDS':
        records.append(dict(guid=str(uuid.UUID(bytes_le=exe[raw+4:raw+20])),age=struct.unpack_from('<I',exe,raw+20)[0]))
assert len(records)==1
assert pdb.startswith(b'Microsoft C/C++ MSF 7.00\r\n\x1aDS\0\0\0')
page,free,count,dsize,reserved,map_page=struct.unpack_from('<6I',pdb,32)
indices=struct.unpack_from('<'+'I'*((dsize+page-1)//page),pdb,map_page*page)
directory=b''.join(pdb[i*page:(i+1)*page] for i in indices)[:dsize]
streams=struct.unpack_from('<I',directory)[0];sizes=struct.unpack_from('<'+'I'*streams,directory,4);cursor=4+streams*4
for i,size in enumerate(sizes):
    pages=0 if size==0xffffffff else (size+page-1)//page
    blocks=struct.unpack_from('<'+'I'*pages,directory,cursor);cursor+=pages*4
    if i==1:stream1=b''.join(pdb[b*page:(b+1)*page] for b in blocks)[:size]
assert records[0]==dict(guid=str(uuid.UUID(bytes_le=stream1[12:28])),age=struct.unpack_from('<I',stream1,8)[0])
startup=[]
for e in json.loads((HOST/'rust-startup-source-manifest.json').read_bytes())['files']:
    p=HOST/'rust-1.85.0-sources'/e['sourcePath'];record=pin(p)
    assert record['sha256']==e['sha256'].lower()
    assert bytes.fromhex(e['sha256']) in pdb
    startup.append(record)
old=json.loads((HOST/'retention-manifest.json').read_bytes())
identical=[]
for i in [17,18,19,20,26,27,28,34]:
    e=old['pins'][i];p=pathlib.Path(e['path']);record=pin(p)
    assert record['sha256']==e['sha256'].lower()
    identical.append(record)
msvc=pathlib.Path('C:/Program Files/Microsoft Visual Studio/2022/Community/VC/Tools/MSVC/14.44.35207')
sdk=pathlib.Path('C:/Program Files (x86)/Windows Kits/10/Lib/10.0.26100.0')
native=[msvc/'crt/src/vcruntime/exe_common.inl',msvc/'lib/x64/msvcrt.lib',msvc/'lib/x64/vcruntime.lib',sdk/'ucrt/x64/ucrt.lib',sdk/'um/x64/Kernel32.lib',sdk/'um/x64/ntdll.lib']
native += list((BASE/'target/debug/build/libsqlite3-sys-536cb156bdf83e9b/out').glob('*'))
sources=[]
for crate in ['layrs-store-local','layrs-weave','layrs-vfs','layrs-core','layrs-store','layrs-sync','layrs-graph']:
    sources += [pin(p) for p in sorted((BASE/'crates'/crate).rglob('*.rs'))]
sources.append(pin(BASE/'crates/layrs-store-local/src/projection/provider/records/golden-r4.json'))
for p in [BASE/'Cargo.lock',BASE/'Cargo.toml',BASE/'rust-toolchain.toml']:sources.append(pin(p))
report=dict(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),executable=pin(OUT/EXE.name),pdb=pin(OUT/PDB.name),codeView=records[0],startupSources=startup,unchangedRustAndSqliteInputs=identical,currentNativeInputs=[pin(p) for p in native if p.is_file()],sourceClosure=sources,
    decision='ROOT accepts this exact normal Rust libtest binary for the family/source publication SQL-memory and separately released native recipes under stock Rust/MSVC/Windows trust assumptions after source review and static artifact binding.',
    audit='Rust 1.85 libtest/libstd and nine startup source checksum bytes match retained audit. Current MSVC 14.44 CRT initialization sequence inspected; bundled SQLite/cc/blake3 source inputs match. Production connection-local progress handler is scoped to dedicated readonly probes and removed before observable close; no process-global SQLite configuration, extension or VFS mutation. Reviewed test-only observers are restricted to exact child recipes.',
    changedNativeToolchain='Current MSVC 14.44 and Windows SDK 10.0.26100 are recorded separately; old MSVC 14.29/SDK 19041 binary qualification is not transferred.',
    trustAssumptions=['Authentic stock Rust/MSVC components and ordinary Windows loader/CRT behavior','No native injection or unreviewed process-global configuration mutation','Reviewed forwarding observers run only in owned disposable test children'],
    notVerified=['Resolved Windows DLL identities','Universal empty autoextension registry proof','Complete historical preprocessing environment'],
    scope='Family/source publication SQL DATA and retained-proof family driver. Exact SQL recipes require source release; native recipes separately require source release and fresh disposable C: parents. No product host qualification, live callback source, historical runtime replay or old fixture reopening.',
    release='Pure and exact Active SQL tests permitted after review. Native activation and hot-journal recipes require separately recorded critical-review release; serial existing child bounds, fresh C: roots, stop first failure.')
save('host-disposition.json',report)
for entry in sources:
    original = pathlib.Path(entry['path'])
    retained = OUT / 'source' / original.relative_to(BASE)
    retained.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(original, retained)
    assert pin(retained)['sha256'] == entry['sha256']
print(json.dumps(dict(evidence=str(OUT),executable=report['executable'],codeView=records[0],startupSources=len(startup),sourceFiles=len(sources))))




