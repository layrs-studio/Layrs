from pathlib import Path
import datetime, difflib, hashlib, json, subprocess

root = Path('D:/Layrs/layrs')
tmp = Path('D:/Layrs/tmp')
old_manifest = json.loads((tmp / 'provider-ordinary-fresh-private-ready-review-r85-inputs.json').read_bytes())
old_report = json.loads((tmp / 'provider-ordinary-fresh-private-ready-critical-review-r85.json').read_bytes())
baseline = tmp / 'provider-ordinary-fresh-private-ready-review-r85-source'
r84 = root / '.layrs-local/validation/provider-ordinary-fresh-family-20261028-r84/source'
p = 'crates/layrs-store-local/src/projection/provider/'
s = p + 'bootstrap/preparation/activation/session/'
changed = [p + 'managed_export/ready.rs', p + 'process_profile/tests/child.rs'] + [s + x for x in [
    'managed_ordinary_ready_tests.rs', 'managed_ordinary_family_ready_tests.rs',
    'managed_ordinary_source_publication_tests.rs', 'managed_ordinary_fresh_private_ready_tests.rs',
]]
paths = sorted(set([e['path'] for e in old_manifest['files']] +
                   [e['path'] for e in old_report['inputs']['extra_source_dependencies']] +
                   [p + 'managed_export/checkout.rs', p + 'managed_export/protection.rs']))
expected = {e['path']: e['sha256'] for e in old_manifest['files']}
expected.update({e['path']: e['sha256'] for e in old_report['inputs']['extra_source_dependencies']})
assert len(changed) == 6 and set(changed).issubset(paths)
head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD']).decode().strip()
assert head == 'f01f6b9518b71a3cfc309be3a2911c51599f2e79'
branch = subprocess.check_output(['git', '-C', str(root), 'branch', '--show-current']).decode().strip()
assert branch == 'feature/worktrees-partial-vfs'
snapshot = tmp / 'provider-ordinary-ready-ordering-review-r86-source'
snapshot.mkdir(exist_ok=False)
files, diff = [], []
normal = lambda b: b.decode('utf-8').replace('\r\n', '\n')
for path in paths:
    raw = (root / path).read_bytes()
    if path in changed:
        old = (baseline / path).read_bytes()
        assert hashlib.sha256(old).hexdigest() == expected[path]
        assert normal(old) != normal(raw), path
        diff.extend(difflib.unified_diff(normal(old).splitlines(True), normal(raw).splitlines(True), fromfile='r85/' + path, tofile='r86/' + path))
    elif path in expected:
        assert hashlib.sha256(raw).hexdigest() == expected[path], ('context drift', path)
    else:
        assert normal(raw) == normal((r84 / path).read_bytes()), ('r84 context drift', path)
    target = snapshot / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    files.append(dict(path=path, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), changed=path in changed))
diff_path = tmp / 'provider-ordinary-ready-ordering-review-r86.diff'
with diff_path.open('x', encoding='utf-8') as f:
    f.write(''.join(diff))
manifest = dict(head=head, branch=branch, recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline=str(baseline), snapshot=str(snapshot), files=files, changed=changed,
    diffSha256=hashlib.sha256(diff_path.read_bytes()).hexdigest(),
    prior_source_review=dict(path=str(tmp / 'provider-ordinary-fresh-private-ready-critical-review-r85.json'), sha256=hashlib.sha256((tmp / 'provider-ordinary-fresh-private-ready-critical-review-r85.json').read_bytes()).hexdigest()),
    scope='Retained ReadyContext strict failure-stop and identity-only checks under catalog gates; physical checks before/after successful gates. Extended retained private/family ACK recipes and family Updated readback. Test-only monotonic phase logging in common setup and fresh private recipes. Prior r85 fresh private implementation otherwise unchanged.',
    execution='Uncompiled/unexecuted candidate. ROOT73332 exclusively runs retained r84. No builds, SQL, native, fixture opens or interaction with that session authorized in review.',
    limits=['No actual COMMIT/rollback/SQLite or OS close failure, crash or owner-loss qualification.',
            'Timing logs measure scopes, can overlap and do not establish test success or performance improvement.',
            'r85 source review is not runtime evidence; compile/runtime remain pending for the integrated candidate.'])
path = tmp / 'provider-ordinary-ready-ordering-review-r86-inputs.json'
with path.open('x', encoding='utf-8') as f:
    json.dump(manifest, f, indent=2)
print(json.dumps(dict(manifest=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), diffSha256=manifest['diffSha256'], files=len(files), changed=len(changed))))
