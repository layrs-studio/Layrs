from pathlib import Path
import datetime, hashlib, io, json, tarfile

root = Path('D:/Layrs/layrs')
tmp = Path('D:/Layrs/tmp')
prefix = 'provider-ordinary-ready-ordering'
manifest_path = tmp / f'{prefix}-review-r86-inputs.json'
report_path = tmp / f'{prefix}-critical-review-r86.json'
manifest = json.loads(manifest_path.read_bytes())
report = json.loads(report_path.read_bytes())
frozen = tmp / f'{prefix}-review-r86-source'
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
assert pin(manifest_path)['sha256'] == 'd9684350c299384cc3006d42c1a60efa45e58671d5a4a996de32a86ccce6275d'
assert not report['findings']
assert report['inputs']['identity_at_end']['mismatches'] == []
entries = {}
for e in manifest['files']:
    expected = {k: e[k] for k in ['bytes', 'sha256']}
    assert pin(frozen / e['path']) == expected, e['path']
    assert pin(root / e['path']) == expected, ('live drift', e['path'])
    entries['reviewed-source/' + e['path']] = frozen / e['path']
for e in report['inputs']['extra_source_dependencies']:
    p = root / e['path']
    assert pin(p)['sha256'] == e['sha256'], e['path']
    entries['reviewed-dependencies/' + e['path']] = p
for name in [f'{prefix}-review-r86-inputs.json', f'{prefix}-review-r86.diff',
             f'{prefix}-critical-review-r86.json', 'prepare-ordinary-ready-ordering-review-r86.py']:
    entries['support/' + name] = tmp / name
entries['support/' + Path(__file__).name] = Path(__file__)
record = dict(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='SOURCE ONLY retained Ready failure ordering and test-only phase timers. Independent critical review r86, no actionable source finding. Compilation r87 later reports a test pattern error; correction is outside this frozen review archive.',
    head=manifest['head'], branch=manifest['branch'],
    limitations=['No runtime, performance, resource, crash or actual close-failure qualification.',
                 'Proposed native ACK loss follows successful SQLite connection close.',
                 'Fresh private product driver r85 is unchanged context; retained ReadyContext correction is the r86 scope.',
                 'ROOT73332 r84 runtime is separate and does not exercise r86.'],
    files=[dict(path=n, **pin(p)) for n, p in sorted(entries.items())])
dest = root / 'docs/continuation/worktrees-partial-vfs'
archive = dest / 'ordinary-ready-ordering-source-review-20261028-r86.tar.gz'
inventory = dest / 'ordinary-ready-ordering-source-review-inventory-20261028-r86.json'
assert not archive.exists() and not inventory.exists()
data = json.dumps(record, indent=2).encode('utf-8')
with tarfile.open(archive, 'x:gz') as tar:
    info = tarfile.TarInfo('manifest.json')
    info.size = len(data)
    tar.addfile(info, io.BytesIO(data))
    for n, p in sorted(entries.items()):
        tar.add(p, arcname=n, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(entries) + 1
    for e in record['files']:
        data = tar.extractfile(e['path']).read()
        assert len(data) == e['bytes'] and hashlib.sha256(data).hexdigest() == e['sha256']
record['archive'] = dict(path=archive.name, **pin(archive))
with inventory.open('x', encoding='utf-8') as f:
    json.dump(record, f, indent=2)
print(json.dumps(dict(archive=str(archive), files=len(entries) + 1, **pin(archive))))
