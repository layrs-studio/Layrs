# r26 pre-execution artifact

The normal libtest binary built successfully and its EXE/PDB/startup/source
closure was retained. No recipe was released or executed with this artifact.

Before execution, ROOT found a test assertion incompatible with the existing
ProjectionStoreError API: Error::source returns None for the Io variant.
Cancellation from the retained-content sink is preserved as the typed inner
layrs_vfs::Error::Cancelled in io::Error, rather than through that outer source
method. The native assertion was corrected to inspect Io::get_ref and downcast
to the concrete cancellation type. Production sources were unchanged.

The corrected binary and full closure are retained separately as r27. This
directory is a build/audit record, not a runtime failure or successful test.
