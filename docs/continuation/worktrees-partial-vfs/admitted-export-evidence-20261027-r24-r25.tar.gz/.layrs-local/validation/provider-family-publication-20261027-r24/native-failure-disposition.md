# r24 native planning recipe — failed final witness

The run remains FAILED: exit 101, 211.21 s child / 211.25 s parent / 211.271 s
outer runner. No failed fixture was reopened or retried. The retained log and
`native-failure-tree-diff.json` show the final assertion at test line 296.
All preceding assertions completed, including the first plan's unchanged byte
trees, its no-SQL-write and forged-admission checks, exact restore-only preimage
mapping/bytes, and equality of the plan after ordinary reopening.

Only the family catalog and B's private database hashes differ in that final
assertion; file identities, sizes and the other recorded tree entries match.
The comparison spanned `ProjectionStore::open`, not just the readonly planner.

Two independent source investigations found the deterministic settlement path:

- `restore/engine.rs` commits the capture and restore history after
  `capture/storage.rs` calls `retention::finish_budget`.
- `retention.rs` marks the private budget `committed`. Shared reads and the
  planning callback leave that deferred reservation intact.
- `format::open` acquires Exclusive access. Its admitted branch invokes
  `retention::settle_with_lease`, which releases the family reservation through
  `shared::Lease::release_reservation`, then deletes the private committed budget.

This explains the expected two-database write boundary from source; the old
fixture's SQL contents were not inspected. The corrected r25 test explicitly
asserts one committed budget before reopen and zero after it. It keeps the
entire byte-tree comparison around each separate planning operation, using a
fresh witness immediately after open for the second operation. It still checks
checkout bytes across reopen, admission equality, and identical encoded prefix,
image digest and exact mappings. No database is excluded from the witnesses.
Only the test changes; production code and the twenty passing r24 test bodies
remain unchanged. The r25 result is recorded separately and is not inferred by
this disposition.
