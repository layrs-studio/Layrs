# Local Provider transition source view — source proposal

ROOT authored this nine-file proposal against HEAD
`6b1f5632bd7f6092226d57e3c813033a82bcfc98`. Nothing was applied to the main
checkout. Existing r98/r100 source evidence and both delegated proposals are
unchanged. This is one concrete local-reader dependency, not completed C13.

`ProviderActiveSession::transition_source(&Cancellation)` returns a privately
constructed `ProviderTransitionSource<'session>`. It borrows the actual session,
retaining its owner/native root/lifecycle. It reads full private publication and
family state with the existing reader and positive close handling, compares the
retained active mount/activation, rejects unfinished capture or transition, then
releases every operation lock before returning. The owned proof is boxed; the
view cannot be constructed from caller DATA, cloned, deserialized or detached
from the live session.

`ProviderTransitionSource::revalidate` repeats that complete read and uses
`PrivateCaptureMutationValidation::require_same_state`, covering source,
activation, captures, mappings, claims and outgoing publication history. The
new `from_publication` helper factors the same no-pending-transition gate used
by the existing capture-mutation reader; that reader's behavior is unchanged.
The source-companion implementation must extend this common equality and the
family reader to retain its new companion proof. Its agent was notified.

The public view exposes identity/binding, activated `VersionedProjection`,
original snapshot, selection with its original row generation/snapshot/digest,
catalog ID, borrowed original descriptor metadata, and complete accepted
Capture patches/count/head. The five public export layers are wired.

## Client bridge

For the completed client collector's request, use `versioned_snapshot().snapshot`
as the historical original and the corresponding generation/digest; do not
substitute `initial_snapshot()` for the activated generation. The parent digest
is the validated activation's original source digest. Selection remains the
actual generation-zero selection row; getters keep that distinction explicit.
Identity supplies Store/Worktree/origin/space/principal; descriptors are only
canonical historical metadata and grant no resident bytes or remote permission.

This view intentionally does NOT invent `source_prefix_id` or
`effective_image_digest`. The actual conversion driver still must derive those
from its verified import closure and retained complete native checkpoint/image,
bind the client request to them, then independently match them after HTTP.
Do not call an arbitrary string or this read result a complete source anchor.

No SQL scope survives network acquisition. The final driver must reacquire its
actual scopes, validate the same source/image/remote witness and retain them
through the authorized effects. A successful standalone revalidation is a
point-in-time read and never a writer grant, a continuous server lease, or a
promise that mutable user files did not change.

## Evidence and remaining checks

Eight proposal Rust files pass rustfmt/check with edition2024, style2021,
skip_children. `projection.rs` preserves unrelated base import formatting and
adds one explicit export. All seven existing file bases were compared against
the exact HEAD and physical checkout before patch generation; two files are new.
`git apply --check` passes without applying anything. An initial check found
missing `new file mode` patch headers; the generator was fixed and the check
then passed. No source change was needed for that patch packaging error.

No compilation, SQL/native execution or independent review was performed.
One ignored native test is authored:
`transition_source_is_readonly_releases_gates_and_refuses_intervening_capture`.
It calls the actual public view, checks zero writer admissions/no hydration,
disconnected and precancel refusal, then runs a real accepted Capture while
the old DATA view is retained. The old view must refuse; a fresh one must expose
the new capture. The capture also demonstrates released operation locks. A
separate assertion demonstrates that unrecorded user-byte changes do not become
metadata drift: a complete image witness remains mandatory. Child3600/outer3660
are proposed, unmeasured bounds, not observed timings.

Pending-transition/refusal-corruption variants are not executed or separately
qualified here. The client collector, source B protection/publication and this
view must be integrated and checked together before production conversion.
The full conversion entry, exact prefix/image bridge, denied-row durability,
companion-capable C Ready, autonomy and expanded Provider activation remain open.
