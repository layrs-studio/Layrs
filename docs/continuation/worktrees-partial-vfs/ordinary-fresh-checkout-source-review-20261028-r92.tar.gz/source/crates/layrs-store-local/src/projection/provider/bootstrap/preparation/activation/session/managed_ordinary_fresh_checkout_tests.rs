//! Proposed fresh B -> C checkout recipes, from genuine completed protection.
//! Each recipe owns a new parent and releases all setup capabilities before
//! reopening. Withheld ACK follows SQLite connection close success; no native
//! xClose/OS-close failure, crash or owner-loss outcome is claimed.
use super::{
    managed_ordinary_family_ready_tests::family,
    managed_ordinary_installing_tests::{self as witness, Database, Node, Tree},
    managed_ordinary_ready_tests::CURRENT,
    managed_ordinary_source_publication_tests::{
        ingress, source, with_protected_checkout_data, ProtectedCheckoutFixture,
    },
};
use crate::{
    error::StoreError,
    lock::StoreLock,
    projection::{
        format,
        provider::{
            checkout_journal::{
                self, CheckoutEntry, CheckoutJournal, DirectoryState, ExpectedCheckout, FileState,
                RowKey,
            },
            database_io::{
                tests::{
                    fresh_ordinary_support::{with_observer, ReadBoundary},
                    writer_support::{self, AdmissionPoint},
                },
                WriterCloseObserver, WriterOpenPoint,
            },
            managed_export::{
                CheckoutPopulationEffect, OrdinaryCheckoutPopulation,
                OrdinaryCheckoutPopulationFailure, OrdinaryManagedExport,
            },
            managed_ready_reopen::AdmissionStep,
            process_profile::tests::child,
            records::{
                transition::{ProviderTransitionIntentRecord, TransitionRole, TransitionState},
                Record,
            },
            recovery::error::{invalid, ProviderBootstrapCause as Cause, Result as CauseResult},
        },
        SessionMode,
    },
};
use layrs_core::scm::FileManifest;
use layrs_vfs::Cancellation;
use rusqlite::ffi;
use std::{
    cell::Cell,
    collections::BTreeSet,
    fs::{self, OpenOptions},
    os::windows::fs::OpenOptionsExt,
    path::{Path, PathBuf},
    rc::Rc,
};

const WITHHELD_ACK: &str = "fresh checkout SQLite close acknowledgement deliberately withheld";
const B_DRIFT: &[u8] = b"changed actual B bytes refuse fresh checkout";
const FOREIGN: &[u8] = b"foreign checkout file must never be adopted";

fn snapshot(path: &Path) -> Database {
    witness::read(path, witness::database)
}

/// Detached DATA only. No allocation, image, CAS or protection proof escapes.
struct Fixture {
    source: PathBuf,
    destination: PathBuf,
    family: PathBuf,
    source_database: PathBuf,
    destination_database: PathBuf,
    family_database: PathBuf,
    source_marker: format::Marker,
    original_ingress: Vec<Vec<u8>>,
    source_staging: ProviderTransitionIntentRecord,
    destination_staging: ProviderTransitionIntentRecord,
    expected: Box<ExpectedCheckout>,
    required: Vec<FileManifest>,
    source_rows: Database,
    destination_rows: Database,
    family_rows: Database,
    // B image, current CAS chunk, then every remaining exact CAS object.
    pins: Vec<PathBuf>,
}

fn close_after_protection(
    owner: OrdinaryManagedExport<'_>,
    f: &ProtectedCheckoutFixture<'_>,
    _: &Cancellation,
) -> Box<Fixture> {
    let mut phase = child::phase("fresh-checkout-setup.protected-witness");
    assert_eq!(f.source_staging.role, TransitionRole::Source);
    assert_eq!(f.source_staging.state, TransitionState::Staging);
    assert!(f.source_staging.receipt_id.is_none());
    assert_eq!(f.destination_staging.role, TransitionRole::Destination);
    assert_eq!(f.destination_staging.state, TransitionState::Staging);
    assert!(f.destination_staging.receipt_id.is_none());
    let _actual_setup_protection = f.protection;
    let original_ingress = witness::read(f.source_database, |c| ingress(c, f.source_marker));
    let source_rows = source(
        f.source_database,
        f.source_marker,
        f.source_staging,
        None,
        &original_ingress,
    );
    let destination_rows = witness::destination(f.destination_database, f.source_staging);
    assert!(destination_rows["projection_prejournal"].is_empty());
    assert_eq!(
        destination_rows["projection_provider_transition_receipts"],
        source_rows["projection_provider_transition_receipts"],
        "complete inherited ingress receipt table is copied to C"
    );
    assert_eq!(
        source_rows["projection_provider_transition_receipts"].len(),
        1
    );
    let family_rows = family(
        f.family_database,
        f.source_staging,
        f.required,
        "initializing",
    );
    assert_eq!(f.expected.files().len(), 1);
    assert!(f.expected.directories().is_empty());
    assert!(f.expected.deletions().is_empty());
    assert_eq!(&f.expected.files()[0].manifest_id, f.current.id());
    let mut pins = vec![
        f.source_root.join(f.expected.files()[0].path.as_str()),
        witness::object(
            f.family_root,
            "chunks",
            f.current.chunks()[0].chunk_id().as_str(),
        ),
    ];
    assert_eq!(fs::read(&pins[0]).unwrap(), CURRENT);
    assert_eq!(fs::read(&pins[1]).unwrap(), CURRENT);
    assert_ne!(
        crate::projection::provider::database_io::tests::support::witness(&pins[0]).0,
        crate::projection::provider::database_io::tests::support::witness(&pins[1]).0,
        "B image and protected CAS require independent identity witnesses"
    );
    for manifest in f.required {
        let objects = std::iter::once(witness::object(
            f.family_root,
            "manifests",
            manifest.id().as_str(),
        ))
        .chain(
            manifest
                .chunks()
                .iter()
                .map(|chunk| witness::object(f.family_root, "chunks", chunk.chunk_id().as_str())),
        );
        for path in objects {
            if !pins.contains(&path) {
                pins.push(path);
            }
        }
    }
    assert!(!f
        .destination_root
        .join(f.expected.stage_relative_path())
        .exists());
    assert!(!f
        .destination_root
        .join(f.expected.files()[0].path.as_str())
        .exists());
    let source_staging =
        ProviderTransitionIntentRecord::decode(&f.source_staging.encode().unwrap()).unwrap();
    let destination_staging =
        ProviderTransitionIntentRecord::decode(&f.destination_staging.encode().unwrap()).unwrap();
    let expected = Box::new(
        ExpectedCheckout::ordinary(
            &source_staging,
            f.expected.files(),
            f.expected.deletions(),
            &f.expected.header().image_digest,
            None,
        )
        .unwrap(),
    );
    assert_eq!(expected.header(), f.expected.header());
    phase.next("fresh-checkout-setup.close-original-b");
    owner.close().unwrap();
    phase.next("fresh-checkout-setup.detached-data");
    Box::new(Fixture {
        source: f.source_root.to_owned(),
        destination: f.destination_root.to_owned(),
        family: f.family_root.to_owned(),
        source_database: f.source_database.to_owned(),
        destination_database: f.destination_database.to_owned(),
        family_database: f.family_database.to_owned(),
        source_marker: f.source_marker.clone(),
        original_ingress,
        source_staging,
        destination_staging,
        expected,
        required: f.required.to_vec(),
        source_rows,
        destination_rows,
        family_rows,
        pins,
    })
}

fn released(path: &Path) {
    drop(
        OpenOptions::new()
            .write(true)
            .share_mode(7)
            .open(path)
            .expect("all former image/CAS/checkout pins must be released"),
    );
}

fn blocked(path: &Path) {
    let error = OpenOptions::new()
        .write(true)
        .share_mode(7)
        .open(path)
        .unwrap_err();
    assert_eq!(
        error.raw_os_error(),
        Some(32),
        "retained native pin {path:?}"
    );
}

fn require_released(f: &Fixture) {
    for path in &f.pins {
        released(path);
    }
    let final_path = final_path(f);
    if final_path.exists() {
        released(&final_path);
    }
    let temporary = temporary(f);
    if temporary.exists() {
        released(&temporary);
    }
}

fn fixture() -> Box<Fixture> {
    let _total = child::phase("fresh-checkout-setup.total");
    let f = with_protected_checkout_data(close_after_protection);
    let _witness = child::phase("fresh-checkout-setup.released-witness");
    require_released(&f);
    require_rows(&f);
    assert_eq!(snapshot(&f.destination_database), f.destination_rows);
    f
}

fn final_path(f: &Fixture) -> PathBuf {
    f.destination.join(f.expected.files()[0].path.as_str())
}

fn stage_path(f: &Fixture) -> PathBuf {
    f.destination.join(f.expected.stage_relative_path())
}

fn temporary(f: &Fixture) -> PathBuf {
    stage_path(f).join(f.expected.temporary_name(0).unwrap())
}

/// Every rowset is compared, including inherited receipts, grants and quotas.
/// Only checkout journal rows may change. C remains C8 Staging throughout.
fn require_rows(f: &Fixture) {
    assert_eq!(
        source(
            &f.source_database,
            &f.source_marker,
            &f.source_staging,
            None,
            &f.original_ingress,
        ),
        f.source_rows
    );
    assert_eq!(
        family(
            &f.family_database,
            &f.source_staging,
            &f.required,
            "initializing"
        ),
        f.family_rows
    );
    let current = witness::destination(&f.destination_database, &f.source_staging);
    assert_eq!(
        current.keys().collect::<Vec<_>>(),
        f.destination_rows.keys().collect::<Vec<_>>()
    );
    for (table, rows) in &f.destination_rows {
        if table != "projection_prejournal" {
            assert_eq!(&current[table], rows, "unexpected C mutation in {table}");
        }
    }
    witness::read(&f.destination_database, |c| {
        let payload: Vec<u8> = c
            .query_row(
                "SELECT payload FROM projection_provider_transitions WHERE id=?1",
                [&f.destination_staging.transaction_id],
                |row| row.get(0),
            )
            .unwrap();
        assert_eq!(
            ProviderTransitionIntentRecord::decode(&payload).unwrap(),
            f.destination_staging
        );
        assert_eq!(c.query_row(
            "SELECT count(*) FROM projection_provider_transition_receipts WHERE transaction_id=?1",
            [&f.source_staging.transaction_id], |row| row.get::<_, u64>(0),
        ).unwrap(), 0, "only the new B -> C receipt is absent");
    });
}

fn trees(f: &Fixture) -> (Tree, Tree, Tree) {
    let b_lock = f.source_database.parent().unwrap().join("layrs.lock");
    let c_lock = f.destination_database.parent().unwrap().join("layrs.lock");
    witness::trees(&f.source, &f.family, &f.destination, [&b_lock, &c_lock])
}

/// Preserve every preexisting inode and byte except C's journal database;
/// assert the complete set of new names, including the still-empty stage.
fn only_checkout_changed(
    f: &Fixture,
    before: &(Tree, Tree, Tree),
    after: &(Tree, Tree, Tree),
    new_paths: BTreeSet<PathBuf>,
) {
    assert_eq!(before.0, after.0);
    for (previous, current) in [
        (&before.0, &after.0),
        (&before.1, &after.1),
        (&before.2, &after.2),
    ] {
        for (path, node) in previous {
            let next = &current[path];
            if path == &f.destination_database {
                let (Node::File((old_id, _, _)), Node::File((new_id, _, _))) = (node, next) else {
                    panic!("C database remains a regular file")
                };
                assert_eq!(old_id, new_id);
            } else {
                assert_eq!(node, next, "checkout changed unrelated {path:?}");
            }
        }
        let actual_new = current
            .keys()
            .filter(|path| !previous.contains_key(*path))
            .cloned()
            .collect::<BTreeSet<_>>();
        let expected_new = new_paths
            .iter()
            .filter(|path| current.contains_key(*path))
            .cloned()
            .collect::<BTreeSet<_>>();
        assert_eq!(actual_new, expected_new);
    }
    for path in new_paths {
        assert!(
            after.2.contains_key(&path),
            "new checkout path {path:?} is observed"
        );
    }
}

fn require_complete(f: &Fixture, expected_journal: Option<&CheckoutJournal>) {
    require_rows(f);
    let complete = trees(f);
    witness::read(&f.destination_database, |c| {
        let journal = checkout_journal::read(c, &f.expected, None).unwrap();
        assert!(journal.is_complete());
        assert_eq!(journal.rows().len(), 3);
        assert_eq!(
            journal.row(RowKey::Header).unwrap(),
            &f.expected.declared_row(RowKey::Header).unwrap()
        );
        if let Some(expected) = expected_journal {
            assert_eq!(journal.rows(), expected.rows());
        }
        let CheckoutEntry::Stage {
            state: DirectoryState::Owned { identity },
        } = &journal.row(RowKey::Stage).unwrap().entry
        else {
            panic!("complete stage is durably Owned")
        };
        assert_eq!(
            &complete.2[&stage_path(f)],
            &Node::Directory(identity.clone())
        );
        let CheckoutEntry::File {
            state:
                FileState::Published {
                    inode,
                    parent_identity,
                },
            file,
            ..
        } = &journal.row(RowKey::File(0)).unwrap().entry
        else {
            panic!("complete file is durably Published")
        };
        assert_eq!(file, &f.expected.files()[0]);
        assert_eq!(parent_identity, &f.expected.header().checkout_identity);
        let Node::File((actual, bytes, _)) = &complete.2[&final_path(f)] else {
            panic!("published checkout must be an actual regular file")
        };
        assert_eq!(inode, actual);
        assert_eq!(*bytes, CURRENT.len() as u64);
        for pin in &f.pins {
            assert_ne!(
                inode,
                &crate::projection::provider::database_io::tests::support::witness(pin).0,
                "published checkout has independent physical identity"
            );
        }
    });
    assert_eq!(fs::read(final_path(f)).unwrap(), CURRENT);
    assert!(fs::read_dir(stage_path(f)).unwrap().next().is_none());
    assert!(!temporary(f).exists());
    witness::verify_objects(&f.family, &f.required);
}

fn require_owners(f: &Fixture) {
    for database in [&f.source_database, &f.destination_database] {
        for mode in [SessionMode::Shared, SessionMode::Exclusive] {
            let error =
                StoreLock::acquire_existing(&database.parent().unwrap().join("layrs.lock"), mode)
                    .unwrap_err();
            assert!(
                matches!(
                    error,
                    StoreError::LockBusy(_) | StoreError::ReentrantLock(_)
                ),
                "exclusive fresh owner required: {error}"
            );
        }
    }
}

fn with_writer_probe<T>(
    observer: impl FnMut(&Path, AdmissionPoint) -> CauseResult<()> + 'static,
    action: impl FnOnce() -> T,
) -> T {
    writer_support::observe(observer);
    struct Reset;
    impl Drop for Reset {
        fn drop(&mut self) {
            writer_support::clear_observer();
        }
    }
    let _reset = Reset;
    action()
}

fn refuse_open_without_writer(f: &Fixture, cancel: &Cancellation) -> Cause {
    let writers = Rc::new(Cell::new(0usize));
    let observed = writers.clone();
    let before = trees(f);
    let result = with_writer_probe(
        move |_, point| {
            if point == AdmissionPoint::BeforeWritableOpen {
                observed.set(observed.get() + 1);
                return Err(invalid(
                    "invalid fresh checkout must refuse before writable open",
                ));
            }
            Ok(())
        },
        || {
            OrdinaryCheckoutPopulation::open(
                &f.source,
                &f.destination,
                &f.source_staging.transaction_id,
                cancel,
            )
        },
    );
    let cause = result.err().expect("invalid fresh checkout must refuse");
    assert_eq!(writers.get(), 0);
    assert_eq!(
        trees(f),
        before,
        "refusal preserves every actual inode and byte"
    );
    require_rows(f);
    require_released(f);
    cause
}

struct Close {
    pins: Vec<PathBuf>,
    counts: (usize, usize, usize, usize),
    refuse_at: Option<usize>,
    withheld: Rc<Cell<bool>>,
}

impl Close {
    fn new(f: &Fixture, refuse_at: Option<usize>) -> Self {
        Self {
            pins: f.pins.clone(),
            counts: (0, 0, 0, 0),
            refuse_at,
            withheld: Rc::new(Cell::new(false)),
        }
    }
    fn require_pins(&self) {
        for path in &self.pins {
            blocked(path);
        }
    }
}

impl WriterCloseObserver for Close {
    fn open_point(&mut self, point: WriterOpenPoint, raw: *mut ffi::sqlite3) -> CauseResult<()> {
        assert!(
            !self.withheld.get(),
            "no writer probe after withheld close ACK"
        );
        match point {
            WriterOpenPoint::BeforeRaw => {
                assert!(raw.is_null());
                self.counts.0 += 1;
                self.require_pins();
            }
            WriterOpenPoint::AfterRaw => {
                assert!(!raw.is_null());
                self.counts.1 += 1;
            }
            _ => {}
        }
        Ok(())
    }
    fn before_close(&mut self, _: *mut ffi::sqlite3) -> Option<Cause> {
        self.require_pins();
        None
    }
    fn after_close(&mut self, success: bool) -> Option<Cause> {
        assert!(
            success,
            "actual SQLite connection close success required; no native OS-close inference"
        );
        self.counts.2 += 1;
        self.require_pins();
        if self.refuse_at == Some(self.counts.2) {
            self.counts.3 += 1;
            self.withheld.set(true);
            Some(invalid(WITHHELD_ACK))
        } else {
            None
        }
    }
}

fn replay_without_writer(f: &Fixture, cancel: &Cancellation) {
    let mut phase = child::phase("fresh-checkout-replay.baseline-witness");
    let before = trees(f);
    let rows = snapshot(&f.destination_database);
    let writers = Rc::new(Cell::new(0usize));
    let observed = writers.clone();
    let mut close = Close::new(f, None);
    let progress = with_writer_probe(
        move |_, point| {
            if point == AdmissionPoint::BeforeWritableOpen {
                observed.set(observed.get() + 1);
                return Err(invalid("complete checkout replay forbids writable open"));
            }
            Ok(())
        },
        || {
            phase.next("fresh-checkout-replay.open");
            let held = OrdinaryCheckoutPopulation::open(
                &f.source,
                &f.destination,
                &f.source_staging.transaction_id,
                cancel,
            )
            .unwrap_or_else(|e| panic!("fresh complete checkout open: {e}"));
            require_owners(f);
            close.require_pins();
            phase.next("fresh-checkout-replay.populate");
            held.populate_checkout(&mut close, cancel)
        },
    )
    .unwrap_or_else(|e| panic!("complete checkout replay {:?}: {}", e.step, e.cause));
    phase.next("fresh-checkout-replay.complete-witness");
    assert_eq!(progress.effect(), CheckoutPopulationEffect::AlreadyComplete);
    assert_eq!(progress.expected().header(), f.expected.header());
    require_complete(f, Some(progress.journal()));
    assert_eq!(writers.get(), 0);
    assert_eq!(close.counts, (0, 0, 0, 0));
    drop(progress);
    assert_eq!(snapshot(&f.destination_database), rows);
    assert_eq!(trees(f), before);
    require_released(f);
}

#[test]
#[ignore = "ROOT source release and audited owned native child3600/outer3660 required; proposed unmeasured"]
fn managed_ordinary_fresh_checkout_refuses_drift_then_populates_absent_and_replays_without_writer()
{
    child::run(concat!(module_path!(), "::managed_ordinary_fresh_checkout_refuses_drift_then_populates_absent_and_replays_without_writer"), 3600, || {
        let _total = child::phase("fresh-checkout-success.total");
        let f = fixture();
        let mut phase = child::phase("fresh-checkout-success.baseline-witness");
        let before = trees(&f);
        let cancel = Cancellation::default();
        let cancelled = Cancellation::default();
        cancelled.cancel();
        phase.next("fresh-checkout-success.precancel");
        let _ = refuse_open_without_writer(&f, &cancelled);
        require_rows(&f);
        assert_eq!(trees(&f), before);
        phase.next("fresh-checkout-success.changed-b");
        fs::write(&f.pins[0], B_DRIFT).unwrap();
        let refused = refuse_open_without_writer(&f, &cancel);
        assert!(refused.to_string().contains("image"), "{refused}");
        require_rows(&f);
        assert_eq!(snapshot(&f.destination_database), f.destination_rows);
        fs::write(&f.pins[0], CURRENT).unwrap();
        assert_eq!(trees(&f), before);
        require_released(&f);
        phase.next("fresh-checkout-success.foreign-c-namespace");
        fs::write(final_path(&f), FOREIGN).unwrap();
        let _ = refuse_open_without_writer(&f, &cancel);
        assert_eq!(fs::read(final_path(&f)).unwrap(), FOREIGN);
        require_rows(&f);
        assert_eq!(snapshot(&f.destination_database), f.destination_rows);
        fs::remove_file(final_path(&f)).unwrap();
        assert_eq!(trees(&f), before);
        require_released(&f);
        phase.next("fresh-checkout-success.fresh-open");
        let held = OrdinaryCheckoutPopulation::open(&f.source, &f.destination, &f.source_staging.transaction_id, &cancel)
            .unwrap_or_else(|e| panic!("fresh protected checkout open: {e}"));
        require_owners(&f);
        let mut close = Close::new(&f, None);
        close.require_pins();
        phase.next("fresh-checkout-success.populate");
        let progress = held.populate_checkout(&mut close, &cancel)
            .unwrap_or_else(|e| panic!("fresh checkout populate {:?}: {}", e.step, e.cause));
        phase.next("fresh-checkout-success.complete-witness");
        assert_eq!(progress.effect(), CheckoutPopulationEffect::Updated);
        assert_eq!(progress.expected().header(), f.expected.header());
        assert_eq!(progress.expected().files(), f.expected.files());
        require_complete(&f, Some(progress.journal()));
        assert_eq!(close.counts.0, close.counts.1);
        assert_eq!(close.counts.1, close.counts.2);
        assert_eq!(close.counts.3, 0);
        assert!(close.counts.2 > 0);
        drop(progress);
        require_released(&f);
        only_checkout_changed(&f, &before, &trees(&f), BTreeSet::from([stage_path(&f), final_path(&f)]));
        phase.next("fresh-checkout-success.fresh-complete-replay");
        replay_without_writer(&f, &cancel);
    });
}

#[derive(Clone, Copy)]
enum Cut {
    Declare,
    Owned,
}

fn require_cut(f: &Fixture, cut: Cut) {
    require_rows(f);
    let physical = trees(f);
    witness::read(&f.destination_database, |c| {
        let journal = checkout_journal::read(c, &f.expected, None).unwrap();
        assert!(!journal.is_complete());
        assert_eq!(journal.rows().len(), 3);
        assert_eq!(
            journal.row(RowKey::Header).unwrap(),
            &f.expected.declared_row(RowKey::Header).unwrap()
        );
        match cut {
            Cut::Declare => {
                assert_eq!(
                    journal.row(RowKey::Stage).unwrap(),
                    &f.expected.declared_row(RowKey::Stage).unwrap()
                );
                assert_eq!(
                    journal.row(RowKey::File(0)).unwrap(),
                    &f.expected.declared_row(RowKey::File(0)).unwrap()
                );
                assert!(!stage_path(f).exists());
                assert!(!temporary(f).exists());
            }
            Cut::Owned => {
                let CheckoutEntry::Stage {
                    state: DirectoryState::Owned { identity },
                } = &journal.row(RowKey::Stage).unwrap().entry
                else {
                    panic!("stage Owned must be durably observed")
                };
                assert_eq!(
                    &physical.2[&stage_path(f)],
                    &Node::Directory(identity.clone())
                );
                let CheckoutEntry::File {
                    state: FileState::Owned { inode },
                    file,
                    ..
                } = &journal.row(RowKey::File(0)).unwrap().entry
                else {
                    panic!("file Owned must be durably observed")
                };
                assert_eq!(file, &f.expected.files()[0]);
                let Node::File((actual, bytes, _)) = &physical.2[&temporary(f)] else {
                    panic!("actual Owned TEMP required")
                };
                assert_eq!(inode, actual);
                assert_eq!(*bytes, 0, "no producer bytes before Owned close ACK");
                assert_eq!(fs::read_dir(stage_path(f)).unwrap().count(), 1);
            }
        }
        assert!(!final_path(f).exists());
    });
}

fn withheld_ack_recipe(cut: Cut) {
    let _total = child::phase("fresh-checkout-ack.total");
    let f = fixture(); // Each native recipe has its own genuine setup/parent.
    let mut phase = child::phase("fresh-checkout-ack.baseline-witness");
    let before = trees(&f);
    let cancel = Cancellation::default();
    phase.next("fresh-checkout-ack.open");
    let held = OrdinaryCheckoutPopulation::open(
        &f.source,
        &f.destination,
        &f.source_staging.transaction_id,
        &cancel,
    )
    .unwrap_or_else(|e| panic!("fresh protected checkout open: {e}"));
    require_owners(&f);
    let refuse_at = match cut {
        Cut::Declare => 1,
        Cut::Owned => 3,
    };
    let mut close = Close::new(&f, Some(refuse_at));
    close.require_pins();
    let withheld = close.withheld.clone();
    let reads_after_ack = Rc::new(Cell::new(0usize));
    let observed_reads = reads_after_ack.clone();
    let reads_before_ack = Rc::new(Cell::new(0usize));
    let observed_before_reads = reads_before_ack.clone();
    let writer_ack = withheld.clone();
    let writers_after_ack = Rc::new(Cell::new(0usize));
    let observed_writers = writers_after_ack.clone();
    let writers_before_ack = Rc::new(Cell::new(0usize));
    let observed_before_writers = writers_before_ack.clone();
    phase.next("fresh-checkout-ack.populate-until-withheld");
    let result = with_writer_probe(
        move |_, _| {
            if writer_ack.get() {
                observed_writers.set(observed_writers.get() + 1);
                return Err(invalid(
                    "withheld checkout ACK forbids subsequent writer admission probes",
                ));
            }
            observed_before_writers.set(observed_before_writers.get() + 1);
            Ok(())
        },
        || {
            with_observer(
                move |_, _point: ReadBoundary| {
                    if withheld.get() {
                        observed_reads.set(observed_reads.get() + 1);
                        return Err(invalid("withheld checkout ACK forbids subsequent read/identity/snapshot probes"));
                    }
                    observed_before_reads.set(observed_before_reads.get() + 1);
                    Ok(())
                },
                || held.populate_checkout(&mut close, &cancel),
            )
        },
    );
    phase.next("fresh-checkout-ack.retained-failure-witness");
    let OrdinaryCheckoutPopulationFailure { step, cause, held } = result
        .err()
        .expect("deliberately withheld close ACK must retain fresh authority");
    assert_eq!(step, AdmissionStep::CommitReturned);
    let primary = cause.to_string();
    assert!(primary.contains(WITHHELD_ACK), "{primary}");
    assert_eq!(close.counts, (refuse_at, refuse_at, refuse_at, 1));
    assert_eq!(reads_after_ack.get(), 0);
    assert_eq!(writers_after_ack.get(), 0);
    assert!(
        reads_before_ack.get() > 0,
        "read guard observed the real driver before ACK"
    );
    assert!(
        writers_before_ack.get() > 0,
        "writer guard observed the real driver before ACK"
    );
    close.require_pins();
    require_owners(&f);
    if let Cut::Owned = cut {
        blocked(&temporary(&f));
    }
    phase.next("fresh-checkout-ack.explicit-holder-release");
    drop(held);
    require_released(&f);
    // Exact durable SQL and native identities, not the close counter, prove
    // which progress survived. These are deliberate caller observations.
    phase.next("fresh-checkout-ack.durable-cut-witness");
    require_cut(&f, cut);
    let new_paths = match cut {
        Cut::Declare => BTreeSet::new(),
        Cut::Owned => BTreeSet::from([stage_path(&f), temporary(&f)]),
    };
    let partial = trees(&f);
    only_checkout_changed(&f, &before, &partial, new_paths);
    if let Cut::Declare = cut {
        phase.next("fresh-checkout-ack.declared-foreign-stage-refusal");
        // Deliberate fixture namespace mutation, with no SQL ownership edit.
        // This checks refusal only; it does not resolve/adopt an allocation
        // gap or represent a crash between native allocation and its journal.
        fs::create_dir(stage_path(&f)).unwrap();
        let _ = refuse_open_without_writer(&f, &cancel);
        require_cut_declared_rows_only(&f);
        fs::remove_dir(stage_path(&f)).unwrap();
        assert_eq!(trees(&f), partial);
    }
    phase.next("fresh-checkout-ack.fresh-resume-open");
    let reopened = OrdinaryCheckoutPopulation::open(
        &f.source,
        &f.destination,
        &f.source_staging.transaction_id,
        &cancel,
    )
    .unwrap_or_else(|e| panic!("fresh partial checkout reopen: {e}"));
    require_owners(&f);
    let mut resumed_close = Close::new(&f, None);
    resumed_close.require_pins();
    phase.next("fresh-checkout-ack.fresh-resume-populate");
    let completed = reopened
        .populate_checkout(&mut resumed_close, &cancel)
        .unwrap_or_else(|e| panic!("fresh partial checkout resume {:?}: {}", e.step, e.cause));
    phase.next("fresh-checkout-ack.resumed-complete-witness");
    assert_eq!(completed.effect(), CheckoutPopulationEffect::Updated);
    require_complete(&f, Some(completed.journal()));
    if let Cut::Owned = cut {
        let Node::Directory(previous_stage) = &partial.2[&stage_path(&f)] else {
            panic!("partial stage identity")
        };
        let Node::File((previous_temp, _, _)) = &partial.2[&temporary(&f)] else {
            panic!("partial TEMP identity")
        };
        let complete = trees(&f);
        assert_eq!(
            &complete.2[&stage_path(&f)],
            &Node::Directory(previous_stage.clone())
        );
        let Node::File((final_inode, _, _)) = &complete.2[&final_path(&f)] else {
            panic!("resumed published inode")
        };
        assert_eq!(
            final_inode, previous_temp,
            "resumed Owned TEMP is published without adopting another inode"
        );
    }
    drop(completed);
    require_released(&f);
    only_checkout_changed(
        &f,
        &before,
        &trees(&f),
        BTreeSet::from([stage_path(&f), final_path(&f)]),
    );
    phase.next("fresh-checkout-ack.complete-replay");
    replay_without_writer(&f, &cancel);
    assert_eq!(
        cause.to_string(),
        primary,
        "fresh progress cannot replace the original ACK error"
    );
    assert_eq!(close.counts, (refuse_at, refuse_at, refuse_at, 1));
}

fn require_cut_declared_rows_only(f: &Fixture) {
    witness::read(&f.destination_database, |c| {
        let journal = checkout_journal::read(c, &f.expected, None).unwrap();
        assert_eq!(journal.rows().len(), 3);
        for key in [RowKey::Header, RowKey::Stage, RowKey::File(0)] {
            assert_eq!(
                journal.row(key).unwrap(),
                &f.expected.declared_row(key).unwrap()
            );
        }
    });
}

#[test]
#[ignore = "ROOT source release and audited owned native child3600/outer3660 required; proposed unmeasured"]
fn managed_ordinary_fresh_checkout_withheld_declare_ack_releases_then_reopens_and_completes() {
    child::run(concat!(module_path!(), "::managed_ordinary_fresh_checkout_withheld_declare_ack_releases_then_reopens_and_completes"), 3600, || withheld_ack_recipe(Cut::Declare));
}

#[test]
#[ignore = "ROOT source release and audited owned native child3600/outer3660 required; proposed unmeasured"]
fn managed_ordinary_fresh_checkout_withheld_owned_ack_releases_then_reopens_and_completes() {
    child::run(concat!(module_path!(), "::managed_ordinary_fresh_checkout_withheld_owned_ack_releases_then_reopens_and_completes"), 3600, || withheld_ack_recipe(Cut::Owned));
}
