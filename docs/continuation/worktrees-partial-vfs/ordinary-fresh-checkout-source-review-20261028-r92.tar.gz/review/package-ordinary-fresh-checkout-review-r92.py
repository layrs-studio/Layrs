"""Archive the original reviewed snapshot, never substituted by live corrections."""
from pathlib import Path
import datetime, hashlib, io, json, tarfile
root, tmp = Path('D:/Layrs/layrs'), Path('D:/Layrs/tmp')
prefix = 'provider-ordinary-fresh-checkout'
manifest_path = tmp / f'{prefix}-review-r92-inputs.json'
report_path = tmp / f'{prefix}-critical-review-r92.json'
manifest, report = [json.loads(p.read_bytes()) for p in [manifest_path, report_path]]
assert [f['id'] for f in report['findings']] == ['R92-01']
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
assert pin(manifest_path)['sha256'] == '5e649c67ac6a67477f37d76992fc99fc416763a1dc91697eae7a9bc7b2e36978'
entries = {}
for e in manifest['files']:
    p = Path(manifest['snapshot']) / e['path']
    assert pin(p) == dict(bytes=e['bytes'], sha256=e['sha256'])
    entries['source/' + e['path']] = p
for e in report['inputs']['supplementary_sources']:
    p = root / e['path']
    assert pin(p) == {k:e[k] for k in ['bytes','sha256']}
    entries['source/' + e['path']] = p
for p in [manifest_path, report_path, tmp / f'{prefix}-review-r92.diff', tmp / 'prepare-ordinary-fresh-checkout-review-r92.py', Path(__file__)]:
    entries['review/' + p.name] = p
record = dict(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Original SOURCE ONLY critical review r92 with R92-01 confirmed test finding. Later ROOT correction is separate. No compilation or runtime qualification.',
    files=[dict(path=n, **pin(p)) for n,p in sorted(entries.items())])
dest = root / 'docs/continuation/worktrees-partial-vfs'
archive = dest / 'ordinary-fresh-checkout-source-review-20261028-r92.tar.gz'
inventory = dest / 'ordinary-fresh-checkout-source-review-inventory-20261028-r92.json'
assert not archive.exists() and not inventory.exists()
data = json.dumps(record,indent=2).encode('utf-8')
with tarfile.open(archive,'x:gz') as tar:
    info = tarfile.TarInfo('manifest.json'); info.size = len(data)
    tar.addfile(info,io.BytesIO(data))
    for n,p in sorted(entries.items()): tar.add(p,arcname=n,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers()) == len(entries)+1
    for e in record['files']:
        data = tar.extractfile(e['path']).read()
        assert len(data) == e['bytes'] and hashlib.sha256(data).hexdigest() == e['sha256']
record['archive'] = dict(path=archive.name,**pin(archive))
with inventory.open('x',encoding='utf-8') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(archive=str(archive),files=len(entries)+1,**pin(archive))))
