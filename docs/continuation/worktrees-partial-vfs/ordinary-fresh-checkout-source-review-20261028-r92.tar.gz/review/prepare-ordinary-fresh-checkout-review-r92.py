from pathlib import Path
import datetime, difflib, hashlib, json, subprocess
root, tmp = Path('D:/Layrs/layrs'), Path('D:/Layrs/tmp')
prefix = 'provider-ordinary-fresh-checkout'
baseline = root / '.layrs-local/validation/provider-ordinary-fresh-private-ready-20261028-r91/source'
old = json.loads((tmp / 'provider-ordinary-checkout-progress-review-r89-inputs.json').read_bytes())
review = json.loads((tmp / 'provider-ordinary-checkout-progress-critical-review-r89.json').read_bytes())
git = lambda *a: subprocess.check_output(['git','-C',str(root),*a]).decode().strip()
head, branch = git('rev-parse','HEAD'), git('branch','--show-current')
assert head == '0fa9954d7208117bcaa84b2a883265e3995da501' and branch == 'feature/worktrees-partial-vfs'
changed = sorted(set(git('diff','--name-only','--','*.rs').splitlines() + git('ls-files','--others','--exclude-standard','--','*.rs').splitlines()))
assert len(changed) == 14, changed
paths = sorted(set([e['path'] for e in old['files']] + [Path(e['path']).relative_to(root).as_posix() for e in review['inputs']['additional_dependencies']] + changed))
snapshot = tmp / f'{prefix}-review-r92-source'
snapshot.mkdir(exist_ok=False)
files, diff = [], []
normal = lambda b: b.decode('utf-8').replace('\r\n','\n')
for rel in paths:
    raw = (root / rel).read_bytes()
    before = (baseline / rel).read_bytes() if (baseline / rel).is_file() else b''
    assert (normal(raw) != normal(before)) == (rel in changed), rel
    if rel in changed:
        diff.extend(difflib.unified_diff(normal(before).splitlines(True),normal(raw).splitlines(True),fromfile='r91/'+rel,tofile='r92/'+rel))
    target = snapshot / rel
    target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(raw)
    files.append(dict(path=rel,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),changed=rel in changed,added=not (baseline/rel).is_file()))
diff_path = tmp / f'{prefix}-review-r92.diff'
with diff_path.open('x',encoding='utf-8') as f:f.write(''.join(diff))
manifest = dict(head=head,branch=branch,snapshot=str(snapshot),baseline=str(baseline),files=files,changed=changed,
    diffSha256=hashlib.sha256(diff_path.read_bytes()).hexdigest(),recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Fresh actual B/C Staging protected checkout population: absent/typed-partial to complete, distinct C Exclusive resources and CAS, strict journal-first writes/readback, pending pins retained on ACK failure, no-writer complete replay. No Ready/admission. Retained checkout strict error ordering. Three native recipes plus SQL Declared/Publishing/Copying/opaque cases and retained ACK observer.',
    execution='Uncompiled/unexecuted source candidate. ROOT75810 exclusively runs retained r91 private Ready candidate; do not interact with session, build or run tests/SQL/natives/fixtures. Source review only; ROOT owns integration and qualification.',
    limits=['Declared filesystem object without durable ownership remains refused; no adoption/deletion resolution provided.',
        'Native recipes are single flat current file; no positive nested/delete, Verified/Publishing/rename-gap or nonempty partial TEMP coverage.',
        'ACK withholding after successful SQLite connection close is not actual OS/xClose failure, crash or owner-loss qualification.',
        'Reconstruction and orchestration duplicate the private Ready/retained patterns rather than a shared extracted engine.',
        'SQL C10 threshold-isolating coverage remains a known evidence gap.'])
path = tmp / f'{prefix}-review-r92-inputs.json'
with path.open('x',encoding='utf-8') as f:json.dump(manifest,f,indent=2)
print(json.dumps(dict(manifest=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),diffSha256=manifest['diffSha256'],files=len(files),changed=len(changed),added=sum(e['added'] for e in files))))
