from editlib import *
s=get(A+'managed_image/complete.rs');i=s.index('    /// Exact current-image lookup')
s=s[:i]+r'''    /// Exact-engine producer from the complete checkpoint or original offline
    /// descriptor owner. Rechunking the SAME verified FileId does not replace
    /// the requested ManifestId; the engine verifies requested chunks + FileId.
    /// Historical-only capture bytes must already have their real family owner.
    pub(in crate::projection::provider) fn copy_required_chunk(
        &mut self, manifest: &FileManifest, ordinal: usize, output: &mut dyn Write, cancel: &Cancellation,
    ) -> Result<()> {
        self.revalidate(cancel)?;
        if let Some(file) = self.retained.files().iter().find(|f| {
            let actual = f.manifest.manifest(); actual.file_id() == manifest.file_id() && actual.byte_length() == manifest.byte_length()
        }) {
            let path = file.path.clone();
            let native = matches!(file.manifest, ManagedManifest::Native(_));
            if native {
                let chunk = stream::exact_chunk(manifest, ordinal)?;
                let mut consumer_error = None;
                let result = self.retained.checkpoint.with_range_reader(&path, chunk.offset(), chunk.byte_length(), |reader| {
                    let copied = stream::copy_verified_chunk(manifest, ordinal, output, cancel, |_, buffer| reader.read_exact(buffer).map_err(Into::into));
                    if let Err(e) = copied {
                        consumer_error = Some(e);
                        return Err(layrs_vfs::Error::Io(io::Error::other("complete image chunk consumer failed")));
                    }
                    Ok(())
                });
                finish_native_copy(result, consumer_error)?;
            } else {
                stream::copy_verified_chunk(manifest, ordinal, output, cancel, |offset, buffer| {
                    self.retained.bytes.read_exact_at(manifest.file_id(), offset, buffer, cancel).map_err(Into::into)
                })?;
            }
        } else {
            if !self.retained.source.descriptors().iter().any(|d| &d.manifest == manifest) {
                return Err(invalid("historical representation has no retained checkpoint/original offline byte owner"));
            }
            stream::copy_verified_chunk(manifest, ordinal, output, cancel, |offset, buffer| {
                self.retained.bytes.read_exact_at(manifest.file_id(), offset, buffer, cancel).map_err(Into::into)
            })?;
        }
        self.revalidate(cancel)
    }

''' +s[i:];put(A+'managed_image/complete.rs',s)
s=get(M+'exact.rs')
a=s.index('                    let path = current_path.as_ref().ok_or_else(');b=s.index('                }\n                exact_content::finish_piece',a)
s=s[:a]+'''                    let ordinal = piece.ordinal();
                    piece.produce(|sink| match &mut self.image {
                        super::companion::ManagedImage::Complete(image) => image.copy_required_chunk(&manifest, ordinal, sink, cancel),
                        super::companion::ManagedImage::Legacy(image) => {
                            let path = current_path.as_ref().ok_or_else(|| invalid("exact historical content unavailable from retained current image"))?;
                            image.copy_exact_chunk(path, &manifest, ordinal, sink, cancel)
                        }
                    }, cancel)?;
''' +s[b:];put(M+'exact.rs',s)
# A genuine retained complete checkpoint can enter Planned and Staging without
# running the strict legacy image rehasher. SQL writers still validate owners.
s=get(A+'managed_journal.rs');a=s.index('pub(super) fn begin(');b=s.index('/// Cancellation retains',a)
complete=s[a:b].replace('fn begin(','fn begin_complete(').replace("managed_image::VerifiedManagedImage<'_, '_>","managed_image::complete::VerifiedCompleteManagedImage<'_, '_>").replace('image.revalidate_and_match_digest(&version.effective_image_digest, cancel)?;','image.revalidate(cancel)?;\n    image.require_retained(root, &version.effective_image_digest, cancel)?;').replace('Some(image),','Some(image.retained()),')
s=s[:b]+complete+s[b:];put(A+'managed_journal.rs',s)
s=get(A+'managed_staging.rs');a=s.index('pub(super) fn stage(')
complete=s[a:].replace('fn stage(','fn stage_complete(').replace("managed_image::VerifiedManagedImage<'_, '_>","managed_image::complete::VerifiedCompleteManagedImage<'_, '_>").replace('image.revalidate_and_match_digest(&version.effective_image_digest, cancel)?;','image.revalidate(cancel)?;\n    image.require_retained(root, &version.effective_image_digest, cancel)?;').replace('                image,\n                destination,','                image.retained(),\n                destination,')
s=s+'\n/// Complete-checkpoint counterpart. Legacy stage retains its strict image guard.\n'+complete
put(A+'managed_staging.rs',s)
print('real complete-image begin/Staging and offline exact-byte producer connected')
