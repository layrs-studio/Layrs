from editlib import *
import hashlib
fix=Path('D:/Layrs/tmp/provider-observation-prefix-domain-fix')
assert hashlib.sha256((fix/'manifest.sha256.json').read_bytes()).hexdigest()=='a6ece02687428485849bb451c51a14e128b3c11f96ccf1d6258a228b41f5ef43'
for q in (fix/'files').rglob('*.rs'): put(q.relative_to(fix/'files').as_posix(),q.read_text())
# Keep all physical engine code from exact HEAD; all callbacks now retain the full publication.
for rel in ['exact.rs','checkout.rs','ready.rs','ready_data.rs','publication.rs']:
 get(M+rel)
for rel in ['managed_content.rs']:
 s=get(A+rel).replace('PrivateActiveCaptureValidation','PrivateActivePublicationValidation')
 s=s.replace('mod source_protection;','mod companion;\nmod source_protection;')
 s=s.replace("image: &'h mut managed_image::VerifiedManagedImage<'a, 'c>,\n    staging:","image: companion::ManagedImage<'h, 'a, 'c>,\n    companion: Option<companion::CompanionLeaseData<'h>>,\n    staging:",1)
 s=s.replace('            image,\n            staging,','            image: companion::ManagedImage::Legacy(image),\n            companion: None,\n            staging,',1)
 s=s.replace('source_context: None,','source_context: self.companion.as_ref().map(|data| data.context(proof)),')
 s=s.replace('managed_destination::with_source(\n            self.held,\n            self.root,\n            self.mount,\n            self.activation,\n            self.attempt,\n            self.staging,\n            self.destination,\n            cancel,','self.with_source(cancel,')
 start=s.index('let derived = managed_plan::rederive_reservation(');end=s.index(')?;',start)+3
 s=s[:start]+'''let derived = self.rederive(source_c, closure, proof, cancel)?;'''+s[end:]
 put(A+rel,s)
for rel in ['exact.rs','checkout.rs','protection.rs','ready.rs','publication.rs']:
 s=get(M+rel).replace('PrivateActiveCaptureValidation','PrivateActivePublicationValidation')
 s=s.replace('managed_destination::with_source(\n            self.held,\n            self.root,\n            self.mount,\n            self.activation,\n            self.attempt,\n            self.staging,\n            self.destination,\n            cancel,','self.with_source(cancel,')
 if 'let derived = managed_plan::rederive_reservation(' in s:
  start=s.index('let derived = managed_plan::rederive_reservation(');end=s.index(')?;',start)+3
  s=s[:start]+'let derived = self.rederive(source_c, closure, proof, cancel)?;'+s[end:]
 s=s.replace('OwnedReadyData::new(\n                    derived,\n                    self.staging,\n                    self.image,\n                    self.manifests,\n                    protected.root(),\n                    cancel,\n                )?','self.ready_data(derived, protected.root(), cancel)?')
 # Ready inputs obtain the same closed rows/B protection/full source proof.
 s=s.replace('                    data: &data,','                    data: &data,\n                    companion: self.ready_companion(proof),')
 put(M+rel,s)
s=get(M+'source_publication.rs');start=s.index('let derived = managed_plan::rederive_publication_reservation(');end=s.index(')?;',start)+3
s=s[:start]+'let derived = self.rederive(source_c, &closure, &proof, cancel)?;'+s[end:]
start=s.index('let owned = OwnedReadyData::new(');end=s.index(')?;',start)+3
s=s[:start]+'let owned = self.ready_data(derived, protected.root(), cancel)?;'+s[end:]
s=s.replace('            data: &data,','            data: &data,\n            companion: self.ready_companion(&proof),')
put(M+'source_publication.rs',s)
# Protection no longer borrows the mutable complete checkpoint. The lease owns that borrow.
s=get(M+'source_protection.rs').replace("    image: &'s VerifiedCompleteManagedImage<'s, 'a>,\n",'')
s=s.replace('self.image\n            .require_retained(lease.root, &version.effective_image_digest, cancel)?;','lease.image.require_retained(lease.root, &version.effective_image_digest, cancel)?;')
s=s.replace("        image: &'s mut VerifiedCompleteManagedImage<'s, 'a>,\n",'')
s=s.replace('        image.revalidate(cancel)?;','        self.image.require_retained(self.root, self.image.digest(), cancel)?;')
s=s.replace('ManagedSourceCompanionProtection { data, image, bytes }','ManagedSourceCompanionProtection { data, bytes }')
put(M+'source_protection.rs',s)
# Explicit rollback before any enclosing reader close for every C writer.
for rel in ['exact.rs','checkout.rs','protection.rs','ready.rs','publication.rs']:
 s=get(M+rel).replace('bare.finish_writer(result, close)','bare.finish_writer(super::source_protection::rollback(bare.connection(), result), close)')
 put(M+rel,s)
s=get(A+'managed_content.rs').replace('bare.finish_writer(result, close)','bare.finish_writer(source_protection::rollback(bare.connection(), result), close)');put(A+'managed_content.rs',s)
edit(M+'source_protection.rs','fn rollback<T>','pub(super) fn rollback<T>')
# Publication companion methods retain DATA, not a capture permission.
s=get(P+'transition_reconcile/source.rs')
a=s.index('    pub(in crate::projection::provider) fn provider_descriptor_view(');b=s.index('    pub(in crate::projection::provider) fn normalize(',a)
addition=s[a:b].replace('provider_descriptor_view','publication_descriptor_view').replace('with_provider_descriptors','with_publication_descriptors').replace('require_provider_descriptors','require_publication_descriptors').replace('PrivateActiveCaptureValidation','PrivateActivePublicationValidation')
s=s[:b]+addition+s[b:]
a=s.index('    pub(super) fn companion_catalog(');b=s.index('    pub(super) fn require_observation',a)
addition=s[a:b].replace('companion_catalog','publication_companion_catalog').replace('PrivateActiveCaptureValidation','PrivateActivePublicationValidation').replace('require_provider_inputs','require_publication_inputs')
s=s[:b]+addition+s[b:];put(P+'transition_reconcile/source.rs',s)
s=get(P+'transition_reconcile/companions.rs');a=s.index('    pub(in crate::projection::provider) fn derive(');b=s.index('    fn from_reconciled',a)
addition=s[a:b].replace('fn derive(','fn derive_publication(').replace('PrivateActiveCaptureValidation','PrivateActivePublicationValidation').replace('source.companion_catalog','source.publication_companion_catalog')
s=s[:b]+addition+s[b:]
# Closed equality includes all heavy data. No synthetic grants.
s=s.replace('pub(in crate::projection::provider) struct AuthorizedFileData','#[derive(Debug, PartialEq, Eq)]\npub(in crate::projection::provider) struct AuthorizedFileData').replace('pub(in crate::projection) struct OwnedCompanionData','#[derive(PartialEq, Eq)]\npub(in crate::projection) struct OwnedCompanionData').replace('struct OwnedInheritedData','#[derive(PartialEq, Eq)]\nstruct OwnedInheritedData')
put(P+'transition_reconcile/companions.rs',s)
# Immutable reconcile against the SAME retained checkpoint while SQL is held: no content callback.
s=get(A+'managed_image/complete.rs');i=s.index('    /// Exact current-image lookup')
s=s[:i]+'''    pub(in crate::projection::provider) fn retained(&self) -> &VerifiedManagedImage<'_, '_> { &self.retained }
    pub(in crate::projection::provider) fn require_owner(&self, root: &layrs_vfs::ProviderRootGuard, source: &ProviderBootstrapSource, activated: &ProjectionSnapshot) -> Result<()> {
        self.retained.require_owner(root, source, activated)
    }
    pub(in crate::projection::provider) fn reconcile_publication_retained(
        &self, source: &ReconcileSourceData<'_>, observation: &TransitionObservationData,
        proof: &crate::projection::provider::validation::PrivateActivePublicationValidation,
        manifests: &[FileManifest], metadata: u64, cancel: &Cancellation,
    ) -> Result<OwnedCompanionData> {
        let source = source.publication_descriptor_view(proof, Some(cancel))?;
        self.retained.require_source(&proof.active.source, &proof.active.activated.snapshot)?;
        let views = self.retained.files().iter().map(|f| ImageFileData {
            path: &f.path, manifest: f.manifest.manifest(), executable: Some(f.executable),
        }).collect::<Vec<_>>();
        let complete = CompleteSourceImageData::from_checkpoint(&source, &*self.retained.checkpoint, &views, Some(cancel))?;
        OwnedCompanionData::derive_publication(&source, &complete, observation, manifests, metadata, Some(proof), Some(cancel))
    }
''' +s[i:];put(A+'managed_image/complete.rs',s)
print('lease dispatch and full-proof callback groundwork written')
