from editlib import *
# Reuse the same bounded scalar decoder for incoming and local retained groups.
s=get(P+'transition_reconcile/source_sql.rs')
a=s.index('        let payload: Vec<u8>');b=s.index('        groups.push((header, files, deletions));',a)
body=s[a:b].replace('        header.as_ref().require_receipt(receipt)?;\n','')
s=s[:a]+'''        let (header, files, deletions) = read_group(c, id, cancel)?;
        header.as_ref().require_receipt(receipt)?;
''' +s[b:]
s+='''\n/// Caller has already performed complete schema and scalar preflight.\npub(in crate::projection::provider) fn read_group(c: &Connection, id: &str, cancel: Option<&Cancellation>) -> Result<(CompanionHeaderRecord, Vec<ProviderCompanionFileRecord>, Vec<ProviderCompanionDeletionRecord>)> {\n'''+body+'''    Ok((header, files, deletions))\n}\n'''
put(P+'transition_reconcile/source_sql.rs',s)
# Canonical local C provenance uses its actual observation, unlike B outgoing.
s=get(P+'import_validation/scoped.rs');a=s.index('pub(in crate::projection::provider) fn validate_outgoing_companion(')
local=s[a:].replace('fn validate_outgoing_companion(','fn validate_local_companion(').replace('        true,','        false,')
s+='\n/// Retained C-local companion provenance, including actual satisfied-absence observation.\n'+local
put(P+'import_validation/scoped.rs',s)
edit(P+'import_validation.rs','pub(in crate::projection::provider) use scoped::validate_outgoing_companion;','pub(in crate::projection::provider) use scoped::{validate_outgoing_companion, validate_local_companion};')
# Row byte accounting remains shared with closed reconcile, no new quota model.
edit(P+'transition_reconcile/companions.rs','fn sql_bytes(','pub(in crate::projection::provider) fn sql_bytes(')
# ReadyView has a distinct privately constructed retained variant: never a live row-owner fabrication.
s=get(P+'destination_ready.rs').replace('mod historical;','mod historical;\nmod retained_companion;')
s=s.replace("    companion: Option<&'a ManagedCompanionReadyData<'a>>,","    companion: Option<&'a ManagedCompanionReadyData<'a>>,\n    retained_companion: Option<&'a retained_companion::RetainedCompanionReadyData>,")
s=s.replace('            companion: self.companion.as_ref(),','            companion: self.companion.as_ref(),\n            retained_companion: None,')
s=s.replace('''        match self.companion {
            Some(c) => c.observation.selection(),
            None => self.source.selection(),
        }''','''        match (self.companion, self.retained_companion) {
            (Some(c), None) => c.observation.selection(),
            (None, Some(c)) => c.selection(),
            _ => self.source.selection(),
        }''')
s=s.replace('''        let Some(c) = self.companion else {''','''        if let Some(retained) = self.retained_companion {
            if self.companion.is_some() { return Err(invalid("Ready companion modes overlap")); }
            return retained.require_data(self.data, self.prefix, cancel);
        }
        let Some(c) = self.companion else {''',1)
i=s.index('    fn require_companion(&self,')
s=s[:i]+'''    fn has_companion(&self) -> bool { self.companion.is_some() || self.retained_companion.is_some() }
    fn companion_header(&self) -> Option<&super::records::companion_v2::CompanionHeaderV2> {
        self.companion.and_then(|c| c.rows.header()).or_else(|| self.retained_companion.map(|c| c.header()))
    }
    fn companion_mapping(&self, file: &FileId) -> Option<&(FileManifestId, u64)> {
        self.companion.and_then(|c| c.rows.source_mappings().get(file))
            .or_else(|| self.retained_companion.and_then(|c| c.mapping(file)))
    }
''' +s[i:]
s=s.replace('(inputs.companion.is_some() && entry.state == EntryState::Reserved)','(inputs.has_companion() && entry.state == EntryState::Reserved)')
s=s.replace('''            let bytes = match inputs.companion {
                None => inputs.source.unchanged_bytes(''','''            let bytes = match (inputs.companion, inputs.retained_companion) {
                (None, None) => inputs.source.unchanged_bytes(''')
s=s.replace('''                Some(c) => c
                    .observation''','''                (Some(c), None) => c
                    .observation''')
# inspect formatting-specific match later if needed
needle='''                    .bytes,
            };'''
s=s.replace(needle,'''                    .bytes,
                (None, Some(c)) => c.length(file_id)?,
                _ => return Err(invalid("Ready companion modes overlap")),
            };''')
put(P+'destination_ready.rs',s)
for rel in ['destination_ready/ordinary.rs','destination_ready/autonomous.rs']:
 s=get(P+rel).replace('companion: None,','companion: None,\n            retained_companion: None,');put(P+rel,s)
s=get(P+'destination_ready/data.rs').replace('ready.plan.companion_id.is_some() != inputs.companion.is_some()','ready.plan.companion_id.is_some() != inputs.has_companion()')
a=s.index('            let (id, bytes) = inputs\n                .companion');b=s.index('            if !required',a)
s=s[:a]+'''            let (id, bytes) = inputs.companion_mapping(manifest.file_id())
                .map_or((manifest.id(), manifest.byte_length()), |(id, bytes)| (id, *bytes));
''' +s[b:];put(P+'destination_ready/data.rs',s)
s=get(P+'destination_ready/read.rs').replace('u64::from(inputs.companion.is_some())','u64::from(inputs.has_companion())')
import re
s=re.sub(r'inputs\.companion\.map_or\(0, \|c\|\s*c\.rows\.header\(\)\.map_or\(0, \|h\| h\.(file_count|deletion_count)\)\s*\)',r'inputs.companion_header().map_or(0, |h| h.\1)',s)
s=s.replace('    let receipt = inputs.data.receipt;','    if let Some(retained) = inputs.retained_companion { retained.require_rows(c, cancel)?; }\n    let receipt = inputs.data.receipt;')
put(P+'destination_ready/read.rs',s)
print('retained/local companion DATA mode scaffolding wired')
