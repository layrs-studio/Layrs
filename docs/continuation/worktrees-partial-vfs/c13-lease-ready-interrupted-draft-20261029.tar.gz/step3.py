from editlib import *
put(P+'transition_reconcile/source_sql.rs',r'''//! Rebuild reconciliation inputs from the frozen SQL closure. No nominated
//! row vector is accepted. All rows are DATA inside the retained source read.
use super::*;
use crate::projection::provider::{
    import_validation::{self, ImportDatabaseKind},
    records::companion_v2::CompanionHeaderRecord,
    validation::PrivateActivePublicationValidation,
};
use rusqlite::Connection;

pub(in crate::projection::provider) fn with_source<T>(
    c: &Connection, marker: &crate::projection::format::Marker,
    prefix: &super::super::records::import::ProviderImportPrefixRecord,
    closure: &VerifiedImportClosure, proof: &PrivateActivePublicationValidation,
    observed: &TransitionObservationData, cancel: Option<&Cancellation>,
    action: impl FnOnce(&ReconcileSourceData<'_>) -> Result<T>,
) -> Result<T> {
    closure.require_source_connection(c)?;
    closure.require_publication_inputs(proof)?;
    let mappings = closure.copied_content_mappings(c, prefix, cancel)?;
    let lineage = import_validation::read_ancestry(c, marker, ImportDatabaseKind::Provider, prefix, cancel)?;
    let mut groups = Vec::new();
    for receipt in lineage.receipts() {
        cancellation::check(cancel)?;
        let Some(id) = &receipt.companion_id else { continue };
        let payload: Vec<u8> = c.query_row(
            "SELECT payload FROM projection_provider_companions WHERE id=?1 AND length(payload)<=65536", [id], |r| r.get(0))?;
        let header = CompanionHeaderRecord::decode(&payload)?;
        header.as_ref().require_receipt(receipt)?;
        let mut files = Vec::new();
        let mut statement = c.prepare("SELECT path,file_id,bytes,executable,manifest_id,base_file_id,base_executable,reason FROM projection_provider_companion_files WHERE companion_id=?1 ORDER BY path COLLATE BINARY LIMIT 100001")?;
        let mut rows = statement.query([id])?;
        while let Some(row) = rows.next()? {
            cancellation::check(cancel)?;
            let reason: String = row.get(7)?;
            files.push(ProviderCompanionFileRecord {
                schema_version: "layrs.projection-provider-companion-file.v1".into(),
                path: RepoPath::parse(row.get::<_, String>(0)?).map_err(|e| invalid(e.to_string()))?,
                file_id: FileId::parse(row.get::<_, String>(1)?).map_err(|e| invalid(e.to_string()))?,
                bytes: row.get(2)?, executable: row.get(3)?,
                manifest_id: FileManifestId::parse(row.get::<_, String>(4)?).map_err(|e| invalid(e.to_string()))?,
                base_file_id: row.get::<_, Option<String>>(5)?.map(FileId::parse).transpose().map_err(|e| invalid(e.to_string()))?,
                base_executable: row.get(6)?,
                reason: serde_json::from_value(serde_json::Value::String(reason)).map_err(|e| invalid(e.to_string()))?,
            });
        }
        let mut deletions = Vec::new();
        let mut statement = c.prepare("SELECT path,base_file_id,base_executable,base_manifest_id,reason FROM projection_provider_companion_deletions WHERE companion_id=?1 ORDER BY path COLLATE BINARY LIMIT 100001")?;
        let mut rows = statement.query([id])?;
        while let Some(row) = rows.next()? {
            cancellation::check(cancel)?;
            let reason: String = row.get(4)?;
            deletions.push(ProviderCompanionDeletionRecord {
                schema_version: "layrs.projection-provider-companion-deletion.v1".into(),
                path: RepoPath::parse(row.get::<_, String>(0)?).map_err(|e| invalid(e.to_string()))?,
                base_file_id: FileId::parse(row.get::<_, String>(1)?).map_err(|e| invalid(e.to_string()))?,
                base_executable: row.get(2)?,
                base_manifest_id: row.get::<_, Option<String>>(3)?.map(FileManifestId::parse).transpose().map_err(|e| invalid(e.to_string()))?,
                reason: serde_json::from_value(serde_json::Value::String(reason)).map_err(|e| invalid(e.to_string()))?,
            });
        }
        header.as_ref().validate_rows(&files, &deletions)?;
        groups.push((header, files, deletions));
    }
    let inherited = groups.iter().map(|(header, files, deletions)| InheritedCompanionData {
        header: header.as_ref(), files, deletions,
    }).collect::<Vec<_>>();
    let source = &proof.active.source;
    let input = SourceObservationData {
        prefix, identity: &marker.identity, snapshot: &proof.active.activated.snapshot,
        snapshot_parent_digest: Some(&proof.active.activation.source_digest),
        selection: source.selection(), selection_generation: source.commitment().source_generation,
        selection_snapshot_digest: &source.commitment().snapshot_digest,
    };
    let normalized = ReconcileSourceData::normalize(input, closure, &proof.capture.patches,
        &mappings, lineage.receipts(), &inherited, observed, cancel)?
        .with_publication_descriptors(proof, cancel)?;
    action(&normalized)
}
''')
edit(P+'transition_reconcile.rs','mod source;','mod source;\npub(in crate::projection::provider) mod source_sql;')
put(M+'companion.rs',r'''//! Complete-checkpoint route. All immutable DATA is rederived from the actual
//! source transaction before any C callback. No network callback runs here.
use super::*;
use crate::projection::{
    provider::{
        destination_ready::ManagedCompanionReadyData,
        records::import::ImportSourceReferences,
        source_companion::SourceCompanionPublication,
        transition_observation::TransitionObservationData,
        transition_reconcile::{companions::OwnedCompanionData, source_sql},
        validation::{self, PrivateActivePublicationValidation},
    },
    shared::{exact_protection::ExactProtection, source_companion::SourceCompanionFamilyContext},
};
use super::super::managed_image::{self, complete::VerifiedCompleteManagedImage, ManagedFile, ManagedDeletion};
use std::io::Write;
use layrs_core::scm::RepoPath;

pub(super) enum ManagedImage<'h, 'a, 'c> {
    Legacy(&'h mut managed_image::VerifiedManagedImage<'a, 'c>),
    Complete(&'h mut VerifiedCompleteManagedImage<'a, 'c>),
}
impl<'a, 'c> ManagedImage<'_, 'a, 'c> {
    fn retained(&self) -> &managed_image::VerifiedManagedImage<'a, 'c> {
        match self { Self::Legacy(i) => i, Self::Complete(i) => i.retained() }
    }
    pub(super) fn digest(&self) -> &str { self.retained().digest() }
    pub(super) fn files(&self) -> &[ManagedFile<'a>] { self.retained().files() }
    pub(super) fn deletions(&self) -> &[ManagedDeletion] { self.retained().deletions() }
    pub(super) fn require_owner(&self, root: &layrs_vfs::ProviderRootGuard, source: &ProviderBootstrapSource, activated: &ProjectionSnapshot) -> CauseResult<()> {
        self.retained().require_owner(root, source, activated)
    }
    pub(super) fn require_retained(&self, root: &layrs_vfs::ProviderRootGuard, digest: &str, cancel: &Cancellation) -> CauseResult<()> {
        match self {
            Self::Complete(i) => i.require_retained(root, digest, cancel),
            Self::Legacy(_) => Err(invalid("source companion witness requires retained complete checkpoint")),
        }
    }
    pub(super) fn revalidate_and_match_digest(&mut self, digest: &str, cancel: &Cancellation) -> CauseResult<()> {
        match self {
            Self::Legacy(i) => i.revalidate_and_match_digest(digest, cancel),
            Self::Complete(i) => { i.revalidate(cancel)?; if i.digest() != digest { return Err(invalid("complete lease image digest differs")); } Ok(()) }
        }
    }
    pub(super) fn copy_exact_chunk(&mut self, path: &RepoPath, manifest: &FileManifest, ordinal: usize, output: &mut dyn Write, cancel: &Cancellation) -> CauseResult<()> {
        match self { Self::Legacy(i) => i.copy_exact_chunk(path, manifest, ordinal, output, cancel), Self::Complete(i) => i.copy_exact_chunk(path, manifest, ordinal, output, cancel) }
    }
    pub(super) fn copy_exact_file(&mut self, path: &RepoPath, manifest: &FileManifest, output: &mut dyn Write, cancel: &Cancellation) -> CauseResult<()> {
        match self { Self::Legacy(i) => i.copy_exact_file(path, manifest, output, cancel), Self::Complete(i) => i.copy_exact_file(path, manifest, output, cancel) }
    }
}

pub(super) struct CompanionLeaseData<'h> {
    publication: &'h SourceCompanionPublication<'h>,
    observation: &'h TransitionObservationData,
    metadata_without_companions: u64,
}
impl CompanionLeaseData<'_> {
    pub(super) fn context<'p>(&'p self, full: &'p PrivateActivePublicationValidation) -> SourceCompanionFamilyContext<'p> {
        SourceCompanionFamilyContext { publication: full, pending: Some(self.publication.protection()) }
    }
}
impl<'h, 'd, 'a, 'c> ManagedImportLease<'h, 'd, 'a, 'c> {
    /// Trusted Store host boundary after point-in-time remote observation and
    /// exact source anchoring. The complete checkpoint stays borrowed by this
    /// lease; DATA cannot reconstruct it, source ownership or remote authority.
    #[allow(clippy::too_many_arguments)]
    pub(super) fn open_companion(
        held: &'h outcome::PublicationPins, root: &'h layrs_vfs::ProviderRootGuard,
        mount: &'h ProviderActiveMountRecord, activation: &'h ProviderActivationRecord,
        attempt: &'h CaptureAttemptLock,
        destination: &'h managed_allocation::ManagedDestinationAllocation<'d>,
        image: &'h mut VerifiedCompleteManagedImage<'a, 'c>,
        staging: &'h ProviderTransitionIntentRecord,
        publication: &'h SourceCompanionPublication<'h>, observation: &'h TransitionObservationData,
        metadata_without_companions: u64, cancel: &Cancellation,
    ) -> CauseResult<Self> {
        if observation.binding().denied_path_count != 0 {
            return Err(invalid("C14 durable denied-absence contract required before effects"));
        }
        let mut lease = Self {
            held, root, mount, activation, attempt, destination,
            image: ManagedImage::Complete(image),
            companion: Some(CompanionLeaseData { publication, observation, metadata_without_companions }),
            staging, manifests: publication.rows().manifests(), fresh: observation.snapshot(),
        };
        lease.rehash(cancel)?;
        // Opening rederives every row/representation/observation but permits an
        // absent B reservation. reserve_source_companion is the FIRST effect.
        lease.with_source(cancel, |c, full, closure| {
            lease.rederive(c, closure, full, cancel)?;
            publication.require(&held.artifacts.allocation, staging, publication.receipt(), Some(cancel))?;
            Ok(())
        })?;
        Ok(lease)
    }

    /// Transition-specific original-prefix validation. This deliberately does
    /// not invoke transition_source()'s no-pending gate once a plan is pending.
    pub(super) fn with_source<T>(&self, cancel: &Cancellation,
        action: impl FnOnce(&Connection, &PrivateActivePublicationValidation, &VerifiedImportClosure) -> CauseResult<T>,
    ) -> CauseResult<T> {
        self.boundary(cancel)?;
        managed_destination::valid(database_io::read_cancellable(&self.held.artifacts.database, cancel, |c| {
            let prepared = self.held.artifacts.prepared.as_ref().ok_or_else(|| invalid("complete lease prepared source absent"))?;
            let full = validation::private_active_publication_with_source(c, &self.held.artifacts.allocation, prepared,
                &self.held.binding, Some(self.root.registration().root_id()), Some(cancel))?;
            if full.active.mount != *self.mount || full.active.activation != *self.activation
                || full.transitions.iter().find(|i| i.transaction_id == self.staging.transaction_id) != Some(self.staging)
            { return Err(invalid("complete lease original source Staging changed")); }
            let ImportSource::Provider { version, .. } = &self.staging.plan.source_prefix.source else { return Err(invalid("complete lease provider prefix absent")); };
            let closure = crate::projection::provider::import_validation::verify_source_publication(c,
                &self.held.artifacts.allocation.format, &self.staging.plan.source_prefix,
                ImportSourceReferences::Provider { allocation: &self.held.artifacts.allocation, prepared, activation: &full.active.activation },
                &full, &version.effective_image_digest, Some(cancel))?;
            self.image.require_owner(self.root, &full.active.source, &full.active.activated.snapshot)?;
            let result = action(c, &full, &closure)?;
            self.boundary(cancel)?;
            Ok(result)
        })?)
    }

    pub(super) fn rederive(&self, c: &Connection, closure: &VerifiedImportClosure,
        full: &PrivateActivePublicationValidation, cancel: &Cancellation,
    ) -> CauseResult<managed_plan::ManagedPlanData> {
        let Some(data) = &self.companion else {
            return managed_plan::rederive_publication_reservation(c, closure, self.image.retained(), full,
                self.fresh, self.staging, self.manifests, cancel);
        };
        let ManagedImage::Complete(image) = &self.image else { return Err(invalid("companion lease complete checkpoint absent")); };
        let rows = source_sql::with_source(c, &self.held.artifacts.allocation.format,
            &self.staging.plan.source_prefix, closure, full, data.observation, Some(cancel), |source| {
                image.reconcile_publication_retained(source, data.observation, full, self.manifests, data.metadata_without_companions, cancel)
            })?;
        if &rows != data.publication.rows() { return Err(invalid("complete lease reconcile rows, sticky mappings or full union changed")); }
        let p = &self.staging.plan;
        let mut derived = managed_plan::derive_reconciled_data(&p.source_prefix, &rows, data.observation,
            p.source_prefix.destination_identity.clone(), &p.destination_parent, &p.destination_parent_identity,
            &p.destination_leaf_nonce, &self.staging.transaction_id)?;
        if derived.plan != *p || derived.required_manifests.len() != self.manifests.len() {
            return Err(invalid("complete lease immutable plan differs from source rederivation"));
        }
        let destination = managed_destination::destination_intent(self.staging)?;
        let minimum = crate::projection::provider::managed_budget::base_metadata_floor(
            closure.metadata_bytes(c, &p.source_prefix, Some(cancel))?, &derived.observation, &derived.placement,
            &derived.capture, p, data.observation.selection(),
            crate::projection::provider::managed_budget::intent_size(self.staging)?,
            crate::projection::provider::managed_budget::intent_size(&destination)?)?;
        if rows.metadata_bytes() < minimum { return Err(invalid("companion lease source-rederived metadata floor insufficient")); }
        derived.validated_metadata_floor = Some(minimum.checked_add(rows.source_row_bytes()?).ok_or_else(|| invalid("companion Ready metadata overflow"))?);
        Ok(derived)
    }
    pub(super) fn ready_data(&self, derived: managed_plan::ManagedPlanData, root: &ExactProtection, cancel: &Cancellation) -> CauseResult<super::ready_data::OwnedReadyData> {
        match &self.companion {
            None => super::ready_data::OwnedReadyData::new(derived, self.staging, self.image.retained(), self.manifests, root, cancel),
            Some(data) => super::ready_data::OwnedReadyData::new_companion(derived, self.staging, self.image.digest(), self.manifests, root, data.publication.rows(), cancel),
        }
    }
    pub(super) fn ready_companion<'p>(&'p self, full: &'p PrivateActivePublicationValidation) -> Option<ManagedCompanionReadyData<'p>> {
        self.companion.as_ref().map(|data| ManagedCompanionReadyData {
            rows: data.publication.rows(), observation: data.observation, source_context: data.context(full),
        })
    }

    /// Actual production Store driver: B reserve -> C exact/install/protect ->
    /// B protect -> authorized checkout -> genuine private/family Ready -> B
    /// Ready atom -> separate Published. Every scope observes positive closes.
    /// The callback can request same-owner terminal replay while all proofs
    /// and the SAME mutable checkpoint are still retained, without self-reference.
    pub(super) fn with_published_companion<T>(
        &mut self, close: &mut impl WriterCloseObserver, cancel: &Cancellation,
        action: impl FnOnce(&mut Self, &super::publication::ManagedFamilyReady<'_, '_>,
            &super::source_protection::ManagedSourceCompanionProtection<'_, '_>) -> CauseResult<T>,
    ) -> CauseResult<T> {
        let data = self.companion.as_ref().ok_or_else(|| invalid("complete companion route absent"))?.publication;
        self.reserve_source_companion(data, close, cancel)?;
        self.reserve_plan(close, cancel)?;
        for index in 0..self.manifests.len() {
            let id = self.manifests[index].id().clone();
            self.install_exact(&id, close, cancel)?;
        }
        let protected = self.protect_exact(close, cancel)?;
        let source = self.protect_source_companion(data, close, cancel)?;
        let checkout = self.copy_checkout(&protected, close, cancel)?;
        let private = self.finalize_private_ready(&protected, &checkout, close, cancel)?;
        let family = self.publish_family_ready(&private, close, cancel)?;
        self.publish_source_companion(&family, &source, close, cancel)?;
        action(self, &family, &source)
    }
}
''')
print('source SQL rebuild and connected Store production route written')
