from pathlib import Path
import json,hashlib,subprocess,difflib
O=Path('D:/Layrs/tmp/c13-complete-lease-ready-source-proposal');O.mkdir(exist_ok=True)
A=Path('D:/Layrs/tmp/c13-source-protection-source-proposal');B=Path('D:/Layrs/tmp/provider-transition-source-anchor-proposal')
assert hashlib.sha256((A/'manifest.sha256.json').read_bytes()).hexdigest()=='601c7e851214849c418c04d9852c8ccd1622243c8899a921e9e9c93aa3516c69'
assert hashlib.sha256((A/'proposal.patch').read_bytes()).hexdigest()=='c1e53502d0691c1d27727435c555f0d5a70fece7f6f33aab20bbe3b098290987'
assert hashlib.sha256((B/'manifest.sha256.json').read_bytes()).hexdigest()=='b715fce9b14728026def9cf64fcbe81fb237d80b2a8fcc01611c3ebcd315e7bf'
for root in [A,B]:
 for p in (root/'files').rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(root/'files');out=O/'files'/rel
  if root==B and out.exists():
   if rel.name=='validation.rs':continue
   base=subprocess.run(['git','show','6b1f5632bd7f6092226d57e3c813033a82bcfc98:'+rel.as_posix()],cwd='D:/Layrs/layrs',capture_output=True,check=True).stdout.decode()
   src=out.read_text();variant=p.read_text();sm=difflib.SequenceMatcher(None,base.splitlines(True),variant.splitlines(True))
   for tag,i,j,k,l in reversed(sm.get_opcodes()):
    if tag=='equal':continue
    before=''.join(base.splitlines(True)[i:j]);after=''.join(variant.splitlines(True)[k:l])
    if before:
     if before not in src:raise RuntimeError(str(rel)+' conflict '+repr(before))
     src=src.replace(before,after,1)
    else:
     anchor=''.join(base.splitlines(True)[max(0,i-2):i]);assert anchor in src,(rel,anchor)
     src=src.replace(anchor,anchor+after,1)
   out.write_text(src,newline='\n')
  else:
   out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
print('preserved all 53 input paths; merged source anchor')
