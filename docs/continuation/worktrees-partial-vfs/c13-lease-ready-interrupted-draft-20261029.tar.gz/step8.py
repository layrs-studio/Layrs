from editlib import *
put(P+'destination_ready/retained_companion.rs',r'''//! Autonomous C-local SQL DATA. Construction reads actual retained rows and
//! validates C's own receipt/protection. It never recreates B/native/remote
//! authority and never opens a source path. Unprovable image forms refuse.
use super::*;
use crate::projection::{offline, provider::{
    checkout_journal::{CheckoutFile, ExpectedCheckout},
    import_validation::{self, VerifiedDestinationPrefix},
    records::{companion_v2::{CompanionHeaderRecord, CompanionHeaderV2}, import::{ProviderCompanionFileRecord, ProviderCompanionDeletionRecord}},
    transition_reconcile::{source_sql, companions::sql_bytes},
}};
use layrs_core::projection::{EntryState, ProjectionSelection};
use layrs_core::scm::TreeEntryTarget;
use serde::Serialize;

pub(super) struct RetainedCompanionReadyData {
    header: CompanionHeaderV2,
    files: Vec<ProviderCompanionFileRecord>,
    deletions: Vec<ProviderCompanionDeletionRecord>,
    mappings: BTreeMap<FileId, (FileManifestId, u64)>,
    lengths: BTreeMap<FileId, u64>,
    observation: ProjectionSnapshot,
    placement: ProjectionSnapshot,
    selection: ProjectionSelection,
}
impl RetainedCompanionReadyData {
    pub(super) fn read(c: &Connection, marker: &format::Marker, prefix: &VerifiedDestinationPrefix<'_>,
        required: &[FileManifest], expected: &ExpectedCheckout, cancel: Option<&Cancellation>,
    ) -> Result<Self> {
        prefix.require_destination_connection(c)?;
        let ready = prefix.ready(); let plan = &ready.plan;
        let id = plan.companion_id.as_ref().ok_or_else(|| invalid("retained local companion absent"))?;
        let (header, files, deletions) = source_sql::read_group(c, id, cancel)?;
        let CompanionHeaderRecord::V2(header) = header else { return Err(invalid("retained local companion requires v2 provenance")); };
        header.require_prefix(prefix.prefix())?;
        header.require_receipt(prefix.receipt())?;
        // This checks actual scalar digests, source effective preimages,
        // original lineage, sticky mappings and C's satisfied absences.
        let ids = import_validation::validate_local_companion(c, marker, id, &header, prefix.receipt(), cancel)?;
        let mut mappings = BTreeMap::new();
        for id in ids {
            let (manifest, bytes): (String, u64) = c.query_row("SELECT manifest_id,bytes FROM projection_content WHERE file_id=?1", [&id], |r| Ok((r.get(0)?,r.get(1)?)))?;
            mappings.insert(FileId::parse(id).map_err(|e| invalid(e.to_string()))?, (FileManifestId::parse(manifest).map_err(|e| invalid(e.to_string()))?, bytes));
        }
        let observation = offline::snapshot_at(c, plan.observation.generation, Some(&plan.observation.snapshot_digest))?.snapshot;
        let placement = offline::snapshot_at(c, plan.placement_generation, Some(&plan.placement_digest))?.snapshot;
        let selection = selection::at(c, plan.observation.generation)?;
        if !selection.is_expansion_of(prefix.source()?.selection()) {
            return Err(invalid("retained local companion selection shrank"));
        }
        let mut lengths = BTreeMap::new();
        let exact: BTreeMap<_,_> = required.iter().map(|m| ((m.file_id(),m.id()),m.byte_length())).collect();
        for m in required {
            if lengths.insert(m.file_id().clone(),m.byte_length()).is_some_and(|old| old != m.byte_length()) {
                return Err(invalid("retained local companion FileId lengths differ"));
            }
        }
        for r in &header.preserved_representations {
            if exact.get(&(&r.file_id,&r.manifest_id)) != Some(&r.bytes) { return Err(invalid("retained local companion representation outside C union")); }
        }
        for (file,(manifest,bytes)) in &mappings {
            if exact.get(&(file,manifest)) != Some(bytes) { return Err(invalid("retained companion sticky mapping outside C union")); }
        }
        let result = Self {header,files,deletions,mappings,lengths,observation,placement,selection};
        result.require_image(prefix.source()?, prefix.prefix(), expected, cancel)?;
        Ok(result)
    }
    pub(super) fn header(&self) -> &CompanionHeaderV2 { &self.header }
    pub(super) fn selection(&self) -> &ProjectionSelection { &self.selection }
    pub(super) fn observation(&self) -> &ProjectionSnapshot { &self.observation }
    pub(super) fn placement(&self) -> &ProjectionSnapshot { &self.placement }
    pub(super) fn mapping(&self, file: &FileId) -> Option<&(FileManifestId,u64)> { self.mappings.get(file) }
    pub(super) fn length(&self, file: &FileId) -> Result<u64> { self.lengths.get(file).copied().ok_or_else(|| invalid("retained unchanged FileId absent in C union")) }
    pub(super) fn metadata_bytes(&self) -> Result<u64> {
        let base = sql_bytes(&self.header.encode()?, &self.files, &self.deletions)?;
        self.mappings.iter().try_fold(base, |sum,(file,(manifest,_))| crate::projection::provider::managed_budget::add_metadata(sum,file.as_str().len() as u64+manifest.as_str().len() as u64+8))
    }
    pub(super) fn require_rows(&self, c: &Connection, cancel: Option<&Cancellation>) -> Result<()> {
        let (header, files, deletions) = source_sql::read_group(c, &self.header.digest()?, cancel)?;
        if header.as_ref().encode()? != self.header.encode()? || files != self.files || deletions != self.deletions {
            return Err(invalid("retained C companion exact rows changed"));
        }
        for (file,(manifest,bytes)) in &self.mappings {
            if !c.query_row("SELECT EXISTS(SELECT 1 FROM projection_content WHERE file_id=?1 AND manifest_id=?2 AND bytes=?3)",params![file.as_str(),manifest.as_str(),bytes],|r|r.get::<_,bool>(0))? {
                return Err(invalid("retained C companion mapping changed"));
            }
        }
        Ok(())
    }
    pub(super) fn require_data(&self, data: &ManagedReadyData<'_>, prefix: &ProviderImportPrefixRecord, cancel: Option<&Cancellation>) -> Result<()> {
        cancellation::check(cancel)?;
        self.header.require_prefix(prefix)?; self.header.require_receipt(data.receipt)?;
        if data.observation != &self.observation || data.placement != &self.placement {
            return Err(invalid("retained companion actual observation/placement differs"));
        }
        let mut placement = self.observation.clone();
        for entry in &mut placement.entries {
            if self.selection.includes(&entry.path) && entry.state != EntryState::Reserved && matches!(entry.target,Some(TreeEntryTarget::File{..})) { entry.state=EntryState::Materialized; }
        }
        if placement != self.placement { return Err(invalid("retained companion placement is not exact materialization")); }
        let plan=&data.ready.plan;
        if plan.companion_id.as_deref()!=Some(self.header.digest()?.as_str()) || plan.companion_files.count!=self.header.file_count
            || plan.companion_files.digest!=self.header.files_digest || plan.companion_deletions.count!=self.header.deletion_count || plan.companion_deletions.digest!=self.header.deletions_digest {
            return Err(invalid("retained companion exact rowset commitment differs"));
        }
        Ok(())
    }
    /// Reconstruct only observable inventory DATA and match the original full
    /// image commitment. New remote-only paths are excluded; ambiguous forms
    /// fail the digest instead of being promoted into a native image witness.
    fn require_image(&self, source: &ProviderBootstrapSource, prefix: &ProviderImportPrefixRecord, expected: &ExpectedCheckout, cancel: Option<&Cancellation>) -> Result<()> {
        #[derive(Serialize)]
        #[serde(rename_all="camelCase")]
        enum Item<'a> { File {file_id:&'a FileId,length:u64,executable:Option<bool>}, Deleted {base:&'a FileId} }
        let mut current = BTreeMap::new();
        for file in expected.files() {
            cancellation::check(cancel)?;
            if source.initial().entries.iter().any(|e| e.path==file.path && source.selection().includes(&e.path)) {
                current.insert(&file.path,Item::File{file_id:&file.file_id,length:file.bytes,executable:Some(file.executable)});
            }
        }
        for row in &self.files {
            current.insert(&row.path,Item::File{file_id:&row.file_id,length:row.bytes,executable:Some(row.executable)});
        }
        let mut deleted: BTreeSet<_> = expected.deletions().iter().collect();
        deleted.extend(self.deletions.iter().map(|r|&r.path));
        deleted.extend(self.header.intents.iter().map(|r|r.path()));
        for path in deleted {
            current.remove(path);
            if let Some(base) = source.initial().entries.iter().find(|e| &e.path==path).and_then(|e| match &e.target {Some(TreeEntryTarget::File{file_id})=>Some(file_id),_=>None}) {
                current.insert(path,Item::Deleted{base});
            }
        }
        let payload=canonical_json(&current).map_err(|e|invalid(e.to_string()))?;
        if payload.len()>32*1024*1024 {return Err(invalid("retained complete image metadata exceeds bound"));}
        let digest=super::super::records::codec::hash("layrs-provider-recovery-image-v1",&payload);
        if digest.strip_prefix("blake3:")!=Some(prefix.source.version().effective_image_digest.as_str()) {
            return Err(invalid("retained companion cannot prove exact original complete image inventory"));
        }
        Ok(())
    }
}
''')
# Correct formatting-dependent view branches.
s=get(P+'destination_ready.rs');a=s.index('            let bytes = match inputs.companion');b=s.index('            Some((file_id, executable, bytes, None))',a)
s=s[:a]+'''            let bytes = match (inputs.companion, inputs.retained_companion) {
                (None, None) => inputs.source.unchanged_bytes(&entry.path,file_id,executable,&required)?,
                (Some(c), None) => c.observation.descriptors().iter().find(|d| d.path==entry.path && &d.file_id==file_id && d.executable==executable).ok_or_else(|| invalid("companion Ready unchanged descriptor absent"))?.bytes,
                (None, Some(c)) => c.length(file_id)?,
                _ => return Err(invalid("Ready companion modes overlap")),
            };
''' +s[b:];put(P+'destination_ready.rs',s)
s=get(P+'destination_ready/read.rs')
s=s.replace('''inputs
                    .companion
                    .map_or(0, |c| c.rows.header().map_or(0, |h| h.file_count))''','''inputs.companion_header().map_or(0, |h| h.file_count)''')
s=s.replace('''inputs
                    .companion
                    .map_or(0, |c| c.rows.header().map_or(0, |h| h.deletion_count))''','''inputs.companion_header().map_or(0, |h| h.deletion_count)''')
put(P+'destination_ready/read.rs',s)
# Actual autonomous opener routes local companions through retained DATA.
s=get(P+'destination_ready/autonomous.rs')
s=s.replace('''        || plan.companion_id.is_some()
        || plan.companion_files.count != 0
        || plan.companion_deletions.count != 0''','''        || (origin != DestinationOriginKind::Provider && (plan.companion_id.is_some() || plan.companion_files.count != 0 || plan.companion_deletions.count != 0))''')
needle='    let copied = prefix.copied_content_mappings(c, cancel)?;'
s=s.replace(needle,needle+'''
    let retained = if plan.companion_id.is_some() {
        Some(super::retained_companion::RetainedCompanionReadyData::read(c,actual_marker,&prefix,&family.required,&expected,cancel)?)
    } else { None };
''')
s=s.replace('''            inventory::require_union(
                prefix.source()?,
                &copied,
                &expected,
                &family.required,
                cancel,
            )?;''','''            if retained.is_none() {
                inventory::require_union(prefix.source()?, &copied, &expected, &family.required, cancel)?;
            }''')
s=s.replace('    inventory::require_image(&capture, &expected, &version.effective_image_digest, cancel)?;','    if retained.is_none() { inventory::require_image(&capture, &expected, &version.effective_image_digest, cancel)?; }')
s=s.replace('''        DestinationOriginKind::Provider => (
            prefix.source()?.initial().clone(),
            super::super::records::activation::activation_snapshot(prefix.source()?)?,
        ),''','''        DestinationOriginKind::Provider => match &retained {
            Some(rows) => (rows.observation().clone(),rows.placement().clone()),
            None => (prefix.source()?.initial().clone(),super::super::records::activation::activation_snapshot(prefix.source()?)?),
        },''')
s=s.replace('''        companion: None,
            retained_companion: None,''','''        companion: None,
        retained_companion: retained.as_ref(),''')
s=s.replace('''        view.source.selection(),''','''        view.selection(),''')
s=s.replace('''    let floor = managed_budget::complete_metadata_floor(
        base,''','''    let retained_floor = match &retained { Some(rows) => managed_budget::add_metadata(base,rows.metadata_bytes()?)?, None=>base };
    let floor = managed_budget::complete_metadata_floor(
        retained_floor,''')
put(P+'destination_ready/autonomous.rs',s)
print('authentic retained C-local row reader and autonomous opener path written')
