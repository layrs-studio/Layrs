from editlib import *
s=get(M+'companion.rs').replace("        pub(super) publication:","        publication:");put(M+'companion.rs',s)
