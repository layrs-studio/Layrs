from editlib import *
# Equality is structural over the canonical inherited variant as well.
edit(P+'records/companion_v2.rs','pub(in crate::projection) enum CompanionHeaderRecord','#[derive(PartialEq, Eq)]\npub(in crate::projection) enum CompanionHeaderRecord')
edit(A+'managed_image/complete.rs',"impl VerifiedCompleteManagedImage<'_, '_> {","impl<'a, 'c> VerifiedCompleteManagedImage<'a, 'c> {")
edit(A+'managed_image/complete.rs',"fn retained(&self) -> &VerifiedManagedImage<'_, '_>","fn retained(&self) -> &VerifiedManagedImage<'a, 'c>")
# Factor shared Ready checks; old constructor still explicitly refuses companions.
s=get(M+'ready_data.rs');a=s.index('        cancel.check()?;',s.index('pub(super) fn new('))
s=s[:a]+'''        if source_staging.plan.companion_id.is_some() || source_staging.plan.companion_files.count != 0 || source_staging.plan.companion_deletions.count != 0 {
            return Err(invalid("legacy Ready constructor refuses companions"));
        }
        Self::build(derived, source_staging, image.digest(), image.files(), image.deletions(), required, protection, None, cancel)
    }

    pub(super) fn new_companion(
        derived: ManagedPlanData, source_staging: &ProviderTransitionIntentRecord,
        image_digest: &str, required: &[FileManifest], protection: &ExactProtection,
        rows: &crate::projection::provider::transition_reconcile::companions::OwnedCompanionData,
        cancel: &Cancellation,
    ) -> Result<Self> {
        let header = rows.header().ok_or_else(|| invalid("companion Ready requires closed new header"))?;
        header.require_prefix(&source_staging.plan.source_prefix)?;
        if source_staging.plan.companion_id.as_deref() != Some(header.digest()?.as_str())
            || source_staging.plan.companion_files.count != header.file_count
            || source_staging.plan.companion_files.digest != header.files_digest
            || source_staging.plan.companion_deletions.count != header.deletion_count
            || source_staging.plan.companion_deletions.digest != header.deletions_digest
            || derived.capture.changes != rows.overlay() || required != rows.manifests()
        { return Err(invalid("companion Ready closed rows/union differ")); }
        Self::build(derived, source_staging, image_digest, &[], &[], required, protection, Some(rows), cancel)
    }

    fn build(
        derived: ManagedPlanData, source_staging: &ProviderTransitionIntentRecord,
        image_digest: &str, files: &[ManagedFile<'_>], deletions: &[ManagedDeletion],
        required: &[FileManifest], protection: &ExactProtection,
        companions: Option<&crate::projection::provider::transition_reconcile::companions::OwnedCompanionData>,
        cancel: &Cancellation,
    ) -> Result<Self> {
''' +s[a:]
s=s.replace('            || derived.plan.companion_id.is_some()\n            || derived.plan.companion_files.count != 0\n            || derived.plan.companion_deletions.count != 0','            || derived.plan.companion_id.is_some() != companions.is_some()')
s=s.replace('if image.digest() != version.effective_image_digest','if image_digest != version.effective_image_digest')
a=s.index('        let overlay = build_overlay(');b=s.index('        require_overlay',a)
s=s[:a]+'''        let overlay = match companions {
            None => build_overlay(&derived.capture, files, deletions, required, cancel)?,
            Some(rows) => {
                let mut overlay = Vec::with_capacity(derived.capture.changes.len());
                for change in &derived.capture.changes {
                    cancel.check()?;
                    let file = rows.authorized_files().iter().find(|f| f.path == change.path);
                    let manifest_id = match (&change.replacement, file) {
                        (Some(r), Some(f)) if r.file_id == f.file_id && r.bytes == f.bytes && r.executable == f.executable => Some(f.manifest_id.clone()),
                        (None, None) => None,
                        _ => return Err(invalid("companion Ready overlay escaped authorized checkout")),
                    };
                    overlay.push(ManagedReadyOverlay { path: change.path.clone(), manifest_id });
                }
                overlay
            }
        };
''' +s[b:]
put(M+'ready_data.rs',s)
print('genuine companion Ready DATA constructor written')
