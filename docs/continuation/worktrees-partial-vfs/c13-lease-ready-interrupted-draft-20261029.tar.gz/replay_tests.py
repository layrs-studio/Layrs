from editlib import *
s=get(M+'companion.rs');i=s.index("impl<'h, 'd, 'a, 'c> ManagedImportLease")
s=s[:i]+'''#[cfg(test)]
struct RefuseReplayWriter;
#[cfg(test)]
impl WriterCloseObserver for RefuseReplayWriter {
    fn open_point(&mut self, _: crate::projection::provider::database_io::WriterOpenPoint, _: *mut rusqlite::ffi::sqlite3) -> CauseResult<()> { Err(invalid("exact companion Ready phase replay attempted a writer")) }
    fn before_close(&mut self,_:*mut rusqlite::ffi::sqlite3)->Option<Cause>{None}
    fn after_close(&mut self,_:bool)->Option<Cause>{None}
}
''' +s[i:]
i=s.index('    /// Actual production Store driver:')
s=s[:i]+'''    /// A focused real SQL negative check, executed by the registered native
    /// recipe before B's physical root is inserted. No synthetic Ready SQL.
    #[cfg(test)]
    fn assert_unprotected_source_refuses_receipt(&self, protected: &super::protection::ManagedImportProtection, cancel:&Cancellation) -> CauseResult<()> {
        let _locks=self.held.family.locks(&self.held.artifacts.allocation.format.identity.worktree_id,true)?;
        self.with_source(cancel,|source_c,proof,closure| {
            let owned=self.ready_data(self.rederive(source_c,closure,proof,cancel)?,protected.root(),cancel)?;
            let data=owned.as_data(self.manifests)?;
            let inputs=crate::projection::provider::destination_ready::ManagedReadyInputs {
                marker:&self.destination.proof().format,source:&proof.active.source,
                allocation:&self.held.artifacts.allocation,prepared:self.held.artifacts.prepared.as_ref().ok_or_else(||invalid("test prepared source absent"))?,
                activation:&proof.active.activation,prefix:&self.staging.plan.source_prefix,staging:owned.destination_staging(),closure,
                family_marker_bytes:self.held.family.marker_bytes(),data:&data,companion:self.ready_companion(proof),
            };
            managed_destination::valid(database_io::read_cancellable_strict(self.destination.destination_database(),cancel,|destination_c| {
                managed_destination::valid(database_io::read_cancellable_strict(&self.held.family.catalog,cancel,|family_c| {
                    let before=destination_c.total_changes();
                    let error=crate::projection::provider::destination_ready::validate_ready_data(source_c,destination_c,family_c,&inputs,Some(cancel)).err().ok_or_else(||invalid("C Ready accepted missing actual B protected root"))?;
                    assert!(error.to_string().contains("actual B protected root"),"{error}");
                    assert_eq!(destination_c.total_changes(),before);
                    assert!(!destination_c.query_row("SELECT EXISTS(SELECT 1 FROM projection_provider_transition_receipts WHERE transaction_id=?1)",[self.staging.transaction_id.as_str()],|r|r.get::<_,bool>(0))?);
                    Ok(())
                })?)
            })?)
        })
    }

''' +s[i:]
s=s.replace('''        pins.exact = Some(self.protect_exact(close, cancel)?);
        pins.source''','''        pins.exact = Some(self.protect_exact(close, cancel)?);
        #[cfg(test)]
        self.assert_unprotected_source_refuses_receipt(pins.exact.as_ref().ok_or_else(|| invalid("C protection absent in test"))?,cancel)?;
        pins.source''')
s=s.replace('''        let family = self.publish_family_ready(&private, close, cancel)?;
        self.publish_source_companion''','''        #[cfg(test)] {
            let replay=self.finalize_private_ready(protected,checkout,&mut RefuseReplayWriter,cancel)?;
            if replay.receipt()!=private.receipt() {return Err(invalid("companion private Ready replay changed receipt"));}
        }
        let family = self.publish_family_ready(&private, close, cancel)?;
        #[cfg(test)] {
            let replay=self.publish_family_ready(&private,&mut RefuseReplayWriter,cancel)?;
            if replay.receipt()!=family.receipt() {return Err(invalid("companion family Ready replay changed receipt"));}
        }
        self.publish_source_companion''')
put(M+'companion.rs',s)
print('real missing-B-root SQL negative and no-writer private/family phase replay coverage authored')
