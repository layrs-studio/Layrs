from editlib import *
import json
results=[]
for q in sorted((O/'files').rglob('*.rs')):
 r=subprocess.run(['rustfmt','--edition','2024','--config','style_edition=2021,skip_children=true',str(q)],capture_output=True,text=True)
 if r.returncode: print(q.relative_to(O),r.stderr)
 results.append({'path':q.relative_to(O).as_posix(),'exit':r.returncode,'stderr':r.stderr})
(O/'rustfmt-results.json').write_text(json.dumps(results,indent=2))
print('rustfmt files',len(results),'failures',sum(r['exit']!=0 for r in results))
