from editlib import *
# B context is borrowed DATA; never an authority grant.
edit('crates/layrs-store-local/src/projection/shared/source_companion.rs','pub(in crate::projection) struct SourceCompanionFamilyContext', '#[derive(Clone, Copy)]\npub(in crate::projection) struct SourceCompanionFamilyContext')
edit('crates/layrs-store-local/src/projection/shared/source_companion.rs','pub(super) fn classify_source_groups','pub(in crate::projection) fn classify_source_groups')
s=get(P+'destination_ready.rs')
i=s.index('pub(in crate::projection::provider) struct ManagedReadyInputs')
s=s[:i]+'''/// Closed reconciliation DATA plus the real pending B root. The caller still
/// owns physical C checkout/CAS and the complete source checkpoint.
#[derive(Clone, Copy)]
pub(in crate::projection::provider) struct ManagedCompanionReadyData<'a> {
    pub rows: &'a super::transition_reconcile::companions::OwnedCompanionData,
    pub observation: &'a super::transition_observation::TransitionObservationData,
    pub source_context: crate::projection::shared::source_companion::SourceCompanionFamilyContext<'a>,
}
''' +s[i:]
s=s.replace("    pub family_marker_bytes: &'a [u8],","    pub family_marker_bytes: &'a [u8],\n    pub companion: Option<ManagedCompanionReadyData<'a>>,")
s=s.replace("    data: &'a ManagedReadyData<'a>,\n}","    data: &'a ManagedReadyData<'a>,\n    companion: Option<&'a ManagedCompanionReadyData<'a>>,\n}")
s=s.replace('            data: self.data,','            data: self.data,\n            companion: self.companion.as_ref(),')
# actual local snapshot/selection can differ from original Provider bootstrap.
s=s.replace('    let plan = &staging.plan;\n    let version = inputs.source.version(inputs.prefix)?;', '    let plan = &staging.plan;\n    let version = inputs.source.version(inputs.prefix)?;')
s=s.replace('selection::insert(destination, generation, inputs.source.selection())?;','selection::insert(destination, generation, inputs.selection())?;')
s=s.replace('    let receipt = inputs.data.receipt;\n    destination.execute(','''    if let Some(companion) = inputs.companion {
        // Identical closed rows precede THIS database's own receipt, in this
        // same Ready transaction. B's private rows are still absent.
        companion.rows.insert_source_mappings_and_rows(destination, cancel)?;
    }
    let receipt = inputs.data.receipt;
    destination.execute(''')
s=s.replace('        if !inputs.source.selection().includes(&entry.path) {','        if !inputs.selection().includes(&entry.path) || (inputs.companion.is_some() && entry.state == EntryState::Reserved) {')
s=s.replace('''            let bytes =
                inputs
                    .source
                    .unchanged_bytes(&entry.path, file_id, executable, &required)?;''','''            let bytes = match inputs.companion {
                None => inputs.source.unchanged_bytes(&entry.path, file_id, executable, &required)?,
                Some(c) => c.observation.descriptors().iter().find(|d| d.path == entry.path && &d.file_id == file_id && d.executable == executable)
                    .ok_or_else(|| invalid("companion Ready unchanged descriptor absent"))?.bytes,
            };''')
i=s.index('/// Each entry wrapper authenticates')
s=s[:i]+'''impl ReadyView<'_> {
    fn selection(&self) -> &layrs_core::projection::ProjectionSelection {
        match self.companion { Some(c) => c.observation.selection(), None => self.source.selection() }
    }
    fn require_companion(&self, cancel: Option<&Cancellation>) -> Result<()> {
        let Some(c) = self.companion else {
            if self.data.ready.plan.companion_id.is_some() || self.data.ready.plan.companion_files.count != 0 || self.data.ready.plan.companion_deletions.count != 0 {
                return Err(invalid("strict Ready DATA refuses new companions"));
            }
            return self.source.require_snapshots(self.data);
        };
        cancellation::check(cancel)?;
        if c.observation.binding().denied_path_count != 0 || c.rows.manifests() != self.data.required
            || c.rows.overlay() != self.data.capture.changes || c.observation.snapshot() != self.data.observation {
            return Err(invalid("companion Ready observation, overlay or full union differs"));
        }
        c.rows.require_plan_observation(self.prefix, c.observation)?;
        let header = c.rows.header().ok_or_else(|| invalid("companion Ready header absent"))?;
        header.require_prefix(self.prefix)?;
        header.require_receipt(self.data.receipt)?;
        let plan = &self.data.ready.plan;
        if plan.companion_id.as_deref() != Some(header.digest()?.as_str())
            || plan.companion_files.count != header.file_count || plan.companion_files.digest != header.files_digest
            || plan.companion_deletions.count != header.deletion_count || plan.companion_deletions.digest != header.deletions_digest {
            return Err(invalid("companion Ready plan rowset commitments differ"));
        }
        let mut placement = c.observation.snapshot().clone();
        for entry in &mut placement.entries {
            if c.observation.selection().includes(&entry.path) && entry.state != layrs_core::projection::EntryState::Reserved
                && matches!(entry.target, Some(layrs_core::scm::TreeEntryTarget::File { .. })) {
                entry.state = layrs_core::projection::EntryState::Materialized;
            }
        }
        if &placement != self.data.placement { return Err(invalid("companion Ready exact placement differs")); }
        Ok(())
    }
}

''' +s[i:]
put(P+'destination_ready.rs',s)
# Non-companion consumers stay strict and unchanged semantically.
for rel in ['destination_ready/ordinary.rs','destination_ready/autonomous.rs']:
 s=get(P+rel).replace('            data: self.data,','            data: self.data,\n            companion: None,').replace('        data: &data,','        data: &data,\n        companion: None,');put(P+rel,s)
s=get(P+'destination_ready/tests/fixture.rs').replace('            data,\n','            data,\n            companion: None,\n');put(P+'destination_ready/tests/fixture.rs',s)
# Ready independent input and family validators.
s=get(P+'destination_ready/data.rs')
s=s.replace('''        || staging.plan.companion_id.is_some()
        || staging.plan.companion_files.count != 0
        || staging.plan.companion_deletions.count != 0''','''        || staging.plan.companion_id.is_some() != inputs.companion.is_some()''')
s=s.replace('''        || ready.plan.companion_id.is_some()
        || ready.plan.companion_files.count != 0
        || ready.plan.companion_deletions.count != 0''','''        || ready.plan.companion_id.is_some() != inputs.companion.is_some()''')
s=s.replace('    inputs.source.require_snapshots(inputs.data)?;','    inputs.require_companion(cancel)?;')
s=s.replace('''    inputs
        .source
        .selection()''','''    inputs
        .selection()''')
s=s.replace('    let copied = inputs','''    if let Some(companion) = &inputs.companion {
        inputs.closure.require_publication_inputs(companion.source_context.publication)?;
        let full = companion.source_context.publication;
        if !std::ptr::eq(inputs.source, &full.active.source) || !std::ptr::eq(inputs.activation, &full.active.activation) {
            return Err(invalid("companion Ready complete source proof differs"));
        }
        let root = companion.source_context.pending.ok_or_else(|| invalid("companion Ready exact pending B root absent"))?;
        let source_staging = full.source_transitions().iter().find(|i| i.transaction_id == staging.transaction_id)
            .ok_or_else(|| invalid("companion Ready original source transition absent"))?;
        if source_staging.plan != staging.plan { return Err(invalid("companion Ready original source plan differs")); }
        root.require_plan(inputs.allocation, source_staging, cancel)?;
        crate::projection::shared::source_companion::classify_source_groups(family_c, inputs.allocation, Some(&companion.source_context), cancel)?;
        if root.inspect(family_c, cancel)? != crate::projection::shared::source_companion::SourceCompanionPresence::Protected {
            return Err(invalid("companion Ready requires actual B protected root"));
        }
    }
    let copied = inputs''',1)
# Sticky mapping choices win, and preimages cannot become arbitrary alternates.
s=s.replace('''            new_content.push((
                manifest.file_id().to_string(),
                manifest.id().to_string(),
                manifest.byte_length(),
            ));''','''            let (id, bytes) = inputs.companion.and_then(|c| c.rows.source_mappings().get(manifest.file_id()))
                .map_or((manifest.id(), manifest.byte_length()), |(id, bytes)| (id, *bytes));
            if !required.get(&(manifest.file_id(), id)).is_some_and(|m| m.byte_length() == bytes) {
                return Err(invalid("companion Ready sticky mapping outside full union"));
            }
            new_content.push((manifest.file_id().to_string(), id.to_string(), bytes));''')
put(P+'destination_ready/data.rs',s)
# Counts are exact incoming prefix + exactly one local header and its scalars.
s=get(P+'destination_ready/read.rs')
s=s.replace('("projection_provider_companions", closure.companions.count),','("projection_provider_companions", add(closure.companions.count, u64::from(inputs.companion.is_some()))?),')
s=s.replace('            closure.companion_files.count,','            add(closure.companion_files.count, inputs.companion.map_or(0, |c| c.rows.header().map_or(0, |h| h.file_count)))?,')
s=s.replace('            closure.companion_deletions.count,','            add(closure.companion_deletions.count, inputs.companion.map_or(0, |c| c.rows.header().map_or(0, |h| h.deletion_count)))?,')
s=s.replace('selection::encode(inputs.source.selection())?','selection::encode(inputs.selection())?')
s=s.replace('    let receipt = inputs.data.receipt;', '''    if let Some(companion) = inputs.companion {
        companion.rows.require_new_rows(c, cancel)?;
        companion.rows.require_inherited_rows(c, cancel)?;
    }
    let receipt = inputs.data.receipt;''')
put(P+'destination_ready/read.rs',s)
# Checkout must contain only authorized live files; recovery stays solely in U.
s=get(A+'managed_content.rs');i=s.index('        let files: Vec<_> = self',s.index('fn expected_checkout'))
s=s[:i]+'''        if let Some(data) = &self.companion {
            let files = data.publication.rows().authorized_files().iter().map(|f| CheckoutFile {
                path: f.path.clone(), manifest_id: f.manifest_id.clone(), file_id: f.file_id.clone(), bytes: f.bytes, executable: f.executable,
            }).collect::<Vec<_>>();
            let deleted = data.publication.rows().overlay().iter().filter(|c| c.replacement.is_none()).map(|c| c.path.clone()).collect::<Vec<_>>();
            return ExpectedCheckout::new(self.staging, &files, &deleted, self.image.digest(), Some(cancel));
        }
''' +s[i:];put(A+'managed_content.rs',s)
print('destination C companion Ready transaction and strict readers written')
