from editlib import *
import hashlib,difflib,json
R=Path('D:/Layrs/tmp/c13-source-protection-review-fixes');B=Path('D:/Layrs/tmp/c13-source-protection-source-proposal/files')
assert hashlib.sha256((R/'manifest.sha256.json').read_bytes()).hexdigest()=='b1d05862814f29e011b6c64e126bd4cb2096efd9da1af80cb139ad5ce26a8fcd'
assert hashlib.sha256((R/'review-fixes.patch').read_bytes()).hexdigest()=='943972e50f11ab092d29b16fbc8bc9d9f781e1d42d174b2f76464365d03d9413'
merged=[]
for e in json.loads((R/'manifest.sha256.json').read_text())['files']:
 p=e['path'];base=(B/p).read_text();theirs=(R/e['output']).read_text();ours=get(p)
 if ours==base: put(p,theirs);merged.append(p);continue
 for tag,i,j,k,l in reversed(list(difflib.SequenceMatcher(None,base.splitlines(True),theirs.splitlines(True)).get_opcodes())):
  if tag=='equal':continue
  before=''.join(base.splitlines(True)[i:j]);after=''.join(theirs.splitlines(True)[k:l])
  if before:
   assert before in ours,(p,repr(before[:150]));ours=ours.replace(before,after,1)
  else:
   anchor=''.join(base.splitlines(True)[max(0,i-2):i]);assert anchor in ours,(p,anchor);ours=ours.replace(anchor,anchor+after,1)
 put(p,ours);merged.append(p)
(O/'root-corrections-merge.json').write_text(json.dumps({'manifest_sha256':'b1d05862814f29e011b6c64e126bd4cb2096efd9da1af80cb139ad5ce26a8fcd','files':merged},indent=2))
print('merged ROOT seven-file critical-review corrections preserving lease/Ready edits')
# Fix nested negative helper using the real source/publication inputs scope.
s=get(M+'source_publication.rs')
s=s.replace('''        self.with_source_publication_context(family,Some(source),cancel, |source_c,destination_c,family_c,inputs,_,_,_,_| {''','''        let _locks=self.held.family.locks(&self.held.artifacts.allocation.format.identity.worktree_id,true)?;
        managed_destination::valid(database_io::read_cancellable_strict(&self.held.artifacts.database,cancel,|source_c| {
          self.with_source_publication_inputs(source_c,family,Some(source),cancel,|inputs,publication,binding,floor,_| {
            managed_destination::valid(database_io::read_cancellable_strict(self.destination.destination_database(),cancel,|destination_c| {
              managed_destination::valid(database_io::read_cancellable_strict(&self.held.family.catalog,cancel,|family_c| {
                self.require_source_publication_family(source_c,destination_c,family_c,inputs,publication,binding,floor,family.private_ready(),cancel)?;''')
a=s.index('fn assert_companion_ready_refusals');b=s.index('    fn check_source_publication',a)
chunk=s[a:b];old='''            Ok(())
        })
    }

''';assert old in chunk
chunk=chunk.replace(old,'''                Ok(())
              })?)
            })?)
          })
        })?)
    }

''');s=s[:a]+chunk+s[b:];put(M+'source_publication.rs',s)
print('negative C DATA checks now use actual nested source/C/family snapshots')
