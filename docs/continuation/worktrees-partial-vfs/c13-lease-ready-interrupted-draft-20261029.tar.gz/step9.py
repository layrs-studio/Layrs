from editlib import *
# Own nested callbacks stop before any post-failure FS probe. ROOT owns the
# separate source_companion_snapshot correction and will supply that overlay.
for q in [A+'managed_content.rs']+[M+r for r in ['companion.rs','exact.rs','checkout.rs','protection.rs','ready.rs','publication.rs','source_publication.rs']]:
 s=get(q).replace('database_io::read_cancellable(', 'database_io::read_cancellable_strict(');put(q,s)
# Opening C Ready validates closed DATA/B root before writer admission too.
s=get(P+'destination_ready.rs');i=s.index('/// Strict Ready suffix reader.')
s=s[:i]+'''pub(in crate::projection::provider) fn validate_ready_data(source_c: &Connection, destination: &Connection, family_c: &Connection, inputs: &ManagedReadyInputs<'_>, cancel: Option<&Cancellation>) -> Result<()> {
    data::prepare(source_c,destination,family_c,inputs,cancel).map(|_| ())
}

''' +s[i:];put(P+'destination_ready.rs',s)
s=get(M+'ready.rs');needle='    let expected = checkout.expected();'
s=s.replace(needle,needle+'\n    destination_ready::validate_ready_data(source_c,destination,family_c,inputs,Some(cancel))?;');put(M+'ready.rs',s)
s=get(P+'destination_ready/data.rs').replace('        root.require_plan(inputs.allocation, source_staging, cancel)?;','        root.require_plan(inputs.allocation, source_staging, cancel)?;\n        root.require_union(inputs.data.required, cancel)?;');put(P+'destination_ready/data.rs',s)
# Autonomous exact union includes the actual new local header's committed
# representations, in addition to all independently proved inherited ones.
s=get(P+'destination_ready/autonomous.rs').replace('    let inherited = prefix.inherited_companion_representations(c, cancel)?;','''    let mut inherited = prefix.inherited_companion_representations(c, cancel)?;
    if let Some(local) = &retained {
        inherited.extend(local.header().preserved_representations.iter().map(|r| RequiredRepresentation {
            file_id:r.file_id.clone(),manifest_id:r.manifest_id.clone(),bytes:r.bytes,
        }));
    }''')
put(P+'destination_ready/autonomous.rs',s)
# Internal non-test commit entry calls the composed driver, allowing a later
# trusted host to use one Store boundary without a SQL/network callback.
s=get(A+'managed_content.rs');s+='''
/// Actual Store commit boundary for a retained complete source and closed
/// observation. Client-core acquisition/revalidation must finish before this
/// is entered. This API is internal, not an HTTP/CLI authorization adapter.
#[allow(clippy::too_many_arguments)]
pub(super) fn commit_companion(
    held: &outcome::PublicationPins, root: &layrs_vfs::ProviderRootGuard,
    mount: &ProviderActiveMountRecord, activation: &ProviderActivationRecord,
    attempt: &CaptureAttemptLock, destination: &managed_allocation::ManagedDestinationAllocation<'_>,
    image: &mut managed_image::complete::VerifiedCompleteManagedImage<'_, '_>,
    staging: &ProviderTransitionIntentRecord,
    publication: &crate::projection::provider::source_companion::SourceCompanionPublication<'_>,
    observation: &crate::projection::provider::transition_observation::TransitionObservationData,
    metadata: u64, close: &mut impl WriterCloseObserver, cancel: &Cancellation,
) -> CauseResult<crate::projection::provider::records::import::ProviderTransitionReceiptRecord> {
    let mut lease = ManagedImportLease::open_companion(held,root,mount,activation,attempt,destination,image,staging,publication,observation,metadata,cancel)?;
    lease.with_published_companion(close,cancel, |_lease,family,_source| {
        crate::projection::provider::records::import::ProviderTransitionReceiptRecord::decode(&family.receipt().encode()?)
    })
}
''';put(A+'managed_content.rs',s)
# Authored real SQL/DATA negative checks from the production context. No Ready
# state is synthesized and no mutable SQL is used for a passing fixture.
s=get(M+'source_publication.rs');i=s.index('    fn check_source_publication(')
s=s[:i]+r'''    #[cfg(test)]
    pub(in crate::projection::provider::bootstrap::preparation::activation) fn assert_companion_ready_refusals(
        &self, family: &ManagedFamilyReady<'_, '_>, source: &super::protection::ManagedSourceCompanionProtection<'_, '_>, cancel: &Cancellation,
    ) -> CauseResult<()> {
        self.with_source_publication_context(family,Some(source),cancel, |source_c,destination_c,family_c,inputs,_,_,_,_| {
            let checkout=family.private_ready().physical_parts().1;
            let mut missing=inputs.companion.ok_or_else(||invalid("native negative requires actual companion route"))?;
            missing.source_context.pending=None;
            let bad=ManagedReadyInputs { marker:inputs.marker,source:inputs.source,allocation:inputs.allocation,prepared:inputs.prepared,
                activation:inputs.activation,prefix:inputs.prefix,staging:inputs.staging,closure:inputs.closure,
                family_marker_bytes:inputs.family_marker_bytes,data:inputs.data,companion:Some(missing) };
            let before=destination_c.total_changes();
            let error=crate::projection::provider::destination_ready::read_checkout_family_ready(source_c,destination_c,family_c,&bad,checkout.expected(),Some(cancel)).err().ok_or_else(||invalid("missing B root context accepted C Ready"))?;
            assert!(error.to_string().contains("pending B root absent"),"{error}");
            let shortened=&inputs.data.required[..inputs.data.required.len()-1];
            let wrong_union=crate::projection::provider::destination_ready::ManagedReadyData {observation:inputs.data.observation,placement:inputs.data.placement,capture:inputs.data.capture,
                overlay:inputs.data.overlay,required:shortened,receipt:inputs.data.receipt,ready:inputs.data.ready,claims:inputs.data.claims};
            let bad=ManagedReadyInputs { data:&wrong_union, companion:inputs.companion, ..bad };
            assert!(crate::projection::provider::destination_ready::read_checkout_family_ready(source_c,destination_c,family_c,&bad,checkout.expected(),Some(cancel)).is_err());
            let mut changed=ProviderTransitionIntentRecord::decode(&inputs.data.ready.encode()?)?;
            changed.plan.companion_files.digest=format!("blake3:{}","f".repeat(64));
            let wrong_rows=crate::projection::provider::destination_ready::ManagedReadyData {ready:&changed,required:inputs.data.required,..wrong_union};
            let bad=ManagedReadyInputs {data:&wrong_rows,..bad};
            assert!(crate::projection::provider::destination_ready::read_checkout_family_ready(source_c,destination_c,family_c,&bad,checkout.expected(),Some(cancel)).is_err());
            assert_eq!(before,destination_c.total_changes());
            Ok(())
        })
    }

''' +s[i:];put(M+'source_publication.rs',s)
print('strict new scopes, independent early B-root checks, commit entry and negative DATA checks wired')
