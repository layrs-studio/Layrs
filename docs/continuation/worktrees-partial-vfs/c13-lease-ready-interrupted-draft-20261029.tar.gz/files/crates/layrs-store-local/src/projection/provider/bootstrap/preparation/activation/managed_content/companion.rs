//! Complete-checkpoint route. All immutable DATA is rederived from the actual
//! source transaction before any C callback. No network callback runs here.
use super::super::managed_image::{
    self, complete::VerifiedCompleteManagedImage, ManagedDeletion, ManagedFile,
};
use super::*;
use crate::projection::{
    provider::{
        destination_ready::ManagedCompanionReadyData,
        records::import::ImportSourceReferences,
        source_companion::SourceCompanionPublication,
        transition_observation::TransitionObservationData,
        transition_reconcile::source_sql,
        validation::{self, PrivateActivePublicationValidation},
    },
    shared::{exact_protection::ExactProtection, source_companion::SourceCompanionFamilyContext},
};
use layrs_core::scm::RepoPath;
use std::io::Write;

pub(super) enum ManagedImage<'h, 'a, 'c> {
    Legacy(&'h mut managed_image::VerifiedManagedImage<'a, 'c>),
    Complete(&'h mut VerifiedCompleteManagedImage<'a, 'c>),
}
impl<'a, 'c> ManagedImage<'_, 'a, 'c> {
    fn retained(&self) -> &managed_image::VerifiedManagedImage<'a, 'c> {
        match self {
            Self::Legacy(i) => i,
            Self::Complete(i) => i.retained(),
        }
    }
    pub(super) fn digest(&self) -> &str {
        self.retained().digest()
    }
    pub(super) fn files(&self) -> &[ManagedFile<'_>] {
        self.retained().files()
    }
    pub(super) fn deletions(&self) -> &[ManagedDeletion] {
        self.retained().deletions()
    }
    pub(super) fn require_owner(
        &self,
        root: &layrs_vfs::ProviderRootGuard,
        source: &ProviderBootstrapSource,
        activated: &ProjectionSnapshot,
    ) -> CauseResult<()> {
        self.retained().require_owner(root, source, activated)
    }
    pub(super) fn require_retained(
        &self,
        root: &layrs_vfs::ProviderRootGuard,
        digest: &str,
        cancel: &Cancellation,
    ) -> CauseResult<()> {
        match self {
            Self::Complete(i) => i.require_retained(root, digest, cancel),
            Self::Legacy(_) => Err(invalid(
                "source companion witness requires retained complete checkpoint",
            )),
        }
    }
    pub(super) fn revalidate_and_match_digest(
        &mut self,
        digest: &str,
        cancel: &Cancellation,
    ) -> CauseResult<()> {
        match self {
            Self::Legacy(i) => i.revalidate_and_match_digest(digest, cancel),
            Self::Complete(i) => {
                i.revalidate(cancel)?;
                if i.digest() != digest {
                    return Err(invalid("complete lease image digest differs"));
                }
                Ok(())
            }
        }
    }
    pub(super) fn copy_exact_chunk(
        &mut self,
        path: &RepoPath,
        manifest: &FileManifest,
        ordinal: usize,
        output: &mut dyn Write,
        cancel: &Cancellation,
    ) -> CauseResult<()> {
        match self {
            Self::Legacy(i) => i.copy_exact_chunk(path, manifest, ordinal, output, cancel),
            Self::Complete(i) => i.copy_exact_chunk(path, manifest, ordinal, output, cancel),
        }
    }
    pub(super) fn copy_exact_file(
        &mut self,
        path: &RepoPath,
        manifest: &FileManifest,
        output: &mut dyn Write,
        cancel: &Cancellation,
    ) -> CauseResult<()> {
        match self {
            Self::Legacy(i) => i.copy_exact_file(path, manifest, output, cancel),
            Self::Complete(i) => i.copy_exact_file(path, manifest, output, cancel),
        }
    }
}

pub(super) struct CompanionLeaseData<'h> {
    pub(super) publication: &'h SourceCompanionPublication<'h>,
    anchor: &'h super::super::session::ProviderTransitionSource<'h>,
    pub(super) observation: &'h TransitionObservationData,
    pub(super) metadata_without_companions: u64,
}
impl CompanionLeaseData<'_> {
    pub(super) fn context<'p>(
        &'p self,
        full: &'p PrivateActivePublicationValidation,
    ) -> SourceCompanionFamilyContext<'p> {
        SourceCompanionFamilyContext {
            publication: full,
            pending: Some(self.publication.protection()),
        }
    }
}
/// Caller-owned progress keeps every acquired byte/checkout pin alive even
/// when a later COMMIT/connection-close acknowledgement is withheld. There is
/// no reference to the lease or mutable image, and no self-referential Ready.
#[derive(Default)]
pub(in crate::projection::provider::bootstrap::preparation::activation) struct CompanionPins<'h> {
    exact: Option<super::protection::ManagedImportProtection>,
    source: Option<super::source_protection::ManagedSourceCompanionProtection<'h, 'h>>,
    checkout: Option<super::checkout::ManagedCheckoutProof>,
}
#[cfg(test)]
struct RefuseReplayWriter;
#[cfg(test)]
impl WriterCloseObserver for RefuseReplayWriter {
    fn open_point(
        &mut self,
        _: crate::projection::provider::database_io::WriterOpenPoint,
        _: *mut rusqlite::ffi::sqlite3,
    ) -> CauseResult<()> {
        Err(invalid(
            "exact companion Ready phase replay attempted a writer",
        ))
    }
    fn before_close(&mut self, _: *mut rusqlite::ffi::sqlite3) -> Option<Cause> {
        None
    }
    fn after_close(&mut self, _: bool) -> Option<Cause> {
        None
    }
}
impl<'h, 'd, 'a, 'c> ManagedImportLease<'h, 'd, 'a, 'c> {
    /// Trusted Store host boundary after point-in-time remote observation and
    /// exact source anchoring. The complete checkpoint stays borrowed by this
    /// lease; DATA cannot reconstruct it, source ownership or remote authority.
    #[allow(clippy::too_many_arguments)]
    pub(in crate::projection::provider::bootstrap::preparation::activation) fn open_companion(
        held: &'h outcome::PublicationPins,
        root: &'h layrs_vfs::ProviderRootGuard,
        mount: &'h ProviderActiveMountRecord,
        activation: &'h ProviderActivationRecord,
        attempt: &'h CaptureAttemptLock,
        destination: &'h managed_allocation::ManagedDestinationAllocation<'d>,
        image: &'h mut VerifiedCompleteManagedImage<'a, 'c>,
        staging: &'h ProviderTransitionIntentRecord,
        publication: &'h SourceCompanionPublication<'h>,
        anchor: &'h super::super::session::ProviderTransitionSource<'h>,
        observation: &'h TransitionObservationData,
        metadata_without_companions: u64,
        cancel: &Cancellation,
    ) -> CauseResult<Self> {
        if observation.binding().denied_path_count != 0 {
            return Err(invalid(
                "C14 durable denied-absence contract required before effects",
            ));
        }
        let mut lease = Self {
            held,
            root,
            mount,
            activation,
            attempt,
            destination,
            image: ManagedImage::Complete(image),
            companion: Some(CompanionLeaseData {
                publication,
                anchor,
                observation,
                metadata_without_companions,
            }),
            staging,
            manifests: publication.rows().manifests(),
            fresh: observation.snapshot(),
        };
        lease.expected_protection(cancel)?;
        let offline_storage = lease.pin_exact_storage()?;
        if let ManagedImage::Complete(image) = &mut lease.image {
            image.pin_offline_current(offline_storage, cancel)?;
        }
        lease.rehash(cancel)?;
        // Opening rederives every row/representation/observation but permits an
        // absent B reservation. reserve_source_companion is the FIRST effect.
        let _locks = held
            .family
            .locks(&held.artifacts.allocation.format.identity.worktree_id, true)?;
        lease.with_source(cancel, |c, full, closure| {
            lease.rederive(c, closure, full, cancel)?;
            publication.require(
                &held.artifacts.allocation,
                staging,
                publication.receipt(),
                Some(cancel),
            )?;
            Ok(())
        })?;
        Ok(lease)
    }

    /// Transition-specific original-prefix validation. This deliberately does
    /// not invoke transition_source()'s no-pending gate once a plan is pending.
    pub(super) fn with_source<T>(
        &self,
        cancel: &Cancellation,
        action: impl FnOnce(
            &Connection,
            &PrivateActivePublicationValidation,
            &VerifiedImportClosure,
        ) -> CauseResult<T>,
    ) -> CauseResult<T> {
        self.boundary(cancel)?;
        managed_destination::valid(database_io::read_cancellable_strict(
            &self.held.artifacts.database,
            cancel,
            |c| {
                let prepared = self
                    .held
                    .artifacts
                    .prepared
                    .as_ref()
                    .ok_or_else(|| invalid("complete lease prepared source absent"))?;
                let full = validation::private_active_publication_with_source(
                    c,
                    &self.held.artifacts.allocation,
                    prepared,
                    &self.held.binding,
                    Some(self.root.registration().root_id()),
                    Some(cancel),
                )?;
                if full.active.mount != *self.mount
                    || full.active.activation != *self.activation
                    || full
                        .transitions
                        .iter()
                        .find(|i| i.transaction_id == self.staging.transaction_id)
                        != Some(self.staging)
                {
                    return Err(invalid("complete lease original source Staging changed"));
                }
                let ImportSource::Provider { version, .. } =
                    &self.staging.plan.source_prefix.source
                else {
                    return Err(invalid("complete lease provider prefix absent"));
                };
                let closure =
                    crate::projection::provider::import_validation::verify_source_publication(
                        c,
                        &self.held.artifacts.allocation.format,
                        &self.staging.plan.source_prefix,
                        ImportSourceReferences::Provider {
                            allocation: &self.held.artifacts.allocation,
                            prepared,
                            activation: &full.active.activation,
                        },
                        &full,
                        &version.effective_image_digest,
                        Some(cancel),
                    )?;
                self.image.require_owner(
                    self.root,
                    &full.active.source,
                    &full.active.activated.snapshot,
                )?;
                let result = action(c, &full, &closure)?;
                self.boundary(cancel)?;
                Ok(result)
            },
        )?)
    }

    pub(super) fn rederive(
        &self,
        c: &Connection,
        closure: &VerifiedImportClosure,
        full: &PrivateActivePublicationValidation,
        cancel: &Cancellation,
    ) -> CauseResult<managed_plan::ManagedPlanData> {
        let Some(data) = &self.companion else {
            return managed_plan::rederive_publication_reservation(
                c,
                closure,
                self.image.retained(),
                full,
                self.fresh,
                self.staging,
                self.manifests,
                cancel,
            );
        };
        data.anchor
            .require_transition(self.held, self.root, full, self.staging, cancel)?;
        let ManagedImage::Complete(image) = &self.image else {
            return Err(invalid("companion lease complete checkpoint absent"));
        };
        let rows = source_sql::with_source(
            c,
            &self.held.artifacts.allocation.format,
            &self.staging.plan.source_prefix,
            closure,
            full,
            data.observation,
            Some(cancel),
            |source| {
                image.reconcile_publication_retained(
                    source,
                    data.observation,
                    full,
                    self.manifests,
                    data.metadata_without_companions,
                    cancel,
                )
            },
        )?;
        if &rows != data.publication.rows() {
            return Err(invalid(
                "complete lease reconcile rows, sticky mappings or full union changed",
            ));
        }
        let p = &self.staging.plan;
        let mut derived = managed_plan::derive_reconciled_data(
            &p.source_prefix,
            &rows,
            data.observation,
            p.source_prefix.destination_identity.clone(),
            &p.destination_parent,
            &p.destination_parent_identity,
            &p.destination_leaf_nonce,
            &self.staging.transaction_id,
        )?;
        if derived.plan != *p || derived.required_manifests.len() != self.manifests.len() {
            return Err(invalid(
                "complete lease immutable plan differs from source rederivation",
            ));
        }
        let destination = managed_destination::destination_intent(self.staging)?;
        let minimum = crate::projection::provider::managed_budget::base_metadata_floor(
            closure.metadata_bytes(c, &p.source_prefix, Some(cancel))?,
            &derived.observation,
            &derived.placement,
            &derived.capture,
            p,
            data.observation.selection(),
            crate::projection::provider::managed_budget::intent_size(self.staging)?,
            crate::projection::provider::managed_budget::intent_size(&destination)?,
        )?;
        if rows.metadata_bytes() < minimum {
            return Err(invalid(
                "companion lease source-rederived metadata floor insufficient",
            ));
        }
        derived.validated_metadata_floor = Some(
            minimum
                .checked_add(rows.source_row_bytes()?)
                .ok_or_else(|| invalid("companion Ready metadata overflow"))?,
        );
        Ok(derived)
    }
    pub(super) fn ready_data(
        &self,
        derived: managed_plan::ManagedPlanData,
        root: &ExactProtection,
        cancel: &Cancellation,
    ) -> CauseResult<super::ready_data::OwnedReadyData> {
        match &self.companion {
            None => super::ready_data::OwnedReadyData::new(
                derived,
                self.staging,
                self.image.retained(),
                self.manifests,
                root,
                cancel,
            ),
            Some(data) => super::ready_data::OwnedReadyData::new_companion(
                derived,
                self.staging,
                self.image.digest(),
                self.manifests,
                root,
                data.publication.rows(),
                cancel,
            ),
        }
    }
    pub(super) fn ready_companion<'p>(
        &'p self,
        full: &'p PrivateActivePublicationValidation,
    ) -> Option<ManagedCompanionReadyData<'p>> {
        self.companion
            .as_ref()
            .map(|data| ManagedCompanionReadyData {
                rows: data.publication.rows(),
                observation: data.observation,
                source_context: data.context(full),
            })
    }

    /// A focused real SQL negative check, executed by the registered native
    /// recipe before B's physical root is inserted. No synthetic Ready SQL.
    #[cfg(test)]
    fn assert_unprotected_source_refuses_receipt(
        &self,
        protected: &super::protection::ManagedImportProtection,
        cancel: &Cancellation,
    ) -> CauseResult<()> {
        let _locks = self.held.family.locks(
            &self.held.artifacts.allocation.format.identity.worktree_id,
            true,
        )?;
        self.with_source(cancel,|source_c,proof,closure| {
            let owned=self.ready_data(self.rederive(source_c,closure,proof,cancel)?,protected.root(),cancel)?;
            let data=owned.as_data(self.manifests)?;
            let inputs=crate::projection::provider::destination_ready::ManagedReadyInputs {
                marker:&self.destination.proof().format,source:&proof.active.source,
                allocation:&self.held.artifacts.allocation,prepared:self.held.artifacts.prepared.as_ref().ok_or_else(||invalid("test prepared source absent"))?,
                activation:&proof.active.activation,prefix:&self.staging.plan.source_prefix,staging:owned.destination_staging(),closure,
                family_marker_bytes:self.held.family.marker_bytes(),data:&data,companion:self.ready_companion(proof),
            };
            managed_destination::valid(database_io::read_cancellable_strict(self.destination.destination_database(),cancel,|destination_c| {
                managed_destination::valid(database_io::read_cancellable_strict(&self.held.family.catalog,cancel,|family_c| {
                    let before=destination_c.total_changes();
                    let error=crate::projection::provider::destination_ready::validate_ready_data(source_c,destination_c,family_c,&inputs,Some(cancel)).err().ok_or_else(||invalid("C Ready accepted missing actual B protected root"))?;
                    assert!(error.to_string().contains("actual B protected root"),"{error}");
                    assert_eq!(destination_c.total_changes(),before);
                    assert!(!destination_c.query_row("SELECT EXISTS(SELECT 1 FROM projection_provider_transition_receipts WHERE transaction_id=?1)",[self.staging.transaction_id.as_str()],|r|r.get::<_,bool>(0))?);
                    Ok(())
                })?)
            })?)
        })
    }

    /// Actual production Store driver: B reserve -> C exact/install/protect ->
    /// B protect -> authorized checkout -> genuine private/family Ready -> B
    /// Ready atom -> separate Published. Every scope observes positive closes.
    /// The callback can request same-owner terminal replay while all proofs
    /// and the SAME mutable checkpoint are still retained, without self-reference.
    pub(in crate::projection::provider::bootstrap::preparation::activation) fn with_published_companion<
        T,
    >(
        &mut self,
        pins: &mut CompanionPins<'h>,
        close: &mut impl WriterCloseObserver,
        cancel: &Cancellation,
        action: impl FnOnce(
            &mut Self,
            &super::publication::ManagedFamilyReady<'_, '_>,
            &super::source_protection::ManagedSourceCompanionProtection<'_, '_>,
        ) -> CauseResult<T>,
    ) -> CauseResult<T> {
        let data = self
            .companion
            .as_ref()
            .ok_or_else(|| invalid("complete companion route absent"))?
            .publication;
        self.reserve_source_companion(data, close, cancel)?;
        self.reserve_plan(close, cancel)?;
        for index in 0..self.manifests.len() {
            let id = self.manifests[index].id().clone();
            self.install_exact(&id, close, cancel)?;
        }
        pins.exact = Some(self.protect_exact(close, cancel)?);
        #[cfg(test)]
        self.assert_unprotected_source_refuses_receipt(
            pins.exact
                .as_ref()
                .ok_or_else(|| invalid("C protection absent in test"))?,
            cancel,
        )?;
        pins.source = Some(self.protect_source_companion(data, close, cancel)?);
        let protected = pins
            .exact
            .as_ref()
            .ok_or_else(|| invalid("retained C protection absent"))?;
        pins.checkout = Some(self.copy_checkout(protected, close, cancel)?);
        let source = pins
            .source
            .as_ref()
            .ok_or_else(|| invalid("retained B protection absent"))?;
        let checkout = pins
            .checkout
            .as_ref()
            .ok_or_else(|| invalid("retained C checkout absent"))?;
        let private = self.finalize_private_ready(protected, checkout, close, cancel)?;
        #[cfg(test)]
        {
            let replay =
                self.finalize_private_ready(protected, checkout, &mut RefuseReplayWriter, cancel)?;
            if replay.receipt() != private.receipt() {
                return Err(invalid("companion private Ready replay changed receipt"));
            }
        }
        let family = self.publish_family_ready(&private, close, cancel)?;
        #[cfg(test)]
        {
            let replay = self.publish_family_ready(&private, &mut RefuseReplayWriter, cancel)?;
            if replay.receipt() != family.receipt() {
                return Err(invalid("companion family Ready replay changed receipt"));
            }
        }
        self.publish_source_companion(&family, source, close, cancel)?;
        action(self, &family, source)
    }
}
