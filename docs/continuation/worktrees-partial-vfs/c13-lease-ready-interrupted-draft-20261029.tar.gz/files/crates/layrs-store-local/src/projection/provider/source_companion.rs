//! Closed source publication DATA and its independently funded B SQL envelope.
//! Construction grants no authority. Managed retention supplies CAS/image pins
//! and both genuine C Ready scopes before this DATA reaches a source writer.
use super::{
    records::{
        import::{
            ImportRowset, ImportSource, ProviderImportPrefixRecord, ProviderTransitionReceiptRecord,
        },
        transition::{ProviderTransitionIntentRecord, TransitionRole, TransitionState},
        AllocationRecord, Record,
    },
    recovery::error::{invalid, Result},
    transition_reconcile::companions::OwnedCompanionData,
};
use crate::projection::shared::{
    exact_content::ExactBinding,
    source_companion::{SourceCompanionBinding, SourceCompanionProtection},
};
use layrs_vfs::Cancellation;
use rusqlite::{params, Connection};

pub(in crate::projection::provider) struct SourceCompanionPublication<'a> {
    rows: &'a OwnedCompanionData,
    protection: SourceCompanionProtection,
    receipt: ProviderTransitionReceiptRecord,
    ready: ProviderTransitionIntentRecord,
    published: ProviderTransitionIntentRecord,
    metadata: u64,
}
impl<'a> SourceCompanionPublication<'a> {
    /// Must run before the first reservation/content/publication effect. Every
    /// count, encoded size and overflow is fixed here from the immutable plan.
    pub(in crate::projection::provider) fn derive(
        a: &AllocationRecord,
        staging: &ProviderTransitionIntentRecord,
        c: &ExactBinding,
        rows: &'a OwnedCompanionData,
        cancel: Option<&Cancellation>,
    ) -> Result<Self> {
        staging.validate_fields()?;
        if staging.role != TransitionRole::Source || staging.state != TransitionState::Staging {
            return Err(invalid(
                "source companion derivation requires original source Staging",
            ));
        }
        let header = rows
            .header()
            .ok_or_else(|| invalid("source companion closed header absent"))?;
        if staging.plan.companion_id.as_deref() != Some(header.digest()?.as_str())
            || staging.plan.companion_files.count != header.file_count
            || staging.plan.companion_deletions.count != header.deletion_count
            || staging.plan.companion_files.digest != header.files_digest
            || staging.plan.companion_deletions.digest != header.deletions_digest
        {
            return Err(invalid(
                "source companion closed rows differ from immutable plan",
            ));
        }
        header.require_prefix(&staging.plan.source_prefix)?;
        let receipt = planned_receipt(staging)?;
        header.require_receipt(&receipt)?;
        let mut ready = ProviderTransitionIntentRecord::decode(&staging.encode()?)?;
        ready.state = TransitionState::Ready;
        ready.receipt_id = Some(receipt.digest()?);
        ready.require_transition(staging)?;
        ready.require_receipt(&receipt)?;
        let mut published = ProviderTransitionIntentRecord::decode(&ready.encode()?)?;
        published.state = TransitionState::Published;
        published.require_transition(&ready)?;
        let metadata = publication_bytes(rows.source_row_bytes()?, &ready, &published, &receipt)?;
        let binding = SourceCompanionBinding::new(a, staging, c)?;
        let protection =
            SourceCompanionProtection::new(binding, rows.manifests(), metadata, cancel)?;
        protection.require_plan(a, staging, cancel)?;
        Ok(Self {
            rows,
            protection,
            receipt,
            ready,
            published,
            metadata,
        })
    }
    pub(in crate::projection::provider) fn protection(&self) -> &SourceCompanionProtection {
        &self.protection
    }
    pub(in crate::projection::provider) fn rows(&self) -> &OwnedCompanionData {
        self.rows
    }
    pub(in crate::projection::provider) fn receipt(&self) -> &ProviderTransitionReceiptRecord {
        &self.receipt
    }
    pub(in crate::projection::provider) fn require(
        &self,
        a: &AllocationRecord,
        staging: &ProviderTransitionIntentRecord,
        receipt: &ProviderTransitionReceiptRecord,
        cancel: Option<&Cancellation>,
    ) -> Result<()> {
        let actual = Self::derive(
            a,
            staging,
            &self.protection.binding.destination,
            self.rows,
            cancel,
        )?;
        if actual.protection != self.protection
            || actual.metadata != self.metadata
            || actual.receipt != *receipt
        {
            return Err(invalid(
                "source companion closed rows, envelope or receipt changed",
            ));
        }
        self.protection.require_envelope(actual.metadata)
    }
    /// Only absent rows may be created. A partial/foreign rowset or claim in a
    /// Staging predecessor is rejected by the complete before interpreter.
    pub(in crate::projection::provider) fn insert(
        &self,
        c: &Connection,
        cancel: Option<&Cancellation>,
    ) -> Result<()> {
        if c.is_autocommit() || c.query_row("PRAGMA foreign_keys", [], |r| r.get::<_, u64>(0))? != 1
        {
            return Err(invalid(
                "source companion publication requires FK-enabled transaction",
            ));
        }
        self.protection.require_envelope(self.metadata)?;
        self.rows.insert_source_mappings_and_rows(c, cancel)?;
        let id = self.protection.id();
        if c.execute("INSERT INTO projection_claims(root_id,digest,kind,owner) VALUES(?1,?1,'provider-companion',?2)",params![id,self.protection.binding.destination.transaction_id])?!=1 {
            return Err(invalid("source companion claim insertion differs"));
        }
        self.require_rows(c, cancel)
    }
    pub(in crate::projection::provider) fn require_rows(
        &self,
        c: &Connection,
        cancel: Option<&Cancellation>,
    ) -> Result<()> {
        self.rows.require_new_rows(c, cancel)?;
        let n:u64=c.query_row("SELECT count(*) FROM projection_claims WHERE root_id=?1 AND digest=?1 AND kind='provider-companion' AND owner=?2",params![self.protection.id(),self.protection.binding.destination.transaction_id],|r|r.get(0))?;
        if n != 1 {
            return Err(invalid("source companion complete private claim absent"));
        }
        self.protection.require_envelope(publication_bytes(
            self.rows.source_row_bytes()?,
            &self.ready,
            &self.published,
            &self.receipt,
        )?)
    }
}

/// Deterministic real planned receipt, not a fake sizing record. No C Ready is
/// inferred from it: every value comes from the already immutable plan/proof.
pub(in crate::projection::provider) fn planned_receipt(
    staging: &ProviderTransitionIntentRecord,
) -> Result<ProviderTransitionReceiptRecord> {
    let p = &staging.plan;
    let prefix = &p.source_prefix;
    let ImportSource::Provider {
        identity, version, ..
    } = &prefix.source
    else {
        return Err(invalid("source receipt requires provider prefix"));
    };
    let destination = staging
        .destination
        .as_ref()
        .ok_or_else(|| invalid("source receipt destination absent"))?;
    let row = |r: &super::records::transition::TransitionRowset| ImportRowset {
        count: r.count,
        digest: r.digest.clone(),
    };
    let receipt = ProviderTransitionReceiptRecord {
        schema_version: "layrs.projection-provider-transition-receipt.v1".into(),
        owner_identity_digest: destination.owner_digest(p)?,
        transaction_id: staging.transaction_id.clone(),
        transition_plan_digest: p.digest()?,
        destination_proof_digest: destination.digest(p)?,
        source_prefix_id: p.source_prefix_id.clone(),
        source_prefix: ProviderImportPrefixRecord::decode(&prefix.encode()?)?,
        parent_receipt_id: prefix.ancestry_root_receipt.clone(),
        source_identity: identity.clone(),
        destination_identity: prefix.destination_identity.clone(),
        imported_max_generation: version.generation,
        destination_observation_generation: p.observation.generation,
        destination_observation_digest: p.observation.snapshot_digest.clone(),
        destination_placement_generation: p.placement_generation,
        destination_placement_digest: p.placement_digest.clone(),
        imported_capture_count: version.capture_count,
        destination_capture_sequence: p.capture_sequence,
        destination_capture_digest: p.capture_digest.clone(),
        protected_manifests: row(&p.protected_manifests),
        content_mappings: prefix.closure.content_mappings.clone(),
        companion_id: p.companion_id.clone(),
        companion_files: row(&p.companion_files),
        companion_deletions: row(&p.companion_deletions),
    };
    receipt.validate_fields()?;
    receipt.require_prefix(prefix)?;
    Ok(receipt)
}
fn add(sum: u64, bytes: u64) -> Result<u64> {
    sum.checked_add(bytes)
        .filter(|n| *n <= 1024 * 1024 * 1024)
        .ok_or_else(|| invalid("source SQL envelope overflow or exceeds 1GiB"))
}
/// Exact normalized values, conservatively charging reused mappings and BOTH
/// terminal intent projections. INTEGER=8, NULL=0, UTF8/BLOB=actual length.
pub(in crate::projection::provider) fn publication_bytes(
    base: u64,
    ready: &ProviderTransitionIntentRecord,
    published: &ProviderTransitionIntentRecord,
    receipt: &ProviderTransitionReceiptRecord,
) -> Result<u64> {
    let mut total = add(
        base,
        64 + 64 + "provider-companion".len() as u64 + receipt.transaction_id.len() as u64,
    )?;
    for n in [
        71,
        receipt.owner_identity_digest.len() as u64,
        receipt.transaction_id.len() as u64,
        receipt.companion_id.as_ref().map_or(0, |s| s.len() as u64),
        receipt.encode()?.len() as u64,
    ] {
        total = add(total, n)?;
    }
    for (intent, state) in [(ready, "ready"), (published, "published")] {
        intent.require_receipt(receipt)?;
        for n in [
            intent.transaction_id.len() as u64,
            6,
            state.len() as u64,
            8,
            intent.reservation.as_ref().map_or(0, |s| s.len() as u64),
            71,
            intent.encode()?.len() as u64,
            71,
        ] {
            total = add(total, n)?;
        }
    }
    Ok(total)
}
