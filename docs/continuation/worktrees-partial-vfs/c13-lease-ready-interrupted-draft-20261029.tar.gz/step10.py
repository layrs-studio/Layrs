from editlib import *
s=get(M+'companion.rs');i=s.index("impl<'h, 'd, 'a, 'c> ManagedImportLease")
s=s[:i]+'''/// Caller-owned progress keeps every acquired byte/checkout pin alive even
/// when a later COMMIT/connection-close acknowledgement is withheld. There is
/// no reference to the lease or mutable image, and no self-referential Ready.
#[derive(Default)]
pub(in crate::projection::provider::bootstrap::preparation::activation) struct CompanionPins<'h> {
    exact: Option<super::protection::ManagedImportProtection>,
    source: Option<super::source_protection::ManagedSourceCompanionProtection<'h,'h>>,
    checkout: Option<super::checkout::ManagedCheckoutProof>,
}
''' +s[i:]
a=s.index('    pub(super) fn with_published_companion<T>(')
s=s[:a]+s[a:].replace('''        &mut self,
        close:''','''        &mut self,
        pins: &mut CompanionPins<'h>,
        close:''',1)
s=s.replace('''        let protected = self.protect_exact(close, cancel)?;
        let source = self.protect_source_companion(data, close, cancel)?;
        let checkout = self.copy_checkout(&protected, close, cancel)?;
        let private = self.finalize_private_ready(&protected, &checkout, close, cancel)?;''','''        pins.exact = Some(self.protect_exact(close, cancel)?);
        pins.source = Some(self.protect_source_companion(data, close, cancel)?);
        let protected = pins.exact.as_ref().ok_or_else(|| invalid("retained C protection absent"))?;
        pins.checkout = Some(self.copy_checkout(protected, close, cancel)?);
        let source = pins.source.as_ref().ok_or_else(|| invalid("retained B protection absent"))?;
        let checkout = pins.checkout.as_ref().ok_or_else(|| invalid("retained C checkout absent"))?;
        let private = self.finalize_private_ready(protected, checkout, close, cancel)?;''')
s=s.replace('self.publish_source_companion(&family, &source, close, cancel)?;','self.publish_source_companion(&family, source, close, cancel)?;').replace('action(self, &family, &source)','action(self, &family, source)')
put(M+'companion.rs',s)
s=get(A+'managed_content.rs').replace('mod companion;','mod companion;\npub(super) use companion::CompanionPins;')
s=s.replace('''    metadata: u64, close: &mut impl WriterCloseObserver, cancel: &Cancellation,''','''    metadata: u64, pins: &mut CompanionPins<'_>, close: &mut impl WriterCloseObserver, cancel: &Cancellation,''')
s=s.replace('lease.with_published_companion(close,cancel,','lease.with_published_companion(pins,close,cancel,')
# Actual signature lifetimes get named when formatting: source DATA borrows
# remain independent of complete image's internal checkpoint/source lifetimes.
s=s.replace('pub(super) fn commit_companion(','pub(super) fn commit_companion<\'h, \'d, \'a, \'c>(')
s=s.replace('''    held: &outcome::PublicationPins, root: &layrs_vfs::ProviderRootGuard,
    mount: &ProviderActiveMountRecord, activation: &ProviderActivationRecord,
    attempt: &CaptureAttemptLock, destination: &managed_allocation::ManagedDestinationAllocation<'_>,
    image: &mut managed_image::complete::VerifiedCompleteManagedImage<'_, '_>,
    staging: &ProviderTransitionIntentRecord,
    publication: &crate::projection::provider::source_companion::SourceCompanionPublication<'_>,
    observation: &crate::projection::provider::transition_observation::TransitionObservationData,
    metadata: u64, pins: &mut CompanionPins<'_>,''','''    held: &'h outcome::PublicationPins, root: &'h layrs_vfs::ProviderRootGuard,
    mount: &'h ProviderActiveMountRecord, activation: &'h ProviderActivationRecord,
    attempt: &'h CaptureAttemptLock, destination: &'h managed_allocation::ManagedDestinationAllocation<'d>,
    image: &'h mut managed_image::complete::VerifiedCompleteManagedImage<'a, 'c>,
    staging: &'h ProviderTransitionIntentRecord,
    publication: &'h crate::projection::provider::source_companion::SourceCompanionPublication<'h>,
    observation: &'h crate::projection::provider::transition_observation::TransitionObservationData,
    metadata: u64, pins: &mut CompanionPins<'h>,''')
put(A+'managed_content.rs',s)
# Source reservation/protection callbacks independently rederive exactly the
# complete checkpoint/observation/plan before their B effects too.
s=get(M+'source_protection.rs')
s=s.replace('''                import_validation::verify_source_publication(c,''','''                let closure = import_validation::verify_source_publication(c,''',1)
# account for preexisting compact frozen code
needle='''&full,&version.effective_image_digest,Some(cancel))?;'''
assert needle in s
s=s.replace(needle,needle+'\n                self.rederive(c, &closure, &full, cancel)?;',1)
put(M+'source_protection.rs',s)
print('caller-owned physical progress pins retained on every failure')
