from editlib import *
s=get(P+'validation.rs');i=s.index('    /// A content context rereads')
s=s[:i]+'''    /// Compare the original no-pending source to one exact transition's live
    /// state. Prior publication/companion history stays byte-exact; only this
    /// transaction may append its independently validated terminal artifacts.
    pub(in crate::projection::provider) fn require_transition_predecessor(
        &self, full: &PrivateActivePublicationValidation, staging: &records::transition::ProviderTransitionIntentRecord,
    ) -> Result<()> {
        let tx=staging.transaction_id.as_str();
        if self.full.transitions.iter().any(|r| r.transaction_id==tx)
            || !self.full.transitions.iter().eq(full.transitions.iter().filter(|r|r.transaction_id!=tx))
            || !self.full.receipts.iter().eq(full.receipts.iter().filter(|r|r.transaction_id!=tx))
            || !self.full.companions.groups().iter().eq(full.companions.groups().iter().filter(|r|r.transaction!=tx))
        { return Err(invalid("transition changed retained source publication history")); }
        let current=full.transitions.iter().find(|r|r.transaction_id==tx).ok_or_else(||invalid("retained transition absent"))?;
        if current.plan!=staging.plan || current.destination!=staging.destination || current.local_generation!=staging.local_generation
            || current.role!=staging.role || current.reservation!=staging.reservation
            || !matches!(current.state,records::transition::TransitionState::Staging|records::transition::TransitionState::Ready|records::transition::TransitionState::Published)
        {return Err(invalid("retained transition original prefix/plan differs"));}
        let a=&self.full.active;let b=&full.active;let x=&self.full.capture;let y=&full.capture;
        if a.mount!=b.mount || a.activation!=b.activation || a.source.commitment()!=b.source.commitment()
            || a.activated.generation!=b.activated.generation || a.activated.digest!=b.activated.digest || a.activated.snapshot!=b.activated.snapshot
            || x.transactions!=y.transactions || x.receipts!=y.receipts || x.patches!=y.patches
            || !x.content.iter().map(|r|(&r.file_id,&r.manifest_id,r.bytes)).eq(y.content.iter().map(|r|(&r.file_id,&r.manifest_id,r.bytes)))
            || !x.claims.iter().map(|r|(&r.root_id,&r.digest,&r.kind,&r.owner)).eq(y.claims.iter().map(|r|(&r.root_id,&r.digest,&r.kind,&r.owner)))
        {return Err(invalid("transition changed retained complete source predecessor"));}
        Ok(())
    }

''' +s[i:];put(P+'validation.rs',s)
s=get(A+'session/transition_source.rs');i=s.index('    pub fn identity(&self)')
s=s[:i]+'''    /// Internal pending-transition reauthentication. Public getters remain
    /// DATA. This retains the actual session/owner and deliberately bypasses
    /// only the no-pending VIEW opener, never original-prefix equality.
    pub(in crate::projection::provider::bootstrap::preparation::activation) fn require_transition(
        &self, held: &outcome::PublicationPins, root: &layrs_vfs::ProviderRootGuard,
        full: &crate::projection::provider::validation::PrivateActivePublicationValidation,
        staging: &crate::projection::provider::records::transition::ProviderTransitionIntentRecord,
        cancel: &Cancellation,
    ) -> CauseResult<()> {
        cancel.check()?;
        if !self.session.is_connected() || self.session.source.lifecycle.get().is_none()
            || !std::ptr::eq(held,&self.session.source.held)
            || root.registration().root_id()!=self.session.source.root.registration().root_id()
            || root.control_directory().identity()!=self.session.source.root.control_directory().identity()
        {return Err(invalid("retained transition source session/root owner differs"));}
        self.state.require_transition_predecessor(full,staging)
    }

''' +s[i:];put(A+'session/transition_source.rs',s)
s=get(M+'companion.rs')
s=s.replace("    pub(super) publication: &'h SourceCompanionPublication<'h>,","    pub(super) publication: &'h SourceCompanionPublication<'h>,\n    anchor: &'h super::super::session::ProviderTransitionSource<'h>,",1)
s=s.replace("        publication: &'h SourceCompanionPublication<'h>,","        publication: &'h SourceCompanionPublication<'h>,\n        anchor: &'h super::super::session::ProviderTransitionSource<'h>,",1)
s=s.replace('''                publication,
                observation,''','''                publication,
                anchor,
                observation,''',1)
needle='''        let ManagedImage::Complete(image) = &self.image else {'''
s=s.replace(needle,'''        data.anchor.require_transition(self.held,self.root,full,self.staging,cancel)?;
'''+needle,1)
put(M+'companion.rs',s)
s=get(A+'managed_content.rs')
s=s.replace("    publication: &'h crate::projection::provider::source_companion::SourceCompanionPublication<'h>,","    publication: &'h crate::projection::provider::source_companion::SourceCompanionPublication<'h>,\n    anchor: &'h session::ProviderTransitionSource<'h>,")
# Existing parent activation imports session::*; qualify explicit module if available.
s=s.replace('''        publication,
        observation,''','''        publication,
        anchor,
        observation,''',1)
put(A+'managed_content.rs',s)
s=get(A+'session/c13_complete_ready_tests.rs')
s=s.replace('''    let full = {''','''    let anchor=session.transition_source(&cancel).unwrap();
    let full = {''',1)
s=s.replace('''        &publication,
        &observation,''','''        &publication,
        &anchor,
        &observation,''',1)
put(A+'session/c13_complete_ready_tests.rs',s)
print('actual session-owned full source anchor retained and transition-specific equality wired')
