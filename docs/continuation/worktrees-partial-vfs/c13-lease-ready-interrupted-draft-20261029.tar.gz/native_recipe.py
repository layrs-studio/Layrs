from editlib import *
put(A+'session/c13_complete_ready_tests.rs',r'''//! Authored integrated native recipe, NOT RUN. Uses real Provider bootstrap,
//! accepted Capture, retained export, exact C engine and private/family Ready.
//! Local observation is fixture DATA, never a server-held authority lease.
use super::*;
use crate::projection::provider::{
    bootstrap::tests::{capture_family,fixture::Fixture},
    capture_lock::CaptureAttemptLock,
    database_io::{self,WriterCloseObserver,WriterOpenPoint},
    import_validation::{self,ImportDatabaseKind},
    managed_ready_reopen::ManagedReadyInspection,
    process_profile::tests::child,
    records::{import::{ImportClosure,ImportRowset,ImportSource,ImportSourceReferences,ImportVersion,ProviderImportKind,ProviderImportPrefixRecord},
        transition::{ProviderTransitionIntentRecord,TransitionRole,TransitionState},ProviderBootstrapSource,ProviderSourceDescriptor,Record},
    source_companion::SourceCompanionPublication,
    transition_observation::{SourceObservationData,TransitionObservationData,ObservationCoverageData,AuthorityObservationData},
    transition_reconcile::source_sql,
    validation,
};
use layrs_core::{projection::{EntryState,ProjectionEntry},scm::{Chunk,ChunkingDescriptor,FileManifest,RepoPath,TreeEntryTarget,WorktreeId}};
use rusqlite::{ffi,Connection};
use std::{collections::BTreeMap,fs,path::{Path,PathBuf}};

#[derive(Default)]
struct Close {opens:usize,closes:usize}
impl WriterCloseObserver for Close {
    fn open_point(&mut self,p:WriterOpenPoint,_:*mut ffi::sqlite3)->CauseResult<()> {if p==WriterOpenPoint::BeforeRaw {self.opens+=1;} Ok(())}
    fn before_close(&mut self,_:*mut ffi::sqlite3)->Option<Cause>{None}
    fn after_close(&mut self,success:bool)->Option<Cause>{assert!(success,"positive SQLite CONNECTION close observation; no OS handle-close claim");self.closes+=1;None}
}
fn replace(path:&Path,bytes:&[u8]) {
    if fs::remove_file(path).is_err(){let mut p=fs::metadata(path).unwrap().permissions();p.set_readonly(false);fs::set_permissions(path,p).unwrap();fs::remove_file(path).unwrap();}
    fs::write(path,bytes).unwrap();
}
fn manifest(bytes:&[u8],native:bool)->FileManifest {
    FileManifest::from_chunks(if native {ChunkingDescriptor::deterministic_fixed(1048576).unwrap()} else {ChunkingDescriptor::single()},&[Chunk::new(bytes.to_vec()).unwrap()]).unwrap()
}
fn with_source(test:impl FnOnce(&Fixture,&ProviderActiveSession,&[u8],&[u8])->PathBuf)->PathBuf {
    let old=Fixture::writable_file_source();
    let accepted=b"C13 real accepted writable edit";
    let recovered=b"provider base content";
    let mut snapshot=old.initial().clone();
    let recovery_manifest=manifest(accepted,false);
    snapshot.entries.push(ProjectionEntry {path:RepoPath::parse("recovery.txt").unwrap(),target:Some(TreeEntryTarget::File{file_id:recovery_manifest.file_id().clone()}),executable:false,writable:true,state:EntryState::Unavailable});
    snapshot.entries.sort_by(|a,b|a.path.cmp(&b.path));
    let mut descriptors=old.descriptors().iter().map(|d|ProviderSourceDescriptor{path:d.path.clone(),manifest:d.manifest.clone()}).collect::<Vec<_>>();
    descriptors.push(ProviderSourceDescriptor{path:RepoPath::parse("recovery.txt").unwrap(),manifest:recovery_manifest});
    descriptors.sort_by(|a,b|a.path.cmp(&b.path));
    let source=ProviderBootstrapSource::validate(snapshot,old.selection().clone(),descriptors).unwrap();
    let (f,holder,allocation,_,binding)=capture_family::active_holder_with_source(Some(source));
    drop(holder);
    crate::projection::provider::family_upgrade::upgrade_source_family(f.family.root(),&f.worktree,&allocation.transaction_id,&mut Close::default(),&Cancellation::default()).unwrap();
    let mut session=PartialStoreFamily::open_provider_active(f.family.root(),&f.worktree,&binding.transaction_id,&binding).unwrap().into_disconnected_session().unwrap_or_else(|e|panic!("session: {}",e.cause()));
    session.connect().unwrap();
    replace(&f.checkout.join("README.md"),accepted);
    let ack=session.capture("c13-real-accepted",&Cancellation::default()).unwrap();
    assert_eq!(ack.patch.changes.len(),1);
    assert_eq!(ack.patch.changes[0].path.as_str(),"README.md");
    // This path was explicitly registered as a writable PRESENT file before
    // bootstrap. No unknown-path or Capture authority guard is bypassed.
    replace(&f.checkout.join("recovery.txt"),recovered);
    let result=test(&f,&session,accepted,recovered);
    session.disconnect().unwrap();
    result
}

fn publish(f:&Fixture,session:&ProviderActiveSession,accepted:&[u8],recovered:&[u8])->PathBuf {
    let cancel=Cancellation::default();let held=&session.source.held;
    let full={let _locks=held.family.locks(&held.artifacts.allocation.format.identity.worktree_id,false).unwrap();capture_state::read_live(held,Some(&session.source.root),Some(&cancel)).unwrap_or_else(|e|panic!("source read: {}",e.cause))};
    assert_eq!(full.capture.patches.len(),1);
    let mut checkpoint=session.session.export_checkpoint().unwrap();
    let mut image=super::super::managed_image::complete::plan(&mut checkpoint,session.source.as_ref(),&full.active.source,&full.active.activated.snapshot,&cancel).unwrap();
    let parent=session.session.guard_export_parent(&f.outer).unwrap();let parent_path=parent.root().to_str().unwrap().to_owned();let parent_identity=parent.filesystem_identity();drop(parent);
    let mut destination_identity=held.artifacts.allocation.format.identity.clone();destination_identity.worktree_id=WorktreeId::parse("worktree:c13-complete-ready").unwrap();
    let placeholder=|count|ImportRowset{count,digest:format!("blake3:{}","0".repeat(64))};
    let mut segment_hash=blake3::Hasher::new();segment_hash.update(b"layrs-projection-provider-import-segments-v1\0");segment_hash.update(&0u64.to_be_bytes());
    let source=&full.active.source;let a=&held.artifacts.allocation;let prepared=held.artifacts.prepared.as_ref().unwrap();
    let mut prefix=ProviderImportPrefixRecord {
        schema_version:"layrs.projection-provider-import-prefix.v1".into(),kind:ProviderImportKind::ManagedOrdinary,
        source:ImportSource::Provider{identity:a.format.identity.clone(),format_digest:crate::projection::provider::records::codec::hash("layrs-projection-provider-import-format-v1",&a.format.bytes().unwrap()),private_schema:8,allocation:a.data_reference().unwrap(),prepared:prepared.data_reference().unwrap(),binding:crate::projection::provider::records::ProviderBootstrapBinding::decode(&held.binding.encode().unwrap()).unwrap(),activation_map_id:full.active.activation.digest().unwrap(),version:ImportVersion{generation:full.active.activated.generation,snapshot_digest:full.active.activated.digest.clone(),selection_digest:full.active.activation.selection_digest.clone(),capture_count:1,capture_head:Some(full.capture.patches[0].digest.clone()),effective_image_digest:image.digest().into()}},
        destination_identity,inherited_segments:ImportRowset{count:0,digest:format!("blake3:{}",segment_hash.finalize())},ancestry_root_receipt:None,
        closure:ImportClosure{restore_history:None,snapshots:placeholder(2),selections:placeholder(1),captures:placeholder(1),publications:placeholder(0),catalogs:placeholder(1),descriptors:placeholder(2),activation_maps:placeholder(1),transition_receipts:placeholder(0),companions:placeholder(0),companion_files:placeholder(0),companion_deletions:placeholder(0),content_mappings:placeholder(1)},
    };
    let (observation,rows,derived,metadata)={
        let _locks=held.family.locks(&a.format.identity.worktree_id,false).unwrap();
        super::super::managed_destination::valid(database_io::read_cancellable_strict(&held.artifacts.database,&cancel,|c| {
            let proof=validation::private_active_publication_with_source(c,a,prepared,&held.binding,Some(session.source.root.registration().root_id()),Some(&cancel))?;
            let refs=||ImportSourceReferences::Provider{allocation:a,prepared,activation:&proof.active.activation};
            let meta=import_validation::read_source_metadata(c,&a.format,ImportDatabaseKind::Provider,&prefix,refs(),image.digest(),Some(&cancel))?;
            prefix.closure=import_validation::compute_scoped_closure(c,ImportDatabaseKind::Provider,&prefix,&meta,Some(&cancel))?;
            let closure=import_validation::verify_source_publication(c,&a.format,&prefix,refs(),&proof,image.digest(),Some(&cancel))?;
            let input=SourceObservationData{prefix:&prefix,identity:&a.format.identity,snapshot:&proof.active.activated.snapshot,snapshot_parent_digest:Some(&proof.active.activation.source_digest),selection:source.selection(),selection_generation:source.commitment().source_generation,selection_snapshot_digest:&source.commitment().snapshot_digest};
            let mut fresh=source.initial().clone();fresh.observed_authorization_epoch+=1;
            let denied=fresh.entries.iter_mut().find(|e|e.path.as_str()=="recovery.txt").unwrap();denied.writable=false;denied.state=EntryState::Reserved;
            let policy=fresh.observed_policy_set_id.clone();let epoch=fresh.observed_authorization_epoch;
            let descriptors=source.descriptors().iter().filter(|d|d.path.as_str()=="README.md").map(|d|ProviderSourceDescriptor{path:d.path.clone(),manifest:d.manifest.clone()}).collect();
            let observation=TransitionObservationData::normalize(input,prefix.destination_identity.clone(),proof.active.activated.generation+1,fresh,source.selection().clone(),descriptors,ObservationCoverageData::default(),AuthorityObservationData::ReobservedExpandedScope{policy_set_id:policy,authorization_epoch:epoch},Some(&cancel))?;
            let mut all=BTreeMap::new();
            for m in source.descriptors().iter().map(|d|&d.manifest).chain(image.retained().files().iter().map(|f|f.manifest.manifest())) {all.insert((m.file_id().clone(),m.id().clone()),m.clone());}
            let manifests=all.into_values().collect::<Vec<_>>();
            // Same measured/conservative envelope convention as existing
            // managed recipes. Q_B itself is independently derived exactly.
            let metadata=closure.metadata_bytes(c,&prefix,Some(&cancel))?+2*ProviderTransitionIntentRecord::MAX_BYTES as u64+8*65536;
            let rows=source_sql::with_source(c,&a.format,&prefix,&closure,&proof,&observation,Some(&cancel),|source| image.reconcile_publication_retained(source,&observation,&proof,&manifests,metadata,&cancel))?;
            let derived=super::super::managed_plan::derive_reconciled_data(&prefix,&rows,&observation,prefix.destination_identity.clone(),&parent_path,&parent_identity,"00000000000000000000000000000071","00000000000000000000000000000072")?;
            Ok((observation,rows,derived,metadata))
        }).unwrap()).unwrap()
    };
    assert_eq!(rows.overlay().len(),1);assert_eq!(rows.authorized_files().len(),1);assert_eq!(rows.header().unwrap().file_count,1);assert_eq!(rows.manifests().len(),4);
    let planned=ProviderTransitionIntentRecord{schema_version:"layrs.projection-provider-transition-intent.v1".into(),transaction_id:derived.transaction_id.clone(),role:TransitionRole::Source,state:TransitionState::Planned,local_generation:full.active.activated.generation,plan:derived.plan,destination:None,reservation:None,receipt_id:None};planned.encode().unwrap();
    let attempt=CaptureAttemptLock::acquire(&held.artifacts,&held.family).unwrap();let mut close=Close::default();
    super::super::managed_journal::begin_complete(held,&session.source.root,&session.source.record,&session.source.activation,&attempt,&mut image,&planned,&mut close,&cancel).unwrap();
    let (mut destination,copying)=super::managed_allocation_tests::bound_holder(session,&attempt,&planned);
    destination.publish_format(&session.source.root,&session.source.record,&session.source.activation,&attempt,&copying,&cancel).unwrap();
    super::super::managed_destination::register_and_copy(held,&session.source.root,&session.source.record,&session.source.activation,&attempt,&copying,&destination,&mut close,&cancel).unwrap();
    let mut staging=ProviderTransitionIntentRecord::decode(&copying.encode().unwrap()).unwrap();staging.state=TransitionState::Staging;staging.reservation=Some(staging.reservation_operation().unwrap());
    super::super::managed_staging::stage_complete(held,&session.source.root,&session.source.record,&session.source.activation,&attempt,&copying,&staging,&destination,&mut image,rows.manifests(),&mut close,&cancel).unwrap();
    let binding={
        let family=&a.family;let proof=destination.proof();let shared=proof.format.shared.as_ref().unwrap();let operation=staging.reservation_operation().unwrap();
        crate::projection::shared::exact_content::ExactBinding{family_incarnation:family.incarnation.clone(),family_root_identity:family.root_identity.clone(),family_marker_digest:family.marker_digest.clone(),family_catalog_identity:family.catalog_file_identity.clone(),plan_digest:staging.plan.digest().unwrap(),prefix_id:staging.plan.source_prefix_id.clone(),destination_proof_digest:proof.digest(&staging.plan).unwrap(),transaction_id:staging.transaction_id.clone(),owner:proof.format.identity.worktree_id.clone(),database_identity:shared.database_identity.clone(),reservation:operation.clone(),operation,quota_bytes:staging.plan.quota_bytes}
    };
    let publication=SourceCompanionPublication::derive(a,&staging,&binding,&rows,Some(&cancel)).unwrap();
    let mut pins=super::super::managed_content::CompanionPins::default();
    let mut lease=super::super::managed_content::ManagedImportLease::open_companion(held,&session.source.root,&session.source.record,&session.source.activation,&attempt,&destination,&mut image,&staging,&publication,&observation,metadata,&cancel).unwrap();
    let requests=session.hydration_requests().len();
    lease.with_published_companion(&mut pins,&mut close,&cancel,|lease,family,source| {
        assert!(family.receipt().companion_id.is_some());
        assert_eq!(family.receipt().protected_manifests.count,4);
        lease.assert_companion_ready_refusals(family,source,&cancel)?;
        let mut replay=Close::default();
        let terminal=lease.publish_source_companion(family,source,&mut replay,&cancel)?;
        assert_eq!(terminal.source_published().state,TransitionState::Published);
        assert_eq!((replay.opens,replay.closes),(0,0),"same-owner Published replay opens no writer");
        for file in [&held.artifacts.database,destination.destination_database()] {
            super::super::managed_destination::valid(database_io::read_cancellable_strict(file,&cancel,|c| {
                publication.rows().require_new_rows(c,Some(&cancel))?;
                let receipt:Vec<u8>=c.query_row("SELECT payload FROM projection_provider_transition_receipts WHERE transaction_id=?1",[staging.transaction_id.as_str()],|r|r.get(0))?;
                assert_eq!(receipt,family.receipt().encode()?);
                Ok(())
            })?)?;
        }
        Ok(())
    }).unwrap();
    assert_eq!(session.hydration_requests().len(),requests);
    assert_eq!(close.opens,close.closes);
    assert_eq!(fs::read(destination.root().join("README.md")).unwrap(),accepted);
    assert!(!destination.root().join("recovery.txt").exists());
    assert_eq!(fs::read(f.checkout.join("recovery.txt")).unwrap(),recovered);
    // Only the root path escapes. Complete image, both owners, source native
    // session, CAS/checkout proof handles and all SQL scopes drop normally.
    destination.root().to_owned()
}

#[test]
#[ignore="UNQUALIFIED integrated C13 complete/Ready route; ROOT serial child3600/outer3660 release required; bounds unmeasured"]
fn c13_real_accepted_edit_denied_present_companion_reaches_c_ready_and_b_published() {
    child::run(concat!(module_path!(),"::c13_real_accepted_edit_denied_present_companion_reaches_c_ready_and_b_published"),3600,||{
        child::declare();
        let destination=with_source(publish);
        let cancel=Cancellation::default();
        let reopened=ManagedReadyInspection::open(&destination,&cancel).unwrap();
        reopened.require(&cancel).unwrap();
        assert!(reopened.ready().plan.companion_id.is_some());
        assert_eq!(reopened.required().len(),4);
        assert_eq!(reopened.expected().files().len(),1);
        assert!(reopened.journal().is_complete());
    });
}
''')
edit(A+'session.rs','mod c13_provider_preservation_tests;','mod c13_provider_preservation_tests;\n#[cfg(test)]\n#[path = "session/c13_complete_ready_tests.rs"]\nmod c13_complete_ready_tests;')
# The production publication reconcile route rejects C14 input before planning.
s=get(A+'managed_image/complete.rs');needle='''        let source = source.publication_descriptor_view(proof, Some(cancel))?;'''
s=s.replace(needle,'''        if observation.binding().denied_path_count != 0 { return Err(invalid("C14 durable denied-absence contract required before effects")); }
'''+needle);put(A+'managed_image/complete.rs',s)
print('registered genuine integrated native same-owner + autonomous recipe authored (NOT RUN)')
