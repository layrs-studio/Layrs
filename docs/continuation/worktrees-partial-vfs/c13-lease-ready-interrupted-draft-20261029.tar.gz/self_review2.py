from editlib import *
s=get(A+'managed_destination.rs')
s=s.replace('''let read = database_io::read_cancellable(&held.artifacts.database, cancel, |c|''','''let read = database_io::read_cancellable_strict(&held.artifacts.database, cancel, |c|''')
s=s.replace('''    let effect = bare.finish_writer(result, close)?;''','''    let result = rollback(bare.connection(),result);
    let effect = bare.finish_writer(result, close)?;''')
s=s.replace('''    bare.finish_writer(result, close)
}''','''    let result=rollback(bare.connection(),result);
    bare.finish_writer(result, close)
}''')
s+='''
/// Roll back a failed owned SQL operation before any enclosing connection
/// scope closes. Preserve both primary and rollback failure, with no retry.
pub(super) fn rollback<T>(c:&Connection,result:CauseResult<T>)->CauseResult<T> {
    match result {
        Err(primary) if !c.is_autocommit()=>match c.execute_batch("ROLLBACK") {
            Ok(())=>Err(primary),Err(close)=>Err(Cause::Cleanup{primary:Box::new(primary),close:Box::new(close.into())}),
        },
        other=>other,
    }
}
''';put(A+'managed_destination.rs',s)
for rel in ['managed_staging.rs','managed_journal.rs']:
 s=get(A+rel).replace('''    let effect = bare.finish_writer(result, close)?;''','''    let result=managed_destination::rollback(bare.connection(),result);
    let effect = bare.finish_writer(result, close)?;''');put(A+rel,s)
s=get(A+'managed_image/complete.rs')
a=s.index('''        self.revalidate(cancel)?;''',s.index('    pub(in crate::projection::provider) fn copy_exact_chunk('));b=s.index('    pub(in crate::projection::provider) fn copy_exact_file(',a)
s=s[:a]+'''        exact_file(self.retained.files(),path,manifest)?;
        if self.offline.is_some() { return self.copy_required_chunk(manifest,ordinal,output,cancel); }
        self.revalidate(cancel)?;
        self.retained.copy_exact_chunk(path,manifest,ordinal,output,cancel)?;
        self.revalidate(cancel)
    }
''' +s[b:]
a=s.index('''        self.revalidate(cancel)?;''',s.index('    pub(in crate::projection::provider) fn copy_exact_file('));b=s.index('    pub(in crate::projection::provider) fn revalidate(',a)
s=s[:a]+'''        self.revalidate(cancel)?;
        let file=exact_file(self.retained.files(),path,manifest)?;
        if self.offline.is_some() && matches!(&file.manifest,ManagedManifest::Source(_)) {
            let mut offset=0u64;
            stream::copy_verified(manifest,output,cancel,|buffer| {
                self.read_offline(manifest.file_id(),offset,buffer,cancel)?;
                offset=offset.checked_add(buffer.len() as u64).ok_or_else(||invalid("offline complete file offset overflow"))?;
                Ok(())
            })?;
        } else { self.retained.copy_exact_file(path,manifest,output,cancel)?; }
        self.revalidate(cancel)
    }
''' +s[b:];put(A+'managed_image/complete.rs',s)
# Remove source-only unused imports that can obscure ownership review.
s=get(M+'companion.rs').replace('transition_reconcile::{companions::OwnedCompanionData, source_sql},','transition_reconcile::source_sql,');put(M+'companion.rs',s)
s=get(P+'destination_ready/retained_companion.rs').replace('checkout_journal::{CheckoutFile, ExpectedCheckout},','checkout_journal::ExpectedCheckout,');put(P+'destination_ready/retained_companion.rs',s)
print('all newly used initial writers have explicit rollback; pinned complete copy wrappers stay offline')
