from editlib import *
q='crates/layrs-store-local/src/projection/shared/exact_content/published_cas.rs'
s=get(q);i=s.index('fn protection(')
s=s[:i]+r'''/// Independently verified existing offline bytes. This is deliberately not a
/// Published installation/receipt/protection witness. It performs no SQL or
/// creation, and retains ordinary immutable CAS handles through later effects.
pub(in crate::projection) struct ResidentCasProof {
    storage: ExactStorage,
    required: Vec<FileManifest>,
    objects: BTreeMap<(bool,String),PinnedFile>,
}
pub(in crate::projection) fn pin_resident_cas(storage:ExactStorage, required:&[FileManifest], cancel:&Cancellation)->Result<ResidentCasProof> {
    let mut result=ResidentCasProof{storage,required:required.to_vec(),objects:BTreeMap::new()};
    for manifest in required {cancel.check()?;verify_manifest(&result.storage,&mut result.objects,manifest,cancel)?;}
    result.verify(cancel)?;Ok(result)
}
impl ResidentCasProof {
    pub(in crate::projection) fn verify(&self,cancel:&Cancellation)->Result<()> {
        self.storage.verify()?;
        for ((manifest,name),pin) in &self.objects {
            cancel.check()?;
            require_same_file(if *manifest {&self.storage.manifests}else{&self.storage.chunks},name,pin)?;
        }
        Ok(())
    }
    pub(in crate::projection) fn read_exact_at(&self,file:&FileId,offset:u64,output:&mut[u8],cancel:&Cancellation)->Result<()> {
        self.verify(cancel)?;
        let manifest=self.required.iter().find(|m|m.file_id()==file).ok_or_else(||invalid("offline source FileId has no retained resident-byte owner"))?;
        let end=offset.checked_add(output.len() as u64).filter(|end|*end<=manifest.byte_length()).ok_or_else(||invalid("offline resident source range differs"))?;
        let mut copied=0usize;
        for chunk in manifest.chunks() {
            let chunk_end=chunk.offset().checked_add(chunk.byte_length()).ok_or_else(||invalid("offline resident chunk range overflow"))?;
            let start=offset.max(chunk.offset());let stop=end.min(chunk_end);
            if start>=stop {continue;}
            let name=object_name(chunk.chunk_id().as_str())?;
            let pin=self.objects.get(&(false,name.to_owned())).ok_or_else(||invalid("offline resident pinned chunk absent"))?;
            let count=usize::try_from(stop-start).map_err(|_|invalid("offline resident copy bound"))?;
            let mut reader=pin.file();reader.seek(SeekFrom::Start(start-chunk.offset()))?;
            reader.read_exact(&mut output[copied..copied+count])?;copied+=count;
        }
        if copied!=output.len(){return Err(invalid("offline source pinned range incomplete"));}
        self.verify(cancel)
    }
}

''' +s[i:];put(q,s)
edit('crates/layrs-store-local/src/projection/shared/exact_content.rs','pub(in crate::projection) use published_cas::{verify_published_cas, PublishedCasProof};','pub(in crate::projection) use published_cas::{pin_resident_cas, ResidentCasProof, verify_published_cas, PublishedCasProof};')
s=get(A+'managed_image/complete.rs')
s=s.replace("    retained: VerifiedManagedImage<'a, 'c>,","    retained: VerifiedManagedImage<'a, 'c>,\n    offline: Option<crate::projection::shared::exact_content::ResidentCasProof>,",1)
s=s.replace('build_complete(checkpoint, bytes, source, activated, cancel)?','build_complete(checkpoint, bytes, source, activated, None, cancel)?',1)
s=s.replace('''            data,
        },
    })''','''            data,
        },
        offline: None,
    })''',1)
i=s.index('    /// Pin/namespace-only check')
s=s[:i]+r'''    /// Pin actual already-resident immutable current bytes before B's first
    /// reservation. Later complete-image rehashes must not reacquire source
    /// range readers, whose ordinary no-pending family view cannot classify B's
    /// reserved-but-unpublished root. No hydration or new bytes are acquired.
    pub(in crate::projection::provider) fn pin_offline_current(
        &mut self, storage:crate::projection::shared::exact_content::ExactStorage, cancel:&Cancellation,
    )->Result<()> {
        if let Some(offline)=&self.offline {return offline.verify(cancel);}
        let mut manifests=BTreeMap::new();
        for file in self.retained.files() {
            if let ManagedManifest::Source(manifest)=&file.manifest {manifests.insert(manifest.id().clone(),(*manifest).clone());}
        }
        self.offline=Some(crate::projection::shared::exact_content::pin_resident_cas(storage,&manifests.into_values().collect::<Vec<_>>(),cancel)?);
        Ok(())
    }
    fn read_offline(&self,file:&FileId,offset:u64,output:&mut[u8],cancel:&Cancellation)->Result<()> {
        match &self.offline {
            Some(offline)=>offline.read_exact_at(file,offset,output,cancel),
            None=>self.retained.bytes.read_exact_at(file,offset,output,cancel).map_err(Into::into),
        }
    }
''' +s[i:]
s=s.replace('''                    self.retained
                            .bytes
                            .read_exact_at(manifest.file_id(), offset, buffer, cancel)
                            .map_err(Into::into)''','''                    self.read_offline(manifest.file_id(),offset,buffer,cancel)''')
s=s.replace('''                self.retained
                    .bytes
                    .read_exact_at(manifest.file_id(), offset, buffer, cancel)
                    .map_err(Into::into)''','''                self.read_offline(manifest.file_id(),offset,buffer,cancel)''')
# Ensure both formatting variants were replaced without accidental source calls.
s=s.replace('''                        self.retained
                            .bytes
                            .read_exact_at(manifest.file_id(), offset, buffer, cancel)
                            .map_err(Into::into)''','''                        self.read_offline(manifest.file_id(),offset,buffer,cancel)''')
s=s.replace('''            self.retained.activated,
            cancel,''','''            self.retained.activated,
            self.offline.as_ref(),
            cancel,''',1)
s=s.replace('''    activated: &ProjectionSnapshot,
    cancel: &Cancellation,
) -> Result<ImageData<'a>>''','''    activated: &ProjectionSnapshot,
    offline: Option<&crate::projection::shared::exact_content::ResidentCasProof>,
    cancel: &Cancellation,
) -> Result<ImageData<'a>>''')
s=s.replace('''                        bytes.read_exact_at(&descriptor.file_id, offset, output, cancel)''','''                        match offline {
                            None=>bytes.read_exact_at(&descriptor.file_id,offset,output,cancel),
                            Some(offline)=>offline.read_exact_at(&descriptor.file_id,offset,output,cancel).map_err(|e|layrs_vfs::Error::Io(io::Error::other(e))),
                        }''')
put(A+'managed_image/complete.rs',s)
s=get(M+'companion.rs')
s=s.replace('''        lease.rehash(cancel)?;
        // Opening''','''        lease.expected_protection(cancel)?;
        let offline_storage=lease.pin_exact_storage()?;
        if let ManagedImage::Complete(image)=&mut lease.image {image.pin_offline_current(offline_storage,cancel)?;}
        lease.rehash(cancel)?;
        // Opening''',1)
# Keep focused test probes from changing valid protected-root replay behavior.
needle='''                        let before = destination_c.total_changes();'''
# first occurrence belongs dedicated unprotected-source helper
s=s.replace(needle,'''                        let context=inputs.companion.as_ref().ok_or_else(||invalid("test companion context absent"))?;
                        if context.source_context.pending.ok_or_else(||invalid("test B root absent"))?.inspect(family_c,Some(cancel))?==crate::projection::shared::source_companion::SourceCompanionPresence::Protected {return Ok(());}
'''+needle,1)
put(M+'companion.rs',s)
print('pinned actual immutable offline source bytes prevent pending-B range-reader dependency')
