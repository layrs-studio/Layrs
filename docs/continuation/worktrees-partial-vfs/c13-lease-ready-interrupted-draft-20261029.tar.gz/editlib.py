from pathlib import Path
import subprocess
O=Path('D:/Layrs/tmp/c13-complete-lease-ready-source-proposal')
P='crates/layrs-store-local/src/projection/provider/'
def get(p):
 q=O/'files'/p
 if not q.exists():
  q.parent.mkdir(parents=True,exist_ok=True)
  q.write_bytes(subprocess.run(['git','show','6b1f5632bd7f6092226d57e3c813033a82bcfc98:'+p],cwd='D:/Layrs/layrs',capture_output=True,check=True).stdout)
 return q.read_text()
def put(p,s):
 q=O/'files'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s,newline='\n')
def edit(p,a,b):
 s=get(p);assert a in s,(p,a[:100]);put(p,s.replace(a,b))
A=P+'bootstrap/preparation/activation/'
M=A+'managed_content/'
