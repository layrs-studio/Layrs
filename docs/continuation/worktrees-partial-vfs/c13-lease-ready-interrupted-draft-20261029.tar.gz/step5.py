from editlib import *
# Fix evaluation order: finish_writer consumes the bare handle.
for p in [A+'managed_content.rs']+[M+r for r in ['exact.rs','checkout.rs','protection.rs','ready.rs','publication.rs']]:
 s=get(p)
 for prefix in ['super::source_protection::','source_protection::']:
  s=s.replace('bare.finish_writer('+prefix+'rollback(bare.connection(), result), close)', 'let result = '+prefix+'rollback(bare.connection(), result);\n        bare.finish_writer(result, close)')
 put(p,s)
edit('crates/layrs-store-local/src/projection/shared/source_companion.rs','pub(super) struct ClassifiedSourceGroups','pub(in crate::projection) struct ClassifiedSourceGroups')
# `ManagedFile` ties its source-manifest borrow to the actual owner, not a new image lifetime.
edit(M+'companion.rs',"fn files(&self) -> &[ManagedFile<'a>]","fn files(&self) -> &[ManagedFile<'_>]")
# This entry has no already-retained operation gates.
edit(M+'companion.rs','        lease.with_source(cancel, |c, full, closure| {','        let _locks = held.family.locks(&held.artifacts.allocation.format.identity.worktree_id, true)?;\n        lease.with_source(cancel, |c, full, closure| {')
# Keep source pins without a mutable-image borrow; the proof rechecks the actual lease owner.
edit(M+'source_protection.rs','use super::super::managed_image::complete::VerifiedCompleteManagedImage;\n','')
# Whole-file checkout reads only the already authenticated pinned C CAS for complete routes.
q='crates/layrs-store-local/src/projection/shared/exact_content/published_cas.rs'
s=get(q);i=s.index('    /// No SQL and no byte read.')
s=s[:i]+'''    /// Copy one exact member from the retained, already verified immutable CAS
    /// handles. No source callback, SQL, hydration or alternate representation.
    pub(in crate::projection) fn copy_exact_file(
        &self, binding: &ExactBinding, required: &[FileManifest], manifest: &FileManifest,
        output: &mut dyn std::io::Write, cancel: &Cancellation,
    ) -> Result<()> {
        self.require(binding, required, cancel)?;
        if !required.iter().any(|m| m == manifest) { return Err(invalid("pinned CAS copy outside exact union")); }
        let mut full = blake3::Hasher::new(); full.update(b"layrs-file-v1\\0");
        let mut total = 0u64; let mut scratch = [0u8; 65536];
        for part in manifest.chunks() {
            let name = object_name(part.chunk_id().as_str())?;
            let pin = self.objects.get(&(false, name.to_owned())).ok_or_else(|| invalid("pinned CAS chunk absent"))?;
            let mut reader = pin.file(); reader.seek(SeekFrom::Start(0))?;
            let mut hash = blake3::Hasher::new(); hash.update(b"layrs-chunk-v1\\0");
            let mut remaining = part.byte_length();
            while remaining != 0 {
                cancel.check()?;
                let count = remaining.min(scratch.len() as u64) as usize;
                reader.read_exact(&mut scratch[..count])?;
                hash.update(&scratch[..count]); full.update(&scratch[..count]);
                output.write_all(&scratch[..count])?;
                remaining -= count as u64; total += count as u64;
            }
            if reader.read(&mut [0u8; 1])? != 0 || format!("blake3:{}", hash.finalize()) != part.chunk_id().as_str() {
                return Err(invalid("pinned CAS checkout chunk differs"));
            }
        }
        if total != manifest.byte_length() || format!("blake3:{}", full.finalize()) != manifest.file_id().as_str() {
            return Err(invalid("pinned CAS checkout FileId differs"));
        }
        self.require(binding, required, cancel)
    }

''' +s[i:];put(q,s)
s=get(M+'protection.rs');i=s.index('    pub(in crate::projection::provider::bootstrap::preparation::activation) fn require(')
s=s[:i]+'''    pub(super) fn copy_file(&self, lease: &ManagedImportLease<'_, '_, '_, '_>, manifest: &FileManifest, output: &mut dyn std::io::Write, cancel: &Cancellation) -> CauseResult<()> {
        self.require(lease, cancel)?;
        self.bytes.copy_exact_file(&self.binding, lease.manifests, manifest, output, cancel)
    }
''' +s[i:];put(M+'protection.rs',s)
s=get(M+'checkout.rs').replace('''                        self.image
                            .copy_exact_file(&file.path, &manifest, output, cancel)?;''','''                        if self.companion.is_some() {
                            protected.copy_file(self, &manifest, output, cancel)?;
                        } else {
                            self.image.copy_exact_file(&file.path, &manifest, output, cancel)?;
                        }''');put(M+'checkout.rs',s)
print('honest mutable-image/pin scopes and CAS-only complete checkout wired')
