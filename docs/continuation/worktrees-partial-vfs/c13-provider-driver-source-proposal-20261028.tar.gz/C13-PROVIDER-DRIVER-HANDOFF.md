# C13 provider driver tranche: blocked, source proposal only

This cumulative bundle does **not** implement the requested Provider8 to ordinary
managed conversion. It preserves all 17 input files and adds independent live
inherited-reader wiring and two source-defined recipes. The main repository was
read only. No compilation, runtime, readiness, C13 or L5 completion is claimed.

Base: `6b1f5632bd7f6092226d57e3c813033a82bcfc98`, branch
`feature/worktrees-partial-vfs`. Input manifest SHA256:
`62b21e4638d7d1aa42a51f67c13387b56eb9383285c5ff6403cf4771552844aa`.
Do not apply this as a Ready-capable conversion feature.

## Exact blocked edges

1. **Production caller and retained authority owner.** At this base,
   `managed_image::plan`, `managed_plan::derive`, `managed_journal::begin`,
   `managed_staging::stage` and `ManagedImportLease::open` have setup/session-test
   callers, with no production Provider8 conversion entry constructing their
   sequence. `ProviderActiveSession` exposes connect/disconnect/capture/recovery
   export/admission operations, but no managed conversion operation. The
   `TransitionObservationData::normalize` contract explicitly requires its
   caller to independently establish complete remote enumeration and authority
   before/after acquisition. `AuthorityObservationData` and declared coverage
   are DATA. The old plan also requires `fresh == source.initial()`; it cannot
   represent a genuine newly revoked/fresh whole-scope observation. No new
   authority capability was fabricated from these values.

   The existing remote enumeration/epoch checks are in
   `crates/layrs-client-core/src/native_scm/remote/projection_selection.rs`,
   `projection_rebase.rs` and `projection_clone.rs`, outside this assignment's
   provider/shared/ordinary-wiring ownership. They do not pass a retained
   conversion authority owner into this Store path. ROOT must coordinate that
   concrete transport/Store entry before the requested driver is safe to wire.

2. **Source ownership before receipt FK.** The current import exact binding and
   `managed_content/protection.rs` protection belong to the destination owner.
   `transition_sql/publication.rs::apply_source_publication` accepts an intent
   and receipt, with no closed companion owner or source-protection witness. It
   inserts the receipt directly. Merely calling `insert_new_rows` there would
   leave source mappings/retention unowned and the prefix accounting invalid.
   Source capture/catalog validation also interprets exact capture mappings;
   arbitrary recovery mappings cannot be silently appended to that contract.

3. **Ready and ordinary admission.** Active `managed_content/ready_data.rs`,
   `destination_ready/data.rs`, `destination_ready/autonomous.rs` and
   `destination_ready/historical.rs` still reject a new local companion plan.
   Their snapshot/image rules assume the source catalogue/checkout image rather
   than a freshly observed authorized checkout plus separate preserved image.
   Removing these guards without matching immutable union/accounting/claim and
   source/destination row checks would admit an incomplete state. All guards
   remain. Source-ready, destination-ready and positive SQLite connection close
   protocols were not bypassed or replaced.

## Implemented independent live paths

* Normal admitted ordinary open:
  `ProjectionStore::open -> format::access -> AdmittedPreflight::open ->
  admitted_ordinary::inspect -> read_admitted_import -> read_frozen_ready_rows
  -> VerifiedDestinationPrefix::inherited_companion_representations ->
  scoped::with_scope -> scoped::companion_representations`.
  The existing historical required-union builder now includes every exact
  representation persisted by inherited v2 headers. V1 representations still
  come from their strictly authenticated copied scalar mappings. No historical
  header, path, source version or sticky mapping is rewritten.
* Terminal destination reading:
  `read_managed_ready/read_ordinary_managed_ready -> read_private_ready_parts
  -> inherited_companion_representations -> inventory::require_union /
  require_ordinary_union`. Both require each inherited exact ManifestId in the
  independently supplied complete union. They do not collapse same-FileId
  alternates to its PK mapping, consult current paths, or grant byte authority.
* Live inherited scoped validation:
  `read_scoped_closure -> with_scope -> derive_companion_scope ->
  companions_v2::validate` checks the scalar file's exact header representation
  and independently requires the unchanged sticky FileId mapping to be another
  exact member of that header. It no longer conflates these two references.
* The scoped header aggregate probe now checks the largest header is at most
  65,536 bytes before loading any selected BLOB. The format/schema/reservation
  maximum is unchanged. Oversized input refuses; no truncation or repair occurs.

These paths consume **inherited** references. They do not make newly produced
local C13 companions admissible, create a produced state, expose an unresolved
work report, or prove stopProvider/open/capture/prepared Restore autonomy.

## U1-U7 disposition

| Item | Disposition and source pointers |
| --- | --- |
| U1 | Blocked: no production Provider8 caller/whole-scope authority owner. Prior `managed_image/complete.rs` and `derive_reconciled_data` remain DATA/physical adapters with test callers only. Immutable plan/reservation live rederivation is still legacy. |
| U2 | Blocked: complete installation from separately owned historical/fresh/native readers and protection at both owners are not wired. No quota enlargement or repair was introduced. |
| U3 | Blocked: prior `transition_reconcile/companions/sql.rs` is still transaction-only. Source AND destination row publication before receipt FK is not wired. Existing rollback/positive SQLite connection close/readback rules remain. |
| U4 | Partial independent work: inherited exact-reference union is wired into `destination_ready/{autonomous.rs,historical.rs,autonomous/inventory.rs}`. New local companion guards remain; Ready production is blocked. |
| U5 | Explicitly deferred: Ordinary9/10 OUTGOING adapters and all their strict legacy guards are unchanged. Inherited v1/v2 constructor uses in the cumulative proposal were inspected; existing `InheritedCompanionData` initializer uses `persisted.as_ref()` consistently. |
| U6 | Partial: inherited reading uses the normal open and terminal paths above. No produced C13 state or autonomous lifecycle/report completion is claimed. |
| U7 | Partial: one exact DATA header-boundary test and one negative native integration recipe authored/registered; neither compiled/run. Mixed successful live-driver/autonomy and independent source/destination receipt/claim tests are still missing. ROOT owns compilation, independent review, integration and runtime qualification. |

## Checks and integration constraints

See `handoff.json` and `manifest.sha256.json` for exact physical base/output
SHA256 values, HEAD blob hashes, patch hash and actual source-check results.
The patch is cumulative against the specified HEAD, with LF canonical text
hunks; physical hashes separately identify line-ending differences. All 17
input paths are retained. New changes are limited to provider source and the
owned convergence plan. No changes to `destination_ready/ordinary_tests.rs`,
fresh-checkout recipes, retained evidence/runners/fixtures or main sources.

No Cargo/build/test/SQL/native/network command was executed. Source recipes
contain future SQL/native operations, never run here. No fixture or database
was opened, no other process was queried or interfered with, no Git command or
mutation was performed, and no subagent was started. Self-review is source-only,
not an independent verification or a typecheck.
