from pathlib import Path
import shutil

MAIN = Path('D:/Layrs/layrs')
OUT = Path('D:/Layrs/tmp/c13-provider-driver-source-proposal/files')
P = 'crates/layrs-store-local/src/projection/provider/'

def read(path):
    dst = OUT / path
    if not dst.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(MAIN / path, dst)
    return dst.read_text(encoding='utf-8')

def write(path, value):
    dst = OUT / path
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(value, encoding='utf-8', newline='\n')

def replace(path, old, new, count=1):
    value = read(path)
    assert value.count(old) == count, (path, old[:100], value.count(old))
    write(path, value.replace(old, new))

# Inherited references come from their authenticated historical headers, not
# whichever representation happens to remain in the current checkout.
path = P + 'import_validation/destination_prefix.rs'
value = read(path)
anchor = '    /// Normalized logical columns of exactly the engaged incoming rowsets.\n'
assert value.count(anchor) == 1
method = '''    /// Exact immutable inherited companion references. These are historical
    /// DATA, never current checkout paths or proof of resident/protected CAS.
    /// Reinterpret the authenticated incoming scope before loading any payload.
    pub(in crate::projection::provider) fn inherited_companion_representations(
        &self,
        c: &Connection,
        cancel: Option<&Cancellation>,
    ) -> CauseResult<Vec<super::super::managed_admission::RequiredRepresentation>> {
        self.require_prefix_scope(c, cancel)?;
        scoped::with_scope(
            c,
            self.metadata.kind,
            &self.prefix,
            &scoped::ScopeView::from_metadata(&self.metadata),
            cancel,
            |_, closure| {
                if closure != &self.prefix.closure {
                    return Err(invalid("inherited companion SQL scope differs"));
                }
                scoped::companion_representations(c, &self.metadata.companion_ids, cancel)
            },
        )
    }

'''
write(path, value.replace(anchor, method + anchor))

path = P + 'import_validation/scoped.rs'
value = read(path)
value += '''
/// Called only after the canonical historical scope has been authenticated.
/// V1 has no alternate-reference payload; V2 retains its complete immutable
/// exact set even after no current image path refers to those representations.
pub(super) fn companion_representations(
    c: &Connection,
    ids: &BTreeSet<String>,
    cancel: Option<&Cancellation>,
) -> CauseResult<Vec<super::super::managed_admission::RequiredRepresentation>> {
    use super::super::{managed_admission::RequiredRepresentation, records::companion_v2::*};
    let mut exact = BTreeMap::new();
    let mut lengths = BTreeMap::new();
    let mut owners = BTreeMap::new();
    for id in ids {
        super::super::cancellation::check(cancel)?;
        // The preceding scope validation checked row cardinality, scalar
        // projections, canonical bytes, receipt/provenance and the aggregate.
        // Repeat the per-header bound in SQL before allocating its BLOB.
        let payload: Vec<u8> = c.query_row(
            "SELECT payload FROM projection_provider_companions WHERE id=?1 AND length(payload)<=65536",
            [id], |r| r.get(0),
        )?;
        let header = CompanionHeaderRecord::decode(&payload)?;
        if header.as_ref().digest()? != *id {
            return Err(invalid("inherited companion exact reference header differs"));
        }
        if let CompanionHeaderRecord::V2(header) = header {
            for row in header.preserved_representations {
                super::super::cancellation::check(cancel)?;
                let key = (row.file_id.clone(), row.manifest_id.clone());
                if exact.len() >= 100_000 && !exact.contains_key(&key) {
                    return Err(invalid("inherited companion exact union exceeds bound"));
                }
                if lengths.insert(row.file_id.clone(), row.bytes).is_some_and(|old| old != row.bytes)
                    || owners.insert(row.manifest_id.clone(), row.file_id.clone()).is_some_and(|old| old != row.file_id)
                    || exact.insert(key, row.bytes).is_some_and(|old| old != row.bytes)
                {
                    return Err(invalid("inherited companion exact representation conflict"));
                }
            }
        }
        // V1's scalar representations/preimages are already in the exact
        // authenticated copied FileId mappings. Do not synthesize v2 payloads.
    }
    Ok(exact.into_iter().map(|((file_id, manifest_id), bytes)| RequiredRepresentation {
        file_id, manifest_id, bytes,
    }).collect())
}
'''
write(path, value)

path = P + 'destination_ready/autonomous/inventory.rs'
value = read(path)
needle = '    expected: &ExpectedCheckout,\n    required: '
assert value.count(needle) == 2
value = value.replace(needle, '    expected: &ExpectedCheckout,\n    inherited: &[RequiredRepresentation],\n    required: ')
value = value.replace('    allowed.extend(copied.keys().cloned());', '    allowed.extend(copied.keys().cloned());\n    allowed.extend(inherited.iter().map(|row| row.file_id.clone()));')
needle = '    for file in expected.files() {\n        cancellation::check(cancel)?;\n        if exact.get('
assert value.count(needle) == 1
value = value.replace(needle, '''    for row in inherited {
        cancellation::check(cancel)?;
        if exact.get(&(&row.file_id, &row.manifest_id)) != Some(&row.bytes) {
            return Err(invalid("ordinary frozen inherited companion representation absent"));
        }
    }
''' + needle)
needle = '    if required.len() != union.len() {'
assert value.count(needle) == 1
value = value.replace(needle, '''    for row in inherited {
        cancellation::check(cancel)?;
        if union.insert((row.file_id.clone(), row.manifest_id.clone()), row.bytes)
            .is_some_and(|old| old != row.bytes)
        {
            return Err(invalid("autonomous Ready inherited companion length differs"));
        }
    }
''' + needle)
write(path, value)

path = P + 'destination_ready/autonomous.rs'
value = read(path)
needle = '    let copied = prefix.copied_content_mappings(c, cancel)?;'
assert value.count(needle) == 1
value = value.replace(needle, needle + '\n    let inherited = prefix.inherited_companion_representations(c, cancel)?;')
value = value.replace('                &expected,\n                &family.required,', '                &expected,\n                &inherited,\n                &family.required,')
value = value.replace('                &expected,\n                &rows,', '                &expected,\n                &inherited,\n                &rows,')
write(path, value)

path = P + 'destination_ready/historical.rs'
value = read(path)
needle = '    let copied = prefix.copied_content_mappings(c, cancel)?;'
assert value.count(needle) == 1
value = value.replace(needle, needle + '\n    let inherited = prefix.inherited_companion_representations(c, cancel)?;')
value = value.replace('required(prefix.source()?, &copied, &expected, cancel)?', 'required(prefix.source()?, &copied, &expected, &inherited, cancel)?')
value = value.replace('                &expected,\n                &rows,', '                &expected,\n                &inherited,\n                &rows,')
needle = '    expected: &ExpectedCheckout,\n    cancel: Option<&Cancellation>,\n) -> Result<Vec<RequiredRepresentation>>'
assert value.count(needle) == 1
value = value.replace(needle, '    expected: &ExpectedCheckout,\n    inherited: &[RequiredRepresentation],\n    cancel: Option<&Cancellation>,\n) -> Result<Vec<RequiredRepresentation>>')
needle = '    for file in expected.files() {\n        add(&file.file_id, &file.manifest_id, file.bytes)?;\n    }'
assert value.count(needle) == 1
value = value.replace(needle, needle + '\n    for row in inherited {\n        add(&row.file_id, &row.manifest_id, row.bytes)?;\n    }')
write(path, value)

# Reuse the accepted DATA API's exact immutable representation references;
# the sticky FileId PK is independently checked, not overwritten to an alternate.
path = P + 'import_validation/scoped/companions_v2.rs'
replace(path, '        require_content_mapping(c, &file, Some(&manifest), Some(bytes))?;', '''        header.require_representation(&record.file_id, &record.manifest_id, bytes)?;
        require_sticky_representation(c, header, &record.file_id, Some(bytes))?;''')
replace(path, '    let mut preimages = BTreeSet::new();', '''    let mut preimages = BTreeSet::new();
    // Include the file itself: its historical FileId mapping may differ from
    // this scalar's exact retained alternate representation.
    preimages.extend(files.iter().map(|row| &row.file_id));''')
value = read(path)
value += '''
fn require_sticky_representation(
    c: &Connection,
    header: &CompanionHeaderV2,
    file: &FileId,
    expected_bytes: Option<u64>,
) -> CauseResult<()> {
    require_content_mapping(c, file.as_str(), None, expected_bytes)?;
    let (manifest, bytes): (String, u64) = c.query_row(
        "SELECT manifest_id,bytes FROM projection_content WHERE file_id=?1",
        [file.as_str()], |r| Ok((r.get(0)?, r.get(1)?)),
    )?;
    let manifest = FileManifestId::parse(&manifest).map_err(|e| invalid(e.to_string()))?;
    header.require_representation(file, &manifest, bytes)?;
    Ok(())
}
'''
write(path, value)

# Explicitly bounded DATA recipe: no production cap increase or truncation.
path = P + 'transition_reconcile/tests/companions.rs'
value = read(path)
value += '''
#[test]
fn c13_v2_header_exact_64k_boundary_refuses_next_byte_without_mutation() {
    let data = Data::new(true);
    let observed = data.observation(true);
    let readme = p("README.md");
    let owned = derive(
        &data, &observed,
        &[ImageFileData { path: &readme, manifest: &data.readme, executable: Some(false) }],
        &[p("new.txt")], &[data.readme.clone(), data.a.clone()],
    ).unwrap();
    let original = owned.header().unwrap().encode().unwrap();
    let mut header = CompanionHeaderV2::decode(&original).unwrap();
    // A valid bounded header may describe more than one durable intent. Use
    // real fixed-size identities/digests and distinct paths; never padding in
    // an unknown JSON field that the strict decoder would already reject.
    for n in 0..300 {
        header.intents.push(CompanionIntentV2::SatisfiedDeletion {
            path: p(&format!("z-boundary-{n:04}.txt")),
            source_effective_base: Some(CompanionBaseV2 {
                file_id: data.a.file_id().clone(), executable: false,
            }),
            accepted: None,
            destination_generation: observed.binding().generation,
            destination_snapshot_digest: observed.binding().snapshot_digest.clone(),
        });
        let size = layrs_core::scm::canonical_json(&header).unwrap().len();
        if size > CompanionHeaderV2::MAX_BYTES - 4096 {
            break;
        }
    }
    let size = layrs_core::scm::canonical_json(&header).unwrap().len();
    assert!(size <= CompanionHeaderV2::MAX_BYTES);
    let last = header.intents.last_mut().unwrap();
    let CompanionIntentV2::SatisfiedDeletion { path, .. } = last else { unreachable!() };
    let prefix = path.as_str().to_owned();
    *path = p(&format!("{prefix}{}", "x".repeat(CompanionHeaderV2::MAX_BYTES - size)));
    let exact = header.encode().unwrap();
    assert_eq!(exact.len(), 64 * 1024);
    assert_eq!(CompanionHeaderRecord::decode(&exact).unwrap().as_ref().encode().unwrap(), exact);
    let CompanionIntentV2::SatisfiedDeletion { path, .. } = header.intents.last_mut().unwrap() else { unreachable!() };
    *path = p(&format!("{}x", path.as_str()));
    assert_eq!(layrs_core::scm::canonical_json(&header).unwrap().len(), 64 * 1024 + 1);
    assert!(header.encode().is_err());
    assert!(CompanionHeaderRecord::decode(&layrs_core::scm::canonical_json(&header).unwrap()).is_err());
    assert_eq!(owned.header().unwrap().encode().unwrap(), original);
    assert_eq!(data.prefix.encode().unwrap(), data.input().prefix.encode().unwrap());
}
'''
write(path, value)

print('Extended cumulative changed-file bundle only; activation and outgoing legacy guards retained.')
