from pathlib import Path
import datetime
import difflib
import hashlib
import json
import re
import zlib

ROOT = Path('D:/Layrs/tmp/c13-provider-driver-source-proposal')
MAIN = Path('D:/Layrs/layrs')
OLD = Path('D:/Layrs/tmp/c13-companions-source-proposal')
HEAD = '6b1f5632bd7f6092226d57e3c813033a82bcfc98'
INPUT_HASH = '62b21e4638d7d1aa42a51f67c13387b56eb9383285c5ff6403cf4771552844aa'

def sha(value):
    return hashlib.sha256(value).hexdigest()

def canonical(value):
    return value.decode('utf-8').replace('\r\n', '\n')

def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')

def object_data(oid):
    # Source-only loose Git object reading. No git process/index/write is used.
    raw = zlib.decompress((MAIN / '.git/objects' / oid[:2] / oid[2:]).read_bytes())
    header, payload = raw.split(b'\0', 1)
    kind, size = header.split(b' ')
    assert int(size) == len(payload)
    assert hashlib.sha1(raw).hexdigest() == oid
    return kind, payload

def head_blob(path):
    kind, commit = object_data(HEAD)
    assert kind == b'commit'
    oid = commit.split(b'\n', 1)[0].decode().removeprefix('tree ')
    parts = path.split('/')
    for index, part in enumerate(parts):
        kind, tree = object_data(oid)
        assert kind == b'tree'
        cursor = 0
        found = None
        while cursor < len(tree):
            end = tree.index(b'\0', cursor)
            mode_name = tree[cursor:end]
            name = mode_name.split(b' ', 1)[1].decode('utf-8')
            candidate = tree[end+1:end+21].hex()
            cursor = end + 21
            if name == part:
                found = candidate
                break
        if found is None:
            return None, None
        oid = found
        if index == len(parts)-1:
            kind, blob = object_data(oid)
            assert kind == b'blob'
            return oid, blob
    raise AssertionError(path)

def reconstruct(base, patch):
    original = base.splitlines(keepends=True)
    output = []
    cursor = 0
    active = False
    for line in patch:
        if line.startswith('@@ '):
            start = int(re.match(r'@@ -(\d+)', line).group(1))
            position = max(0, start - 1)
            assert position >= cursor
            output.extend(original[cursor:position])
            cursor = position
            active = True
        elif active and line[0] in ' +-':
            if line[0] in ' -':
                assert original[cursor] == line[1:]
                cursor += 1
            if line[0] in ' +':
                output.append(line[1:])
    output.extend(original[cursor:])
    return ''.join(output)

assert sha((OLD / 'manifest.sha256.json').read_bytes()) == INPUT_HASH
old = json.loads((OLD / 'manifest.sha256.json').read_text(encoding='utf-8-sig'))
old_by_path = {row['path']: row for row in old['files']}
assert (MAIN / '.git/HEAD').read_text().strip() == 'ref: refs/heads/feature/worktrees-partial-vfs'
assert (MAIN / '.git/refs/heads/feature/worktrees-partial-vfs').read_text().strip() == HEAD
for row in old['files']:
    assert sha((OLD / row['output']).read_bytes()) == row['output_sha256']

rows = []
patches = []
source_hashes = {}
for output in sorted((ROOT / 'files').rglob('*')):
    if not output.is_file():
        continue
    path = output.relative_to(ROOT / 'files').as_posix()
    assert path.startswith('crates/layrs-store-local/src/projection/provider/') or path == 'docs/plans/worktrees-partial-vfs-convergence.md', path
    assert path != 'crates/layrs-store-local/src/projection/provider/destination_ready/ordinary_tests.rs'
    assert '/fixtures/' not in path and '/fixture.' not in path
    oid, blob = head_blob(path)
    physical = (MAIN / path).read_bytes() if (MAIN / path).exists() else None
    assert (physical is None) == (blob is None), path
    if physical is not None:
        assert canonical(physical) == canonical(blob), ('concurrent main change outside HEAD', path)
        source_hashes[path] = sha(physical)
    if path in old_by_path:
        assert (None if physical is None else sha(physical)) == old_by_path[path]['base_sha256'], ('input source changed', path)
    contents = output.read_bytes()
    before = '' if blob is None else canonical(blob)
    after = canonical(contents)
    assert after.endswith('\n'), path
    if output.suffix == '.rs':
        assert not re.search(r'\bTODO\b|todo!\s*\(|unimplemented!\s*\(', after), path
    assert not any(line.rstrip() != line for line in after.splitlines()), path
    diff = list(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True), fromfile='/dev/null' if blob is None else 'a/' + path, tofile='b/' + path, n=3))
    assert reconstruct(before, diff) == after, path
    if diff:
        patches.append('diff --git a/' + path + ' b/' + path + '\n' + ''.join(diff))
    rows.append({
        'path': path, 'kind': 'new' if blob is None else 'modified',
        'base_sha256': None if physical is None else sha(physical),
        'base_bytes': None if physical is None else len(physical),
        'base_head_git_blob': oid, 'base_head_blob_sha256': None if blob is None else sha(blob),
        'input_bundle_output_sha256': old_by_path.get(path, {}).get('output_sha256'),
        'output': output.relative_to(ROOT).as_posix(), 'output_sha256': sha(contents), 'output_bytes': len(contents),
        'added_lines': sum(line.startswith('+') and not line.startswith('+++') for line in diff),
        'removed_lines': sum(line.startswith('-') and not line.startswith('---') for line in diff),
    })
assert set(old_by_path).issubset({row['path'] for row in rows})
patch = ''.join(patches).encode('utf-8')
(ROOT / 'proposal.patch').write_bytes(patch)

provider = 'crates/layrs-store-local/src/projection/provider/'
def proposed(path):
    output = ROOT / 'files' / (provider + path)
    return output.read_text(encoding='utf-8') if output.exists() else (MAIN / (provider + path)).read_text(encoding='utf-8')

checks = {
    'input_manifest_sha256': 'passed', 'all_17_input_files_retained': 'passed',
    'base_head_binding': 'passed; loose commit/tree/blob source reading; no Git command',
    'main_owned_source_hash_recheck': 'passed', 'input_bundle_final_hash_recheck': 'passed',
    'hunk_reconstruction': f'passed independently in memory for {len(rows)} files',
    'ownership_paths': 'passed; provider and single owned convergence plan only',
    'rustfmt': {'status': 'passed', 'files': sum(row['path'].endswith('.rs') for row in rows), 'command': 'rustfmt --edition 2024 --config skip_children=true,style_edition=2021 <22 proposed Rust files>'},
    'rustfmt_check': {'status': 'passed', 'files': sum(row['path'].endswith('.rs') for row in rows), 'command': 'rustfmt --check --edition 2024 --config skip_children=true,style_edition=2021 <22 proposed Rust files>'},
    'no_rust_placeholders': 'passed', 'trailing_whitespace': 'passed',
    'constructor_consistency': 'source inspected; InheritedCompanionData initializer passes persisted.as_ref(); no v1 decoder used for a v2 header',
    'live_reader_call_sites': 'historical.rs and autonomous.rs call inherited_companion_representations; all three union call sites supply inherited references',
    'legacy_local_companion_and_outgoing_guards': 'retained',
    'cargo_build_typecheck_tests_sql_native_network_fixtures': 'NOT RUN',
    'independent_review': 'NOT PERFORMED; source self-review only',
}
for file in ['destination_ready/data.rs', 'destination_ready/autonomous.rs', 'destination_ready/historical.rs', 'bootstrap/preparation/activation/managed_content/ready_data.rs', 'managed_export/ready_data.rs']:
    assert 'companion_id.is_some()' in proposed(file), file
for file in ['managed_export/budget.rs', 'managed_export/ready_data.rs']:
    assert (ROOT / 'files' / (provider + file)).exists() is False
for path, digest in source_hashes.items():
    assert sha((MAIN / path).read_bytes()) == digest, path
for row in old['files']:
    assert sha((OLD / row['output']).read_bytes()) == row['output_sha256']
assert (MAIN / '.git/refs/heads/feature/worktrees-partial-vfs').read_text().strip() == HEAD

patch_record = {'path': 'proposal.patch', 'sha256': sha(patch), 'bytes': len(patch), 'line_endings': 'LF canonical text hunks against exact HEAD; physical byte hashes recorded separately'}
artifacts = []
for name in ['C13-PROVIDER-DRIVER-HANDOFF.md', 'ROOT-INTEGRATION-RECIPES.md']:
    raw = (ROOT / name).read_bytes()
    artifacts.append({'path': name, 'sha256': sha(raw), 'bytes': len(raw)})
manifest = {
    'schema': 'layrs.c13-provider-driver-source-proposal-manifest.v1',
    'source_root': str(MAIN), 'source_head': HEAD, 'source_branch': 'feature/worktrees-partial-vfs',
    'proposal_root': str(ROOT), 'checkout': False,
    'input_bundle': {'root': str(OLD), 'manifest_sha256': INPUT_HASH, 'files': 17},
    'patch': patch_record, 'files': rows, 'artifacts': artifacts,
}
dump(ROOT / 'manifest.sha256.json', manifest)
handoff = {
    'schema': 'layrs.c13-provider-driver-source-proposal-handoff.v1',
    'status': 'BLOCKED_PARTIAL_SOURCE_PROPOSAL_NOT_REQUESTED_DRIVER_NOT_C13_COMPLETE',
    'source_head': HEAD, 'main_source_modified_by_agent': False, 'bundle_is_checkout': False,
    'role': 'implementation sub-agent; GPT-6.1-Sol/high; no delegation',
    'manifest': {'path': 'manifest.sha256.json', 'sha256': sha((ROOT / 'manifest.sha256.json').read_bytes())},
    'patch': patch_record, 'files': rows, 'checks': checks,
    'implemented': [
        'Live historical/admitted ordinary and autonomous terminal readers include every inherited v2 exact representation in their required union; v1 continues through strict copied mappings.',
        'Live scoped v2 file validation separates exact scalar representation from immutable sticky historical FileId mapping and requires both in the header.',
        'Per-header 64KiB SQL preflight precedes header BLOB loading; no schema/cap/reservation increase.',
        'One new exact 64KiB/64KiB+1 DATA boundary test and one registered negative native allocation/copier/Staging/checkpoint retention recipe; both uncompiled/unrun.',
        'Original 17 proposal paths retained cumulatively; all local companion Ready/outgoing guards remain.',
    ],
    'real_caller_routes': [
        'ProjectionStore::open -> format::access -> AdmittedPreflight::open -> admitted_ordinary::inspect -> read_admitted_import -> read_frozen_ready_rows -> inherited_companion_representations -> scoped::with_scope -> companion_representations',
        'read_managed_ready/read_ordinary_managed_ready -> read_private_ready_parts -> inherited_companion_representations -> inventory::{require_union,require_ordinary_union}',
        'read_scoped_closure -> with_scope -> derive_companion_scope -> companions_v2::validate',
    ],
    'requested_provider_driver_real_caller_route': None,
    'exact_blockers': [
        {'edge': 'production Provider8 managed entry -> real retained whole-scope authority/epoch owner -> complete checkpoint/closed owner', 'evidence': 'Provider8 image/plan/Staging/lease setup has only test callers at HEAD; transition_observation normalize explicitly carries declared DATA. Existing remote epoch/enumeration adapters are outside provider/shared ownership and expose no retained conversion authority owner.', 'pointer': 'C13-PROVIDER-DRIVER-HANDOFF.md#exact-blocked-edges'},
        {'edge': 'closed owner -> source-owned mappings/CAS/metadata/retention claims -> source AND destination rows -> receipt FK', 'evidence': 'Existing protection binds destination; source publication directly inserts receipt without companion/protection inputs. Prior companion SQL primitives have no live publication caller.'},
        {'edge': 'fresh authorized checkout plus preserved complete image -> strict Ready/admission -> ordinary autonomous lifecycle', 'evidence': 'Local companion guards and legacy source snapshot/image assumptions remain. They cannot be safely removed independently of U1-U3.'},
    ],
    'U1_U7': [
        {'id': 'U1', 'status': 'blocked', 'pointer': 'bootstrap/preparation/activation/{managed_plan.rs,managed_image/complete.rs}; no production authority-owning conversion caller'},
        {'id': 'U2', 'status': 'blocked', 'pointer': 'bootstrap/preparation/activation/managed_content/{exact.rs,protection.rs}; complete independent readers and both owners not wired'},
        {'id': 'U3', 'status': 'blocked', 'pointer': 'transition_sql/publication.rs and transition_reconcile/companions/sql.rs; no source/destination companion publication integration'},
        {'id': 'U4', 'status': 'partial inherited live readers only', 'pointer': 'destination_ready/{autonomous.rs,historical.rs,autonomous/inventory.rs}; local companion Ready guards retained'},
        {'id': 'U5', 'status': 'explicitly deferred; outgoing strict legacy guards preserved', 'pointer': 'managed_export unchanged; inherited v1/v2 constructor consistency inspected'},
        {'id': 'U6', 'status': 'partial inherited normal-open/terminal reading only', 'pointer': 'import_validation/{destination_prefix.rs,scoped.rs,scoped/companions_v2.rs}; no produced autonomous state/report'},
        {'id': 'U7', 'status': 'partial source recipes; runtime/integration/independent review pending', 'pointer': 'ROOT-INTEGRATION-RECIPES.md; full mixed driver/autonomy/source-destination publication test not authored because required production entry is absent'},
    ],
    'bounded_tranche': {'header_bytes': 65536, 'oversized_behavior': 'early refusal; original source DATA unchanged; no truncation, schema redesign, automatic larger reservation, or 100k-companion scalability claim'},
    'instructions_for_ROOT': 'Review the blocked partial status first. This changed-file bundle is not a checkout; never run Cargo here. Require exact base hashes/absence of new paths, preserve all concurrent work, integrate/review/typecheck/test only under ROOT ownership. Do not activate as a complete C13 conversion feature.',
    'handoff_document': 'C13-PROVIDER-DRIVER-HANDOFF.md',
}
dump(ROOT / 'handoff.json', handoff)
print(json.dumps({'files': len(rows), 'rust_files': checks['rustfmt']['files'], 'patch_sha256': patch_record['sha256'], 'manifest_sha256': handoff['manifest']['sha256'], 'status': handoff['status']}, indent=2))
