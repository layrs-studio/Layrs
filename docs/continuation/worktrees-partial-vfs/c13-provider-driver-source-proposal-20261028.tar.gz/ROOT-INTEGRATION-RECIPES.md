# Additional C13 recipes — proposed, uncompiled, unexecuted

The prior bundle's R1-R5 remain proposals. These additions do not alter any
existing fresh-checkout recipe, retained runner or fixture. Every bound below
is proposed and unmeasured. This bundle cannot produce a C13 Ready destination.

## Authored source recipes

1. `transition_reconcile::tests::companions::c13_v2_header_exact_64k_boundary_refuses_next_byte_without_mutation`
   constructs a structurally valid 65,536-byte header with distinct intent
   paths and valid component lengths. Exact encode/decode must roundtrip. The
   same header at 65,537 bytes must refuse encode and dispatch decode; original
   owner/header/source-prefix bytes must remain unchanged. Proposed bounds:
   at most 300 added intents, 4,096-byte intent path, 255-scalar components,
   65,536-byte accepted header. This is DATA-only and establishes no authority,
   SQL publication, quota or Ready evidence. It explicitly exercises the bounded
   tranche; 100k-companion support is not claimed.
2. `bootstrap::preparation::activation::session::c13_provider_preservation_tests::c13_unknown_creation_preserved_complete_reader_and_legacy_staging_stays_unready`
   reuses `with_content_planned`, `bound_holder`, real `register_and_copy`,
   real export checkpoints, and `managed_staging::stage`. An unknown real file
   added after planning must cause staging refusal before any writer opens.
   The complete adapter must subsequently enumerate/copy/rehash its exact
   contents. Source/destination/family database witnesses and the unknown file's
   inode/size/hash witness must remain identical; destination must remain
   Copying with no new transaction receipt or Ready/Published state. Proposed
   bound: existing audited child 240 seconds, two native files and existing tiny
   source history. No measured time/IO/bytes bound is asserted. This tests the
   real legacy refusal boundary and complete physical reader; it is explicitly
   **not** a successful new companion driver test or autonomous lifecycle test.

## Required future integrated driver fixture (not authored as a fake test)

ROOT should implement
`c13_provider8_managed_mixed_companions_autonomous_capture_prepared_restore`
against the actual future production entry, once the authority owner and
source-protection edges in `C13-PROVIDER-DRIVER-HANDOFF.md` exist. Do not replace
them with declarations or pass `source.initial()` as fresh authority.

Before connecting the fresh Provider fixture, establish selected paths with
genuine source observations for an uncaptured writable edit, writable explicit
absence/create, writable present/delete, readonly present/edit, accepted writable
deletion subsequently revoked by the fresh whole-scope observation, and a
previously accepted edit subsequently revoked. Add a truly unknown real file
without adding any absence/grant to either observation. Use two exact manifests
of one FileId and an inherited v1 artifact plus inherited v2 alternate reference
whose live path no longer exists. Every base/historical/fresh reader and its
content/protection owner must be real, with fresh epoch checks around acquisition
and every effect. Proposed tiny bounds: <=12 paths, <=16 exact manifests, <=8
captures, <=64KiB of content, <=64KiB per new companion header, audited child
240 seconds; all unmeasured. ROOT should adjust only from measured evidence.

Call the production driver once, then exact no-writer replay. Assert:

* Checkout and genuine destination Capture contain exactly the authorized
  edit/create/delete relative to the fresh snapshot; all other paths remain
  excluded. No fabricated None-to-None change or altered original capture.
* Unknown/readonly/revoked bytes and revoked accepted-deletion preimage/intent
  survive outside checkout under an explicit unresolved receipt. Every original
  source inode/content/history/receipt witness survives unchanged.
* Independently read source AND destination headers/scalars/mappings/receipts,
  and source AND destination CAS/metadata/retention claims. Require exact
  original sticky mappings and every alternate ManifestId. The pre-effect
  reservation must fund the whole finite union and both metadata sides exactly;
  compare family root/union/accounting independently, with no repair/enlargement.
* Release all original holders and stop Provider. Normal ordinary open/read,
  a further authorized capture and the existing supported prepared
  RestoreOrdinary route must work offline, preserving unresolved work and the
  exact old provenance. No Provider callback or old checkout is available.
* Deterministically refuse preservation before source/destination receipt FK
  publication, and inject acknowledgement refusal after an actual successful
  SQLite connection close. C stays unready on failure; no filesystem/SQL
  readback follows an unacknowledged SQLite connection close. Replay validates
  source/destination independently and retains all holders until positive close.

This integrated successful recipe, positive companion replay, source/destination
row/claim coverage, genuine authority-change failure and provider-produced
autonomy remain outstanding. The two authored recipes do not satisfy them.
