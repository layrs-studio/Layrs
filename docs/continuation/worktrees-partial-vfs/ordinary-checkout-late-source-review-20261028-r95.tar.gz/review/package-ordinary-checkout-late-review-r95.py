"""Archive the original reviewed snapshot, never substituted by live corrections."""
from pathlib import Path
import datetime, hashlib, io, json, tarfile
root, tmp = Path('D:/Layrs/layrs'), Path('D:/Layrs/tmp')
prefix = 'provider-ordinary-checkout-late'
manifest_path = tmp / f'{prefix}-review-r95-inputs.json'
report_path = tmp / f'{prefix}-critical-review-r95.json'
manifest, report = [json.loads(p.read_bytes()) for p in [manifest_path, report_path]]
assert [f['id'] for f in report['findings']] == ['R95-F1','R95-F2']
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
assert pin(manifest_path)['sha256'] == '4bf344e1f1c40d8c17eb220f5d1259082c7057c5218d18e4512be397a2d78cdc'
entries = {}
for e in manifest['files']:
    p = Path(manifest['snapshot']) / e['path']
    assert pin(p) == dict(bytes=e['bytes'], sha256=e['sha256'])
    entries['source/' + e['path']] = p
for e in report['pins']['additional_sources']['ending']:
    p = root / e['path']
    assert pin(p) == {k:e[k] for k in ['bytes','sha256']}
    entries['source/' + e['path']] = p
for p in [manifest_path, report_path, tmp / 'ordinary-checkout-late-recipes-proposal/late-recipes.patch', tmp / 'prepare-ordinary-checkout-late-review-r95.py', tmp / 'ordinary-checkout-late-recipes-proposal/base.sha256.json', Path(__file__)]:
    entries['review/' + p.name] = p
record = dict(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Original SOURCE ONLY critical review r95 of five off-worktree native recipes, with R95-F1/F2 test oracle findings. Later ROOT correction separate; no compilation/runtime qualification.',
    files=[dict(path=n, **pin(p)) for n,p in sorted(entries.items())])
dest = root / 'docs/continuation/worktrees-partial-vfs'
archive = dest / 'ordinary-checkout-late-source-review-20261028-r95.tar.gz'
inventory = dest / 'ordinary-checkout-late-source-review-inventory-20261028-r95.json'
assert not archive.exists() and not inventory.exists()
data = json.dumps(record,indent=2).encode('utf-8')
with tarfile.open(archive,'x:gz') as tar:
    info = tarfile.TarInfo('manifest.json'); info.size = len(data)
    tar.addfile(info,io.BytesIO(data))
    for n,p in sorted(entries.items()): tar.add(p,arcname=n,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers()) == len(entries)+1
    for e in record['files']:
        data = tar.extractfile(e['path']).read()
        assert len(data) == e['bytes'] and hashlib.sha256(data).hexdigest() == e['sha256']
record['archive'] = dict(path=archive.name,**pin(archive))
with inventory.open('x',encoding='utf-8') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(archive=str(archive),files=len(entries)+1,**pin(archive))))
