from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
root,tmp=Path('D:/Layrs/layrs'),Path('D:/Layrs/tmp')
proposal=tmp/'ordinary-checkout-late-recipes-proposal'
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
meta=json.loads((proposal/'base.sha256.json').read_bytes())
assert pin(Path(meta['base_path']))['sha256']==meta['base_sha256']
assert pin(proposal/meta['candidate'])['sha256']==meta['candidate_sha256']
assert pin(proposal/meta['patch'])['sha256']==meta['patch_sha256']
previous=json.loads((tmp/'provider-ordinary-fresh-checkout-root-correction-r93.json').read_bytes())
review=json.loads((tmp/'provider-ordinary-fresh-checkout-critical-review-r92.json').read_bytes())
head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()
assert head==previous['head']
paths={e['path']:e for e in previous['files']}
paths.update({e['path']:e for e in review['inputs']['supplementary_sources']})
snapshot=tmp/'provider-ordinary-checkout-late-review-r95-source'
snapshot.mkdir(exist_ok=False)
changed=Path(meta['base_path']).relative_to(root).as_posix()
files=[]
for rel,e in sorted(paths.items()):
    assert pin(root/rel)=={k:e[k] for k in ['bytes','sha256']},rel
    source=proposal/meta['candidate'] if rel==changed else root/rel
    target=snapshot/rel;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    files.append(dict(path=rel,inputPath=str(source),liveBase=pin(root/rel),**pin(target),changed=rel==changed))
manifest=dict(head=head,branch='feature/worktrees-partial-vfs',snapshot=str(snapshot),
    recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=files,changed=[changed],
    proposal=dict(path=str(proposal),**meta),patch=dict(path=str(proposal/meta['patch']),**pin(proposal/meta['patch'])),
    scope='SOURCE ONLY review of five appended native recipes in an OFF-WORKTREE candidate. Production code unchanged from r92+r93. Verify authentic cutpoints, exact failure phase/primary cause, read/writer controls, handle/inode/byte witnesses, fresh recovery and no adoption/cleanup in allocation gaps.',
    execution='ROOT75810 retained r91 running; no build/test/SQL/native/fixture operations by reviewer. ROOT may finish r91 then compile/release unchanged live r93 baseline while review runs. Candidate integration waits for retained r94 binary. Docs/logs/target may change; HEAD and selected source inputs remain frozen.',
    limitations=['No runtime qualification, no true crash/OS close/owner loss/mid-copy/partial nonempty TEMP scenario.',
        'Single current flat file; numbers4/5/6 and2/3 valid only for exact setup; SQL/physical witnesses must establish cut.',
        'No product fixes or permission changes. Allocation gaps intentionally refuse and preserve; successful orphan recovery is not provided.'])
path=tmp/'provider-ordinary-checkout-late-review-r95-inputs.json'
with path.open('x',encoding='utf-8') as f:json.dump(manifest,f,indent=2)
print(json.dumps(dict(manifest=str(path),**pin(path),files=len(files),patch=manifest['patch'])))
