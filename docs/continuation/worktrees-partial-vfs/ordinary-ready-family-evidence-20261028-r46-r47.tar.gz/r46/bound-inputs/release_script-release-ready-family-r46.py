from pathlib import Path
import datetime, hashlib, json, subprocess

base = Path('D:/Layrs/layrs')
tmp = Path('D:/Layrs/tmp')
out = base / '.layrs-local/validation/provider-family-publication-20261027-r46'
read = lambda p: json.loads(p.read_bytes())
pin = lambda p: dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
host = read(out / 'host-disposition.json')
prior = read(base / '.layrs-local/validation/provider-family-publication-20261027-r44/ordinary-ready-source-release.json')
family_manifest = read(tmp / 'provider-ordinary-family-ready-review-inputs-r45.json')
review_path = base / 'docs/continuation/worktrees-partial-vfs/ordinary-family-ready-source-review-20261028-r45.json'
review = read(review_path)
assert not review['findings']
corrections = read(out / 'correction-review-inputs.json')
changed = {Path(e['path']).relative_to(base).as_posix() for e in corrections['files']}
assert len(changed) == 2
previous_source = base / '.layrs-local/validation/provider-family-publication-20261027-r44/source'
allowed = {e['path'] for e in family_manifest['files']} | changed
for entry in host['sourceClosure']:
    relative = Path(entry['path']).relative_to(base)
    previous = previous_source / relative
    current = out / 'source' / relative
    if relative.as_posix() not in allowed:
        assert previous.exists() and previous.read_bytes().replace(b'\r\n', b'\n') == current.read_bytes().replace(b'\r\n', b'\n'), str(relative)
for entry in family_manifest['files']:
    if entry['path'] not in changed:
        assert pin(base / entry['path'])['sha256'] == entry['sha256'], entry['path']
for entry in host['sourceClosure']:
    live = Path(entry['path'])
    saved = out / 'source' / live.relative_to(base)
    assert pin(live)['sha256'] == pin(saved)['sha256'] == entry['sha256'], live
for entry in [host['executable'], host['pdb'], *host['startupSources'], *host['unchangedRustAndSqliteInputs'], *host['currentNativeInputs']]:
    assert pin(Path(entry['path'])) == entry, entry['path']
paths = sorted({e['path'] for e in prior['reviewed_paths']} | {e['path'] for e in family_manifest['files']})
reviewed = [dict(path=p, sha256=pin(out / 'source' / p)['sha256']) for p in paths]
recipes = read(out / 'proposed-recipes.json')['recipes']
runner = tmp / 'provider-ordinary-ready-family-run-r46.py'
script = (tmp / 'provider-ordinary-ready-run.py').read_text(encoding='utf-8')
script = script.replace("assert revision in [f'r{n}' for n in range(42, 50)]", "assert revision == 'r46'")
script = script.replace('ordinary-ready-source-release.json', 'ordinary-ready-family-source-release.json')
script = script.replace('layrs-provider-ordinary-ready-', 'layrs-provider-ordinary-ready-family-')
script = script.replace('ordinary-ready-results.json', 'ordinary-ready-family-results.json')
start = script.index("              scope='")
end = script.index(", results=[])", start)
script = script[:start] + "              scope='Private Ready ACK/replay and family Ready Updated/readback plus ACK/replay on separate fresh fixtures. B remains Staging; C8 remains unadmitted. No B publication/C9/autonomy/crash/owner-loss qualification.'" + script[end:]
with runner.open('x', encoding='utf-8') as f:
    f.write(script)
bindings = dict(runner=pin(runner), manifest=pin(out / 'correction-review-inputs.json'),
                correction_diff=pin(out / 'test-corrections.diff'), family_review=pin(review_path),
                family_manifest=pin(tmp / 'provider-ordinary-family-ready-review-inputs-r45.json'),
                build=pin(tmp / 'ordinary-ready-family-build-r46.log'),
                check=pin(tmp / 'ordinary-ready-family-check-r46.log'),
                host_audit=pin(tmp / 'provider-family-publication-host-audit-r46.py'),
                release_script=pin(Path(__file__)))
for label in ['build','check']:
    raw=Path(bindings[label]['path']).read_bytes()
    text=raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert 'Finished `' in text, label
release = dict(decision='released', revision='r46',
               recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               baseline_head=corrections['head'],
               scope='Integrated private C Ready and family C Ready; no B Ready/Published or C9 admission.',
               reviewer='ROOT integration and narrow test-correction self-review; unchanged product candidate retains independent r43/r45 source reviews',
               runtime_executed_by_reviewer=False,
               correction='Explicit three-manifest fixture witness retains full-row equality; separate fresh native Updated/readback recipe resolves r45 E1 coverage gap in source, pending execution.',
               artifact_audit=dict(host=pin(out / 'host-disposition.json'), executable=host['executable'],pdb=host['pdb'],codeView=host['codeView']),
               input_bindings=bindings, reviewed_paths=reviewed, recipes=recipes,
               limitations=['Native runtime and proposed timing bounds unproven until these recipes finish.', 'No actual OS close failure, crash, owner-loss, positive deletion/nested native checkout or nonempty native restore qualification.', 'Earlier r44 failed attempt retained; it is not a passing qualification.'])
with (out / 'ordinary-ready-family-source-release.json').open('x',encoding='utf-8') as f:
    json.dump(release,f,indent=2)
retained=out / 'bound-inputs'
retained.mkdir(exist_ok=False)
for label,e in bindings.items():
    (retained / (label+'-'+Path(e['path']).name)).write_bytes(Path(e['path']).read_bytes())
with (retained / 'inventory.json').open('x',encoding='utf-8') as f:
    json.dump(bindings,f,indent=2)
print(json.dumps(dict(release=pin(out / 'ordinary-ready-family-source-release.json'),paths=len(paths),recipes=len(recipes),sources=len(host['sourceClosure']))))
