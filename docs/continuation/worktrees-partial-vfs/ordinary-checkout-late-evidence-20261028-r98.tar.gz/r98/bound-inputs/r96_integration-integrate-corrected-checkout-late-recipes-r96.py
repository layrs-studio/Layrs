"""Apply reviewed test-only proposal after r94 binary retention; fix R95-F1/F2."""
from pathlib import Path
import datetime,difflib,hashlib,json,subprocess
root,tmp=Path('D:/Layrs/layrs'),Path('D:/Layrs/tmp')
proposal=tmp/'ordinary-checkout-late-recipes-proposal'
meta=json.loads((proposal/'base.sha256.json').read_bytes())
source=Path(meta['base_path']); candidate=proposal/meta['candidate']
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
assert pin(source)['sha256']==meta['base_sha256']
assert pin(candidate)['sha256']==meta['candidate_sha256']
release=root/'.layrs-local/validation/provider-ordinary-fresh-checkout-20261028-r94/ordinary-fresh-checkout-source-release.json'
assert pin(release)['sha256']=='669c97d204533804845bb157bcb65e6d16a80342db48a96f38ca275689139296'
r=json.loads(release.read_bytes()); assert r['decision']=='released'
assert pin(Path(r['artifact_audit']['path']))['sha256']==r['artifact_audit']['sha256']
before=candidate.read_text(encoding='utf-8');s=before
old='''    let reopened = OrdinaryCheckoutPopulation::open(
        &f.source,
        &f.destination,
        &f.source_staging.transaction_id,
        &cancel,
    )
    .unwrap_or_else(|e| panic!("fresh late-cut reopen: {e}"));'''
new='''    let reopen_writers = Rc::new(Cell::new(0usize));
    let observed_reopen_writers = reopen_writers.clone();
    let reopened = with_writer_probe(
        move |_, point| {
            if point == AdmissionPoint::BeforeWritableOpen {
                observed_reopen_writers.set(observed_reopen_writers.get() + 1);
                return Err(invalid("partial checkout reopen must not open a writer"));
            }
            Ok(())
        },
        || {
            OrdinaryCheckoutPopulation::open(
                &f.source,
                &f.destination,
                &f.source_staging.transaction_id,
                &cancel,
            )
        },
    )
    .unwrap_or_else(|e| panic!("fresh late-cut reopen: {e}"));
    assert_eq!(reopen_writers.get(), 0);'''
assert s.count(old)==1;s=s.replace(old,new,1)
old='    assert!(!refused.to_string().is_empty());'
assert s.count(old)==1;s=s.replace(old,'    require_unowned_namespace_refusal(&refused);',1)
anchor='#[derive(Clone, Copy)]\nenum AllocationGap {'
helper='''fn require_unowned_namespace_refusal(mut cause: &Cause) {
    while let Cause::Cleanup { primary, .. } = cause {
        cause = primary;
    }
    let Cause::Validation(error) = cause else {
        panic!("allocation gap must reach the namespace validation: {cause:?}")
    };
    let crate::projection::ProjectionStoreError::Invalid(message) = error.as_ref() else {
        panic!("allocation gap must refuse an unowned namespace entry: {error:?}")
    };
    assert!(
        matches!(
            message.as_str(),
            "checkout namespace entry count or duplicate differs"
                | "checkout namespace has unowned entry"
        ),
        "unrelated refusal cannot qualify the allocation-gap protection: {message}"
    );
}

'''
assert s.count(anchor)==1;s=s.replace(anchor,helper+anchor,1)
base=source.read_bytes();assert s.encode('utf-8').startswith(base)
source.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true',str(source)],check=True)
assert source.read_bytes().startswith(base), 'existing r94 recipes changed'
snapshot=tmp/'provider-ordinary-checkout-late-root-correction-r96.rs'
with snapshot.open('xb') as f:f.write(source.read_bytes())
diff=tmp/'provider-ordinary-checkout-late-root-correction-r96.diff'
with diff.open('x',encoding='utf-8',newline='\n') as f:f.writelines(difflib.unified_diff(before.splitlines(True),source.read_text(encoding='utf-8').splitlines(True),fromfile='r95/'+source.name,tofile='r96/'+source.name))
record=dict(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),path=source.relative_to(root).as_posix(),
    before=pin(candidate),after=pin(source),snapshot=str(snapshot),diff=dict(path=str(diff),**pin(diff)),
    baseline_r94_unchanged=meta['base_sha256'],
    corrections=[dict(id='R95-F1',resolution='Require structured primary Validation(Invalid) and exact two namespace refusals; unrelated owner/profile/I/O/SQL errors fail the oracle.'),
        dict(id='R95-F2',resolution='Guard fresh partial reopen itself with BeforeWritableOpen rejection/count zero; remove guard before expected 2/1/1 population writers.')],
    status='ROOT self-reviewed narrow test fixes; rustfmt PASS. New five recipes not compiled or executed. Original r95 proposal and review unchanged.')
p=tmp/'provider-ordinary-checkout-late-root-correction-r96.json'
with p.open('x',encoding='utf-8') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(record=str(p),**pin(p),after=record['after'],diff=record['diff'])))
