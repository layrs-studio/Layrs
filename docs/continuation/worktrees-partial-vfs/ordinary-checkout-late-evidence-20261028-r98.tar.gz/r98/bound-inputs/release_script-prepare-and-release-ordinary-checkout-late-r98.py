"""After r94 terminal PASS and build/check r97. Five new tests only; no runtime here."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,sys
assert sys.argv[1:]==['--root-accept-r95-corrected']
root,tmp=Path('D:/Layrs/layrs'),Path('D:/Layrs/tmp')
prior=root/'.layrs-local/validation/provider-ordinary-fresh-checkout-20261028-r94'
out=root/'.layrs-local/validation/provider-ordinary-checkout-late-20261028-r98'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pin=lambda p:dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
normal=lambda p:p.read_text(encoding='utf-8').replace('\r\n','\n')
head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()
assert head=='6b1f5632bd7f6092226d57e3c813033a82bcfc98'
assert subprocess.check_output(['git','-C',str(root),'branch','--show-current']).decode().strip()=='feature/worktrees-partial-vfs'
previous=read(prior/'ordinary-fresh-checkout-results.json')
assert len(previous['results'])==5 and all(r['exit']==0 for r in previous['results'])
manifest_path=tmp/'provider-ordinary-checkout-late-review-r95-inputs.json'
report_path=tmp/'provider-ordinary-checkout-late-critical-review-r95.json'
correction_path=tmp/'provider-ordinary-checkout-late-root-correction-r96.json'
manifest,review,correction=[read(p) for p in [manifest_path,report_path,correction_path]]
assert sha(manifest_path)=='4bf344e1f1c40d8c17eb220f5d1259082c7057c5218d18e4512be397a2d78cdc'
assert sha(correction_path)=='6e06222636b5896ef865c2c32378592e4c1c843b80560435d2a1d6b92be17e31'
assert [f['id'] for f in review['findings']]==['R95-F1','R95-F2']
assert sha(Path(correction['snapshot']))==sha(root/correction['path'])==correction['after']['sha256']
assert sha(Path(correction['diff']['path']))==correction['diff']['sha256']
for e in manifest['files']:
    assert sha(Path(manifest['snapshot'])/e['path'])==e['sha256'],e['path']
for e in review['pins']['additional_sources']['ending']:
    assert sha(root/e['path'])==e['sha256'],e['path']
oldhost=read(prior/'host-disposition.json')
changed=[]
for e in oldhost['sourceClosure']:
    p=Path(e['path']);rel=p.relative_to(root)
    assert sha(prior/'source'/rel)==e['sha256']
    if sha(p)!=e['sha256']:changed.append(rel.as_posix())
assert changed==[correction['path']],changed
assert (root/correction['path']).read_bytes().startswith((prior/'source'/correction['path']).read_bytes())
build,check=[tmp/f'provider-ordinary-checkout-late-{k}-r97.log' for k in ['build','check']]
for p in [build,check]:
    raw=p.read_bytes();s=raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert 'Finished `' in s and 'error[' not in s,p
audit=tmp/'provider-ordinary-checkout-late-host-audit-r98.py'
s=normal(tmp/'provider-ordinary-fresh-checkout-host-audit-r94.py').replace('r94','r98').replace('provider-ordinary-fresh-checkout','provider-ordinary-checkout-late')
s=s.replace('Fresh protected checkout r92 with ROOT r93 test-only correction and r93b explicit result type; retained checkout strict error ordering; extended SQL progress recipe. Build/check r93b PASS; runtime pending.',
    'Five appended late checkout and allocation-gap recipes from r95 review, corrected R95-F1/F2 by ROOT r96. Product and r94 recipes byte-identical. Build/check r97 PASS; new recipe runtime pending.')
with audit.open('x',encoding='utf-8') as f:f.write(s)
subprocess.run(['py',str(audit),'r98'],check=True)
host=read(out/'host-disposition.json');assert len(host['sourceClosure'])==672
for e in host['sourceClosure']:
    p=Path(e['path']);assert sha(p)==sha(out/'source'/p.relative_to(root))==e['sha256']
runner=tmp/'provider-ordinary-checkout-late-run-r98.py'
s=normal(tmp/'provider-ordinary-fresh-checkout-run-r94.py').replace('r94','r98').replace('provider-ordinary-fresh-checkout','provider-ordinary-checkout-late').replace('ordinary-fresh-checkout','ordinary-checkout-late')
with runner.open('x',encoding='utf-8') as f:f.write(s)
prefix='projection::provider::bootstrap::preparation::activation::session::managed_ordinary_fresh_checkout_tests::'
cases=[
 ('managed_ordinary_fresh_checkout_withheld_verified_ack_reopens_exact_temp_and_finishes_with_two_writers','Verified ACK4, exact TEMP/inode/bytes, zero-writer fresh open and two population writers; complete replay.'),
 ('managed_ordinary_fresh_checkout_withheld_publishing_ack_reopens_exact_temp_and_finishes_with_one_writer','Publishing ACK5, exact parent/TEMP, zero-writer fresh open, one population writer; replay.'),
 ('managed_ordinary_fresh_checkout_rename_gap_reopens_exact_final_and_finishes_with_one_writer','After real rename+sync, deny Published writable admission6; exact Publishing/final inode, zero-writer fresh open then one writer.'),
 ('managed_ordinary_fresh_checkout_stage_allocation_gap_retains_then_refuses_without_adoption_or_cleanup','Deny stage Owned admission2 after actual creation. Retain/release mutable handle; exact Declared state; structured namespace refusal with no writer/adoption/deletion.'),
 ('managed_ordinary_fresh_checkout_file_allocation_gap_retains_then_refuses_without_adoption_or_cleanup','Deny file Owned admission3 after actual TEMP creation. Exact durable Stage Owned/File Declared; structured fresh refusal preserving inode/bytes without writer/adoption/deletion.')]
recipes=[dict(name=prefix+n,ignored=True,outer_seconds=3660,scope=s) for n,s in cases]
bindings=dict(runner=pin(runner),host_audit=pin(audit),release_script=pin(Path(__file__)),build=pin(build),workspace_check=pin(check),
 r95_manifest=pin(manifest_path),r95_review=pin(report_path),r95_patch=pin(Path(manifest['patch']['path'])),
 r96_correction=pin(correction_path),r96_diff=pin(Path(correction['diff']['path'])),r96_integration=pin(tmp/'integrate-corrected-checkout-late-recipes-r96.py'),
 prior_results=pin(prior/'ordinary-fresh-checkout-results.json'),prior_release=pin(prior/'ordinary-fresh-checkout-source-release.json'),
 prior_archive=pin(root/'docs/continuation/worktrees-partial-vfs/ordinary-fresh-checkout-evidence-20261028-r94.tar.gz'),
 review_archive=pin(root/'docs/continuation/worktrees-partial-vfs/ordinary-checkout-late-source-review-20261028-r95.tar.gz'))
saved=out/'bound-inputs';saved.mkdir(exist_ok=False)
for n,e in bindings.items():shutil.copyfile(e['path'],saved/(n+'-'+Path(e['path']).name))
release=dict(decision='released',revision='r98',recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_head=head,artifact_audit=host['executable'],
 reviewer='Independent SOURCE review r95; ROOT narrow fixes of R95-F1/F2 and integrated acceptance, no independent re-review of those fixes.',
 source_review='All672 inputs match live/retained. Only appended test file differs from qualified r94; old prefix byte-exact. Product unchanged. Build/check r97 PASS. Runtime pending.',
 reused_evidence='r91 Ready7PASS and r94 checkout5PASS retained; unchanged recipes intentionally excluded from this five-new-recipe suite.',
 limitations=['Single flat current file; no mid-copy/nonempty partial TEMP, real OS close failure, crash or owner-loss qualification.',
  'Rename gap means rename+sync succeeded before Published writer admission; no interruption between rename and sync.',
  'Allocation gaps intentionally remain blocked and preserve their objects; no successful orphan adoption/cleanup claimed.',
  'Native child3600/outer3660 bounds proposed and unmeasured for these new recipes.',
  'No C13 companions, Ready/admission or complete L0-L9 qualification from these cases.'],recipes=recipes,input_bindings=bindings)
path=out/'ordinary-checkout-late-source-release.json'
with path.open('x',encoding='utf-8') as f:json.dump(release,f,indent=2)
print(json.dumps(dict(release=pin(path),source_inputs=672,changed=1,recipes=5)))
