from pathlib import Path
import gzip, hashlib, io, json, shutil, sys, tarfile

base = Path('D:/Layrs/layrs').resolve()
output = base / 'docs/continuation/worktrees-partial-vfs'
last = int(sys.argv[1])
assert 23 <= last <= 25
suffix = 'r23' if last == 23 else f'r23-r{last}'
archive = output / f'imported-history-evidence-20261027-{suffix}.tar.gz'
inventory_path = output / f'imported-history-inventory-20261027-{suffix}.json'
assert not archive.exists() and not inventory_path.exists()
validation = base / '.layrs-local/validation'
recipes = validation / f'provider-family-publication-20261027-r{last}/recipes'
recipes.mkdir(exist_ok=False)
for name in ['provider-family-publication-host-audit.py', 'provider-imported-history-run.py',
             'provider-imported-history-source-release.json', 'package-imported-history-evidence-20261027.py']:
    shutil.copyfile(Path('D:/Layrs/tmp') / name, recipes / name)
for path in Path('D:/Layrs/tmp').glob('provider-imported-history-*.log'):
    shutil.copyfile(path, recipes / path.name)
allowed = {'.rs', '.json', '.md', '.log', '.py', '.toml', '.lock', '.txt'}
files = []
for rev in range(23, last + 1):
    folder = validation / f'provider-family-publication-20261027-r{rev}'
    assert folder.is_dir() and not folder.is_symlink()
    files.extend(p for p in folder.rglob('*') if p.is_file() and p.suffix in allowed)
files = sorted(set(files))
inventory = {'scope': f'{suffix} import v2 restore history codec/SQL DATA and native fresh capture frontier evidence. Individual reports state qualification; no physical inherited inverse, schema9 re-export, multi-segment product or crash acceptance. Includes preserved failures/superseded revisions when present; excludes binaries/databases/native fixtures.', 'files': []}
with archive.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as tar:
            for path in files:
                assert not path.is_symlink() and path.resolve().is_relative_to(base)
                relative = path.relative_to(base).as_posix()
                assert relative.startswith('.layrs-local/validation/')
                data = path.read_bytes()
                inventory['files'].append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
                info = tarfile.TarInfo(relative)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
expected = {e['path']: e for e in inventory['files']}
with tarfile.open(archive, 'r:gz') as tar:
    seen = set()
    for member in tar:
        assert member.isfile() and member.name in expected and member.name not in seen
        seen.add(member.name)
        data = tar.extractfile(member).read()
        entry = expected[member.name]
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
    assert seen == set(expected)
inventory['archive'] = {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
with inventory_path.open('x', encoding='utf-8', newline='\n') as f:
    json.dump(inventory, f, indent=2)
    f.write('\n')
print(json.dumps({'files': len(files), **inventory['archive']}))
