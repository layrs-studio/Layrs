"""ROOT invokes only after the r95 source review releases its selected inputs."""
from pathlib import Path
import datetime,difflib,hashlib,json
root,tmp=Path('D:/Layrs/layrs'),Path('D:/Layrs/tmp')
relative='crates/layrs-store-local/src/projection/provider/managed_export/checkout.rs'
source=root/relative
pin=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
prior=json.loads((tmp/'provider-ordinary-fresh-checkout-root-correction-r93.json').read_bytes())
e=next(e for e in prior['files'] if e['path']==relative)
assert pin(source)=={k:e[k] for k in ['bytes','sha256']}
raw=source.read_bytes();old=b'        let result = (|| {';new=b'        let result: CauseResult<Option<CheckoutJournal>> = (|| {'
assert raw.count(old)==2
assert raw.index(old)>raw.index(b'pub(super) fn read_checkout(')
assert raw.index(old)<raw.index(b'fn checkout_mutation(')
fixed=raw.replace(old,new,1)
log=tmp/'provider-ordinary-fresh-checkout-build-r93.log'
data=log.read_bytes();text=data.decode('utf-16' if data.startswith(b'\xff\xfe') else 'utf-8-sig')
assert 'error[E0282]' in text and 'checkout.rs:275' in text and 'due to 7 previous errors' in text
diff=tmp/'provider-ordinary-fresh-checkout-inference-correction-r93b.diff'
with diff.open('x',encoding='utf-8') as f:f.writelines(difflib.unified_diff(raw.decode().splitlines(True),fixed.decode().splitlines(True),fromfile='r93/'+relative,tofile='r93b/'+relative))
source.write_bytes(fixed)
snapshot=tmp/'provider-ordinary-fresh-checkout-inference-correction-r93b.rs'
with snapshot.open('xb') as f:f.write(fixed)
record=dict(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),path=relative,before={k:e[k] for k in ['bytes','sha256']},after=pin(source),snapshot=str(snapshot),
    diff=dict(path=str(diff),**pin(diff)),failed_build=dict(path=str(log),**pin(log)),
    correction='One explicit CauseResult<Option<CheckoutJournal>> annotation at retained read_checkout closure; E0282/E0283 ambiguous error conversion. No expression, control-flow or test change.',
    status='ROOT self-reviewed one-line compile correction; rebuild pending, no runtime claim')
p=tmp/'provider-ordinary-fresh-checkout-inference-correction-r93b.json'
with p.open('x',encoding='utf-8') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(record=str(p),**pin(p),after=record['after'])))
