"""Freeze ROOT's small test-only r92 correction, without claiming independent review."""
from pathlib import Path
import datetime, difflib, hashlib, json, shutil, subprocess
root, tmp = Path('D:/Layrs/layrs'), Path('D:/Layrs/tmp')
pin = lambda p: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
manifest_path = tmp / 'provider-ordinary-fresh-checkout-review-r92-inputs.json'
manifest = json.loads(manifest_path.read_bytes())
assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip() == manifest['head']
base = 'crates/layrs-store-local/src/projection/provider/bootstrap/preparation/activation/session/'
expected = {base + n for n in ['managed_ordinary_checkout_tests.rs','managed_ordinary_fresh_checkout_tests.rs']}
changed, patches, sources = [], [], []
for e in manifest['files']:
    previous, live = Path(manifest['snapshot']) / e['path'], root / e['path']
    assert pin(previous) == {k:e[k] for k in ['bytes','sha256']}
    if pin(live) != pin(previous):
        changed.append(e['path'])
        patches.extend(difflib.unified_diff(previous.read_text(encoding='utf-8').splitlines(True), live.read_text(encoding='utf-8').splitlines(True), fromfile='r92/'+e['path'],tofile='r93/'+e['path']))
    sources.append(dict(path=e['path'],**pin(live)))
assert set(changed) == expected, changed
snapshot = tmp / 'provider-ordinary-fresh-checkout-root-correction-r93-source'
snapshot.mkdir(exist_ok=False)
for e in sources:
    target = snapshot / e['path']; target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/e['path'],target)
    assert pin(target) == {k:e[k] for k in ['bytes','sha256']}
diff = tmp / 'provider-ordinary-fresh-checkout-root-correction-r93.diff'
with diff.open('x',encoding='utf-8',newline='\n') as f:f.write(''.join(patches))
record = dict(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=manifest['head'],
    status='ROOT source correction, rustfmt check passed; compilation/runtime pending; not independently re-reviewed',
    baseline_manifest=dict(path=str(manifest_path),**pin(manifest_path)),snapshot=str(snapshot),
    diff=dict(path=str(diff),**pin(diff)),changed=changed,files=sources,
    corrections=[dict(id='R92-01',resolution='Replace compatible write/share-all TEMP probe with read/share-none: blocked while failure holder retains mutable handle, succeeds after explicit holder drop, exact TEMP inode preserved. Production sharing flags unchanged.',
        reference='https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilea'),
        dict(id='G5',resolution='Require positive B/C/family snapshot/identity read routes and B OrdinarySourceIdentity before withholding ACK; retain zero read/writer probes after ACK.'),
        dict(id='G6',resolution='Traverse only Cleanup.primary and require exact Validation(Invalid(WITHHELD_ACK)), both fresh and retained checkout recipes.')],
    limitations=['A retained data-access handle is witnessed, not immutable TEMP or write exclusion.',
        'No actual OS close failure, crash, owner loss, Verified/Publishing/rename gap or partial nonempty TEMP qualification.',
        'Small correction self-reviewed by ROOT per orchestration instruction; original independent finding retained unmodified.'])
path=tmp/'provider-ordinary-fresh-checkout-root-correction-r93.json'
with path.open('x',encoding='utf-8') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(record=str(path),**pin(path),changed=changed,diff=record['diff'])))
