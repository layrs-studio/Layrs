"""Invoke only after r91 terminal and r93b build/check PASS. No tests executed here."""
from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, sys

assert sys.argv[1:] == ['--root-accept-r92-and-correction']
root, tmp = Path('D:/Layrs/layrs'), Path('D:/Layrs/tmp')
prior = root / '.layrs-local/validation/provider-ordinary-fresh-private-ready-20261028-r91'
out = root / '.layrs-local/validation/provider-ordinary-fresh-checkout-20261028-r94'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pin = lambda p: dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))
normal = lambda p: p.read_text(encoding='utf-8').replace('\r\n', '\n')
head = subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()
assert head == '0fa9954d7208117bcaa84b2a883265e3995da501'
assert subprocess.check_output(['git','-C',str(root),'branch','--show-current']).decode().strip() == 'feature/worktrees-partial-vfs'
manifest_path = tmp/'provider-ordinary-fresh-checkout-review-r92-inputs.json'
review_path = tmp/'provider-ordinary-fresh-checkout-critical-review-r92.json'
correction_path = tmp/'provider-ordinary-fresh-checkout-root-correction-r93.json'
manifest, review, correction = [read(p) for p in [manifest_path,review_path,correction_path]]
inference_path=tmp/'provider-ordinary-fresh-checkout-inference-correction-r93b.json'
inference=read(inference_path)
assert sha(manifest_path) == '5e649c67ac6a67477f37d76992fc99fc416763a1dc91697eae7a9bc7b2e36978'
assert sha(correction_path) == '2790cd2bb49c76894136f84b058fe2297ff556eae03e747f2ce432c7240254be'
assert [f['id'] for f in review['findings']] == ['R92-01']
assert sha(Path(correction['diff']['path'])) == correction['diff']['sha256']
assert len(correction['changed']) == 2
assert sha(tmp/'provider-ordinary-fresh-checkout-review-r92.diff') == manifest['diffSha256']
for e in manifest['files']:
    assert sha(Path(manifest['snapshot'])/e['path']) == e['sha256']
for e in correction['files']:
    assert sha(Path(correction['snapshot'])/e['path']) == e['sha256'], e['path']
    if e['path']==inference['path']:
        assert inference['before']=={k:e[k] for k in ['bytes','sha256']}
        assert sha(root/e['path']) == sha(Path(inference['snapshot'])) == inference['after']['sha256']
        before=normal(Path(correction['snapshot'])/e['path'])
        assert normal(root/e['path']) == before.replace('        let result = (|| {','        let result: CauseResult<Option<CheckoutJournal>> = (|| {',1)
    else:
        assert sha(root/e['path']) == e['sha256'], e['path']
assert sha(Path(inference['diff']['path']))==inference['diff']['sha256']
assert sha(Path(inference['failed_build']['path']))==inference['failed_build']['sha256']
for e in review['inputs']['supplementary_sources']:
    assert sha(root/e['path']) == e['sha256'], e['path']
previous = read(prior/'ordinary-fresh-private-ready-results.json')
assert len(previous['results']) == 7 and all(r['exit'] == 0 for r in previous['results'])
build, check = [tmp/f'provider-ordinary-fresh-checkout-{kind}-r93b.log' for kind in ['build','check']]
for p in [build,check]:
    raw=p.read_bytes(); text=raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert 'Finished `' in text and 'error[' not in text, p

audit=tmp/'provider-ordinary-fresh-checkout-host-audit-r94.py'
text=normal(tmp/'provider-ordinary-fresh-private-ready-host-audit-r91.py').replace('r91','r94').replace('provider-ordinary-fresh-private-ready','provider-ordinary-fresh-checkout')
text=text.replace('Fresh private Ready and retained Ready ordering with r89 protected checkout-progress SQL, corrected inherited-receipt witness and finer allocation timing. Build/check r90 PASS; new runtime qualification pending.',
    'Fresh protected checkout r92 with ROOT r93 test-only correction and r93b explicit result type; retained checkout strict error ordering; extended SQL progress recipe. Build/check r93b PASS; runtime pending.')
with audit.open('x',encoding='utf-8') as f:f.write(text)
subprocess.run(['py',str(audit),'r94'],check=True)
host=read(out/'host-disposition.json')
assert len(host['sourceClosure']) == 672
changed=[]
for e in host['sourceClosure']:
    rel=Path(e['path']).relative_to(root)
    assert sha(root/rel) == sha(out/'source'/rel) == e['sha256']
    old=prior/'source'/rel
    if not old.exists() or normal(root/rel) != normal(old): changed.append(rel.as_posix())
assert set(changed) == set(manifest['changed']) and len(changed)==14, changed
runner=tmp/'provider-ordinary-fresh-checkout-run-r94.py'
text=normal(tmp/'provider-ordinary-fresh-private-ready-run-r91.py').replace('r91','r94').replace('provider-ordinary-fresh-private-ready','provider-ordinary-fresh-checkout').replace('ordinary-fresh-private-ready','ordinary-fresh-checkout')
with runner.open('x',encoding='utf-8') as f:f.write(text)
session='projection::provider::bootstrap::preparation::activation::session::'
recipes=[dict(name='projection::provider::destination_ready::ordinary_tests::ordinary_family_publication_authenticates_actual_ready_changes_one_row_and_replays_readonly',ignored=True,outer_seconds=180,
    scope='Exact protected checkout progress absent/Declared/Owned/Verified/Publishing/complete and corrupt rows; query-only, no-effects; strict finalizable exclusions and family Ready publication.')]
for name,scope in [
    ('managed_ordinary_fresh_checkout_refuses_drift_then_populates_absent_and_replays_without_writer','Actual absent checkout from fresh B/C owners; drift and namespace refusals, exact population, no-writer complete replay.'),
    ('managed_ordinary_fresh_checkout_withheld_declare_ack_releases_then_reopens_and_completes','Declare SQLite close ACK withheld; primary cause, positive observer controls, zero probes after ACK, explicit teardown and fresh completion.'),
    ('managed_ordinary_fresh_checkout_withheld_owned_ack_releases_then_reopens_and_completes','Owned SQLite close ACK withheld; mutable TEMP handle retained/released with exact inode, fresh Owned resume, exact final inode/bytes and replay.')]:
    recipes.append(dict(name=session+'managed_ordinary_fresh_checkout_tests::'+name,ignored=True,outer_seconds=3660,scope=scope))
recipes.append(dict(name=session+'managed_ordinary_checkout_tests::managed_ordinary_checkout_protects_complete_union_and_replays_declared_close_ack',ignored=True,outer_seconds=2460,
    scope='Retained checkout strict read/error ordering regression, exact primary ACK and positive per-route observation with zero subsequent probes.'))
bindings=dict(runner=pin(runner),host_audit=pin(audit),release_script=pin(Path(__file__)),build=pin(build),workspace_check=pin(check),
    r92_manifest=pin(manifest_path),r92_review=pin(review_path),r92_diff=pin(tmp/'provider-ordinary-fresh-checkout-review-r92.diff'),
    r93_correction=pin(correction_path),r93_diff=pin(Path(correction['diff']['path'])),r93_freeze=pin(tmp/'record-ordinary-fresh-checkout-root-correction-r93.py'),
    r93b_inference=pin(inference_path),r93b_diff=pin(Path(inference['diff']['path'])),r93b_fix_script=pin(tmp/'correct-ordinary-checkout-inference-r93b.py'),failed_build_r93=pin(Path(inference['failed_build']['path'])),
    prior_results=pin(prior/'ordinary-fresh-private-ready-results.json'),prior_release=pin(prior/'ordinary-fresh-private-ready-source-release.json'),
    prior_archive=pin(root/'docs/continuation/worktrees-partial-vfs/ordinary-fresh-private-ready-evidence-20261028-r91.tar.gz'),
    review_archive=pin(root/'docs/continuation/worktrees-partial-vfs/ordinary-fresh-checkout-source-review-20261028-r92.tar.gz'))
saved=out/'bound-inputs'; saved.mkdir(exist_ok=False)
for name,e in bindings.items():shutil.copyfile(e['path'],saved/(name+'-'+Path(e['path']).name))
release=dict(decision='released',revision='r94',recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_head=head,artifact_audit=host['executable'],
    reviewer='Independent r92 critical SOURCE review plus ROOT small test-only correction, explicit result type compilation fix, and integrated acceptance. These small corrections have not been independently re-reviewed.',
    source_review='All672 inputs retained/live match; exactly14 paths differ from r91, equal reviewed r92 plus the recorded two-file test correction and one explicit result type annotation. Build/check r93b PASS. Runtime pending.',
    limitations=['No actual OS/SQLite close failure, crash or owner-loss qualification; only withheld observer ACK after successful SQLite close.',
        'Flat current README; no positive deletion, nested directory, nonempty partial TEMP, Verified/Publishing/rename-gap or B10 source coverage in new native recipes.',
        'Declared objects without durable Owned remain refused, not adopted or removed.',
        'No Ready, publication or admission effects in fresh checkout driver. No complete L0-L9 or product-host qualification.',
        'Child3600/outer3660 bounds are proposed and unmeasured for the three fresh natives.',
        'TEMP witness establishes retained data-access handle, not immutable TEMP or exclusion of compatible writes.'],
    recipes=recipes,input_bindings=bindings)
path=out/'ordinary-fresh-checkout-source-release.json'
with path.open('x',encoding='utf-8') as f:json.dump(release,f,indent=2)
print(json.dumps(dict(release=pin(path),source_inputs=len(host['sourceClosure']),changed=len(changed),recipes=len(recipes))))
