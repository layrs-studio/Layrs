# Ordinary C metadata and content integration

27 October 2026. Next implementation plan after physical C allocation, source
Copying and Initializing registration. It does not qualify those preceding
states or claim that C is Ready/admitted. The original full programme goal stays
open through autonomous C, inherited inverses and all later product stages.

## Qualified ReserveOnly checkpoint — r36/r37

After Staging commit `6ccea26`, the dedicated ReserveOnly catalog validator,
exact source adapter and physical reservation callback are connected. The
ordinary catalog route remains strict. Export planning uses the freshly
authenticated private mappings and cached exact manifests, avoiding both
ordinary lease lookups after C obtains its reservation. A complete export
catalog/index read closes before physical CAS verification; immutable object
pins and an independent lifecycle guard survive the later Exclusive/Immediate
index revalidation, reservation COMMIT and positive close.

Production check passes (28.44 s). Workspace all-targets check passes (40.19 s)
after a test helper's domain argument was corrected to its required static
lifetime. Final normal test build passes (1m18s); r36 audit retains 620 inputs,
nine startup checks and CodeView age114. Independent critical source release
compares 132 live/retained paths and releases 17 exact recipes.

All six pure recipes pass on r36. The first SQL recipe stops during fixture
construction: ImportSource::Ordinary enum fields are snake_case, but the
fixture supplied formatDigest/privateSchema/checkoutIdentity. ROOT changes
exactly those three test keys; production and native test sources are unchanged.
The failed fixture and logs remain preserved and must not be reopened.

The corrected normal test build passes (22.45 s). r37 audit retains the same
620 inputs, with exactly one changed test file, CodeView age115 and EXE SHA256
`75eb4f69be114a8b9d007701999610aa4fe44f14830ecd3c9ed3398dc72f577b`.
ROOT's narrow fixture addendum inherits the unchanged independent production
review and binds all 132 selected paths and all eleven remaining recipe names
to this new artifact. Addendum SHA256:
`a83ee6f59785afc1891846d223ff717fbd1456ac22abe0ee015eeee10bd8f0b9`.

All ten SQL recipes pass on fresh r37 fixtures: five new ReserveOnly cases and
five strict retained-family regressions. The native same-owner reservation
recipe passes in 640.03 s child / 640.12 s parent / 640.167 s outer. It verifies
the actual immutable CAS/source ownership, exact full-Q insertion, withheld
acknowledgement after successful family writer close, and same-owner replay
without another writer. Complete B/C private rows and other files are unchanged;
only the identity-bound family catalog gains the reservation. C remains
Initializing without root, installation, Ready or ordinary admission.

Portable archive `ordinary-reservation-evidence-20261027-r36-r37.tar.gz`:
1,277 verified files, 3,592,445 bytes, SHA256
`87f9d2d4fc249e2f2a57cd9740f0393b27c157eeb1322e65cad1716a01184389`.
The r36 fixture failure remains included. These recipes do not qualify actual
OS close failure, index mutation during the released-gate interval or recovery
after owner loss. Later Installing changes are a separate unqualified lot.

## Qualified Installing checkpoint — r38

The complete-family Installing gate and ordinary ExactCatalog adapter are now
written and wired. Workspace all-targets check passes in 55.46 s; the final
normal test build passes in 1m40s. The r38 audit retains 623 inputs, nine startup
checks and CodeView age116; EXE SHA256
`0cadf30343128b48409bd610640dd4aaa3f5eff775a4ef8cc49546116eb2374e`.
Independent critical source review finds no
confirmed blocking issue in production and SQL tests. The separate final r38
review also finds no blocking issue: 143 reviewed paths, all 623 source inputs,
artifact/runner bindings and all fourteen exact recipe names match. Release
SHA256 `a9ad09a9a8bf66b1b630b52437ae17705eba2f43aeed999b3fbdb2bd938b9474`. The strict Provider and ReserveOnly routes
retain their exclusions. The new gate validates all retained Published groups
first, then C Declared..Published using the same charged chunk/manifest sets,
then the complete reservation inventory. Global accounting includes every exact
journal; future row capacity subtracts already-created C rows before adding
the complete C union.

The ordinary physical adapter holds one immutable private source snapshot and
retained CAS pins across engine steps. Each family action validates completely,
commits, positively closes and reads back before engine advancement. Byte reads
and complete image revalidation happen outside family catalog scopes. Errors
abort without further SQL probes; public success waits for observed outer
snapshot completion, and persistent connection finalization still requires
owner.close. No attempt/capability escapes. Provider per-action source-close
semantics stay unchanged; the ExactCatalog documentation states this difference.

CAS-only read opens in exact_content/spool.rs and publish.rs now request only
read access, compatible with retained immutable Windows handles. Staging files
keep the rights needed for publication. Four new SQL DATA recipes and a pure
100k capacity-boundary test are written. The genuine native recipe is now frozen:
one B owner, retained base/history plus new current content, withheld Declared
close acknowledgement, complete union installation and no-writer retry. It is
qualified on the retained r38 artifact. Checkout population, protection, Ready/Published transition,
C9 admission, autonomous C and owner-loss recovery remain separate next steps.

The qualified ReserveOnly predecessor is `00d7aa7`. All fourteen r38 recipes
pass: two pure, four new Installing SQL, two strict exact-engine SQL, five
ReserveOnly SQL regressions and the genuine native scenario. Native timings:
1193.83 s child / 1193.87 s parent / 1193.900 s outer, child1800/outer1860.
Session 18648 is terminal exit0. The complete union includes retained base,
historical-only capture and uncaptured current bytes; all three C journals
become Published. A withheld acknowledgement AFTER actual successful Declared
close leaves exactly that durable progress; same-owner retry completes it.
Completed retry opens no writer and preserves all SQL/tree witnesses. Actual
retained CAS pins refuse conflicting Windows write opens during writer callbacks.
C remains Initializing/C8 without root, checkout, Ready or ordinary admission.

Archive `ordinary-installing-evidence-20261027-r38.tar.gz`: 649 verified files,
1,818,703 bytes, SHA256
`75f35736a3003220ce69215a52c0691ffa86ed9d4561004cce0f642f209493be`.
Sources, startup audit, independent release, runner and all results are retained;
native fixtures and binaries are excluded. The 16 source blobs committed in
`bb1a5ac` match the retained r38 source modulo CRLF. Subsequent Protected/Checkout source is a
separate working-tree lot and is not covered by this qualification.

## Next integrated protection and checkout slice

Implementation is integrated in the working tree and compiles; runtime is still
unqualified. The new `managed_export/content.rs` factors the retained source
snapshot/full union/funding proof into closed Installing, Protection and
Checkout modes. Installing retains its strict no-root/no-checkout rules.
`protection.rs` verifies and pins C CAS, writes/replays the exact root with
unchanged installation/accounting state, and requires acknowledged closes.
`checkout.rs` uses the typed Ordinary journal, retained allocation pins and
the existing filesystem engine; source/C/family validation surrounds every
acknowledged journal mutation. An unsuccessful writer/rollback/close cannot
advance filesystem work. Protection reopening is read-only and requires an
existing exact checkout journal. Checkout success retains immutable final-file
pins; it grants no Ready or admission authority.

Five Protected SQL recipes, two Ordinary checkout pure recipes and two C8
checkout SQL recipes are written/formatted. The separate native Protection +
Checkout recipe is frozen with genuine B/C owners, withheld successful
Declare-close acknowledgement, same-owner retry and complete witnesses. None
of this new lot has run. It covers one selected current file; positive deletion,
nested directories, actual OS close failure, mid-copy interruption and owner
loss remain unqualified.

The first workspace check found E0425 in content.rs: the stageable reader is
under ordinary_destination::staging. After that path correction, the workspace
all-targets check passes in 35.14 s and the normal test build passes in 1m27s.
The independent critical source review reports no confirmed remaining blocker,
including the corrected call and all new recipes. Its full final result is
retained at `D:/Layrs/tmp/provider-ordinary-protection-critical-review-20261028.json`.

The r39 audit retains 631 source inputs, nine startup sources and CodeView
age117. EXE SHA256
`20d9a32e2a4853ce1cc7266d241555076ffb4df76f1e6ae19d91bc2ea8e696bb`.
Eighteen proposed recipes comprise three pure, fourteen SQL (including strict
Provider journal and Installing regressions), and one native child2400/outer2460
case. Final exact artifact/recipe binding review precedes serial fresh-fixture
execution; there is no r39 runtime result yet.

After Installing qualification, protect C and materialize its checkout under
the same genuine B/C owners. Keep the current Installing/ReserveOnly gates
strict. The independent investigation identified these concrete seams:

1. Add a closed Protected family mode. The retained root walk currently calls
   read_group/require_member before target validation, and therefore requires
   every provider-import root to belong to a Ready member. Defer ONLY the exact
   expected C root_id to the active validator, still count that root in the
   global bounded inventory, and leave all other retained roots unchanged.
2. The active validator reuses validate_export_installations with the same
   shared debit sets, requires all required C journals Published, and validates
   exact root absence/presence, binding, member and retained envelope. Existing
   ExactProtection::insert_or_replay is accessible from admitted_catalog;
   its complete caller pre/post checks must preserve installation, reservations
   and global usage exactly. No new debit or release accompanies protection.
3. Verify C through verify_published_cas with its actual ExactBinding and
   ExactStorage outside catalog scopes. RetainedCas remains the independent B
   proof. Never label B's pins as C's Published proof.
4. Add an explicit ordinary ExpectedCheckout constructor. Current
   checkout_journal/inventory.rs::expected_parts requires ImportSource::Provider;
   the ordinary entry must require admitted private9 and reuse the bounded
   inventory, Windows alias checks and canonical header. Reconstruct its header
   from the actual destination Staging before admitting any journal.
5. Add a distinct ordinary read_checkout_staging. The current copied reader
   requires projection_prejournal empty. Preserve read_stageable's strict rule;
   factor only the common complete C8 schema, identity/head/intent, thirteen
   copied rowsets (including restore history) and FK checks. The new branch
   accepts solely checkout_journal::read's complete bounded typed inventory.
6. Expose only the needed CheckoutStorage/OwnedCheckoutFile methods through
   bootstrap and construct storage from the ordinary allocation's cloned root
   and control pins. Do not reopen ownership by pathname. Reuse the filesystem
   engine's durable Declare/Owned/Verified/Publishing/Published protocol.
7. Before checkout effects require the exact root present and
   protection.require_envelope(remaining - expected.file_bytes,
   actual_metadata_floor + expected.maximum_encoded_bytes). Commit, positively
   close and freshly reread each private C journal mutation before filesystem
   work. Retain immutable final-file proof; do not admit C at checkout completion.

Follow-on order remains C private Ready, C family member Ready, B Ready,
B Published, then C9 admission. Those readers/writers still contain Provider
source assumptions and need explicit ordinary interpretations authenticating
B9 provenance. Autonomous C must eventually read its archived provenance with
A and B unavailable; source availability cannot become a permanent dependency.

### Investigated Ready/publication/admission seams — 28 October

Read-only investigation after the Protected/Checkout implementation identified
these concrete next changes. No Ready implementation or runtime evidence yet:

1. `managed_export/content.rs` is deliberately Staging-only, including its final
   revalidation. A distinct Ready context must retain original Staging, actual
   selection, rederived `ReservePlan.data` (observation/placement/capture), full
   union/binding, C protection and exact checkout expected/journal/file pins.
   Expose narrow internal proof getters and exact `require_journal`; do not use
   the Staging callback to perform a mutation that invalidates its own exit gate.
2. `destination_ready::{ManagedReadyInputs,ReadyView,data,read}` and
   `managed_content/ready_data.rs` contain Provider bootstrap/activation inputs.
   Introduce a closed ordinary input backed by actual B9 admitted provenance and
   closure, and factor the common suffix INSERT/CAS (snapshots/selections,
   capture/mappings/claim/receipt/DestinationReady). The Ready table inventory in
   `destination_ready/read.rs` currently omits `projection_restore_history`;
   preserve and authenticate that copied history for this ordinary route.
3. Ready DATA must be rebuilt from the genuine ordinary image and plan. The
   current ReservePlan intentionally has `validated_metadata_floor=None`;
   compute complete Ready/journal/admission metadata explicitly, without
   upgrading planning DATA into physical authority. The destination reader must
   accept only exact Staging or the complete exact Ready suffix, not the old
   Copied reader after suffix insertion.
4. `shared/provider_import/publication.rs` and `destination_ready/family.rs`
   need a closed ordinary publication mode using actual C Ready and B9. Preserve
   the full retained-family walk/shared debits/root; distinguish C Initializing
   from Ready explicitly. Only CAS registry Initializing→Ready, retaining C's
   validated read transaction across family COMMIT/close and fresh readback.
5. `ordinary_transition.rs` currently rejects Ready/Published and receipt IDs.
   Add exact ordinary forms and separate B Ready then Published writers, with
   actual C/family snapshots held through each source COMMIT/close. After B
   Ready, use retained CAS/checkout/plan; never re-enter the Staging image route.
   Historical B Published must remain inspectable after later allowed B changes.
6. `VerifiedDestinationPrefix` and `PublishedForReady` retain Provider source
   or activation types. Ordinary provenance needs explicit historical variants:
   complete copied B9 prefix/ancestry and actual B Published read through an
   independent RO connection with exact admission/FORMAT/database/receipt.
   `destination_ready/autonomous.rs` must use the complete multi-group family
   interpreter, rather than a single-group family interpretation.
7. `managed_admission::{write,record}` currently refuses Ordinary. Reuse its
   journal/source-publication archive and budget protocol with genuine B9
   binding fields. Hold independent B RO and family through C9 COMMIT/close;
   then prove C9 can read the archived provenance with B unavailable.
   `read_admitted_import` and `destination_ready/historical.rs` must support
   that origin. A fresh Ready opener/retry after allocation-holder loss remains
   separate work; same-holder retry is not evidence for that recovery.

Required observable order stays **C private Ready → C family Ready → B Ready →
B Published → C9**, with positive closes/fresh readback at every acknowledgement.

For the first private-Ready integration, keep the current complete Protected
family gate: C's family registry remains Initializing while its private suffix
becomes Ready. A new family publication mode is needed only for the subsequent
registry CAS. The Ready boundary can rederive the planned destination-Staging
DATA from actual B Staging and retained C allocation pins, then authenticate
actual C as either that Staging form or its exact complete Ready suffix. Never
present the derived predecessor as an observed C row. This avoids re-entering
the old Staging-only reader after a successful Ready COMMIT.

The current `destination_ready::ReadyView` is not truly provenance-neutral: its
source field supplies selection, observation/activation placement and selected
base descriptors. A closed ordinary view must carry actual B selection and
source-derived observation/placement plus the exact selected-base map from
private content mappings and retained manifests. The unchanged-file checkout
check must use that exact map, not manufacture Provider descriptors or choose
an arbitrary representation by FileId. Keep Provider constructor checks intact.

The common suffix mutation itself is reusable after authenticated predecessor
and DATA preparation: append two snapshots/selections, exact new mappings,
capture/claim/receipt, CAS head and DestinationReady, then re-read the complete
prefix plus suffix. `projection_restore_history` must join the bounded count
inventory while the immutable prefix validator continues checking its exact
rows. Add a dedicated ordinary Ready checkout expectation constructor; the
existing Provider `from_ready` must remain strict.

Metadata can reuse `managed_budget::complete_metadata_floor` on the actual
base floor and canonical Ready/receipt/claim, then add the retained checkout
journal envelope. Require the remaining exact reservation after checkout bytes
to cover that floor and the exact protection envelope. This does not set the
planning-only `validated_metadata_floor` field or change quota/reservation.

## Qualified Staging checkpoint — r34/r35

After metadata commit `959e363`, the ordinary destination interpreter now has
an explicit expected source phase. Both Copying and Staging require the actual
durable source row; a proposed Staging row grants no destination access. The
shared copied-row validator accepts the legitimate SourceStaging /
DestinationCopying gap without reconstructing historical source authority.
The family wrapper still requires exact Initializing and no C reservation.

Source gates, full planning funding, preallocation lifecycle capacity and the
physical two-commit driver are integrated with three SQL recipes and one
native phase-gap recipe. Workspace all-targets check passes (33.03 s), and the
normal initial libtest build passes (1m16s). The
first check exposed a missing proposal re-export; its canonical construction
was restored before the passing check. Critical review also corrected both
error-path family postchecks: failed updates or close acknowledgements now
permit physical pin checks only, never an automatic additional SQL probe.
No reservation, content installation or autonomous C claim is added by this
Staging increment. Later ReserveOnly changes are tracked separately above and
are absent from the retained r35 executable/source release.

r34 passed all nine pure budget/capacity recipes, then stopped at the exact-test
guard: the first Staging SQL name ran zero tests. An implicit child module path
had compiled the production Staging module twice instead of the SQL test file.
The explicit `#[path = "tests/staging.rs"]` correction builds successfully in
1m15s on r35; the three SQL bodies are now compiled. No SQL/native r34 recipe
executed. r34 logs, source release and runner remain preserved; its pure passes
retain their provenance. This wiring gap escaped initial source review and
integration; r35 review checks all seven exact recipe names in the executable.

All six SQL recipes pass on r35: the three new Stage cases (11.258, 11.359,
8.136 s) and three copied-metadata regressions (6.074, 10.396, 4.054 s). The
native case passes in 694.90 s child / 694.97 s parent / 694.993 s outer. Four
actual B owners exercise SourceStaging/C Copying after a refused C writer open,
durable C Staging after withheld successful-close ACK, then exact no-writer
replay. All thirteen copied rowsets, B admission and byte witnesses pass. C is
still Initializing/unadmitted without any family reservation. These results do
not establish real OS close failure, midwrite cancellation or owner-loss/crash
recovery.

r35 audit: EXE `e57361ef0487a9a7751305f2fe76e1dc65c5f46d18abdbbf6995cbf72e838acd`,
CodeView age113, 615 retained inputs and nine startup checks. Independent release
`29d772439c27fff76a1fe5ee9cc09c5f158b9d878d4de408d390635163c99c18`
matches all 119 reviewed live/retained files before execution. The portable
`ordinary-staging-evidence-20261027-r34-r35.tar.gz` contains 1,264 verified files,
3,495,506 bytes, SHA-256
`024959c4c0a5e6c748c9ad3ff04561378d9b1503525ad7fc4f0a1e9b1e8206b4`.

## Current qualified metadata checkpoint

The ordinary C8 adapter and physical driver are connected and qualified on the
three r32 SQL recipes and the corrected r33 native recipe. The workspace
all-targets check passed (24.01 s); the final normal libtest build passed
(41.25 s). The r33 executable and 612 retained source inputs are audited; four
of those inputs are unwired future budget/Staging drafts, explicitly outside
this release. Newer Staging/reservation drafts remain outside the module tree.

r31 stopped in the SQL fixture before destination copying: its manifest list
included a known old Provider base outside the exact ordinary union. The
test-only correction derives the exact union from authenticated history and
selected bases. All three r32 SQL recipes then passed (4.918, 7.264, 2.988 s).

r32's native attempt reached durable C8 and successful physical close with ACK
withheld, then failed a too-broad content-table witness after 580.436 s. Twelve
other tables were identical; B retained one extra 21-byte base mapping outside
the committed historical mapping rowset. No failed database was reopened. The
corrected native witness derives that exact rowset independently in a fresh
source RO snapshot, compares the COMPLETE C content table to it and compares
all twelve other complete tables to B. Production code is unchanged.

r33 native passes: 696.21 s child / 696.29 s parent / 696.914 s outer. The
successful-close ACK refusal, durable complete C8, managed B reopen, exact
no-writer retry, complete byte witnesses, unchanged incoming admission and C
ordinary-open refusal all pass. Bounds remain child1200/outer1260. This is not
performance acceptance. The three SQL passes retain their r32 provenance.

The portable `ordinary-metadata-evidence-20261027-r31-r33.tar.gz` contains 1,858
verified files, 5,170,933 bytes, SHA-256
`8277f045a188af5faa55119a68461e8050f8de8f5f9b1cc15078aecca8c9a912`.
r33 EXE SHA-256
`ff0fc51d90f2720c7130feba64272ba507327cd05773745db7640ca4c5e112de`,
CodeView age111; independent release SHA-256
`5b382424cca0ac41ccf182f75ade2094c1113a909cbcbe4ea28c5ae725026106`.
All 112 reviewed live/retained paths matched before execution.

The native recipe deliberately withholds one acknowledgement after a successful
physical writer close, independently checks complete durable C8, then reopens B
and requires exact replay without another destination writer. It does not model
an actual OS close failure or cancellation after destination writes.

The next reservation investigation also found that ordinary planning currently
budgets copied-prefix metadata only. The later base floor additionally includes
observation, placement, capture, selection and both actual intents. The immutable
plan must fund a conservative complete envelope before SourcePlanned; Staging
must rederive and validate its actual floor. An underfunded durable plan must
refuse reservation, never silently increase its quota or lower the floor.

Two new Staging SQL modules are drafted outside the module tree:
`ordinary_transition/staging.rs` and `ordinary_destination/staging.rs`. They are
not compiled or qualified. Integration must extend the bounded outgoing reader,
live-mutation gate, source phase/shape checks and preallocation capacity together.
Source normalized byte accounting must include the reservation TEXT column.
The destination source interpreter needs an explicit expected source phase and
a shared exact copied-row validator; this permits actual SourceStaging with
DestinationCopying without manufacturing historical SourceCopying authority.

The first content-reservation slice can retain the installation engine's strict
Provider policy: a dedicated ordinary ReserveOnly family validator must walk all
retained Published groups, preserve global accounting and permit exactly C's
absent-or-full reservation. C must still have no protection root, legacy journal
or exact installation. Installation progress requires a later explicit mode.

After that reservation exists, ordinary content-manifest lookup rejects it.
The retained managed owner therefore needs an export-specific source callback
and canonical manifest lookup using actual source/C commitments and pins. Keep
generic ordinary content permissions strict. Retained-owner retry and reopening
after owner loss are different requirements; the latter additionally needs the
still-missing physical allocation recovery protocol.

## Atomic C8 ingress

Use a dedicated ordinary adapter, leaving Provider EmptyIngress entry points
strict. The generic `copy_verified_prefix` already accepts genuine admitted B9
closure evidence and an actual private8 destination. It copies all thirteen v2
rowsets, including generation-zero snapshot/selection and restoration history.

Under the real owner, source snapshot and independently retained C pins:

1. Require exact SourceCopying, published FORMAT and Initializing membership.
2. Inspect the pinned C database; accept only Uninitialized or exact complete
   ordinary CopiedPrefix. Reject arbitrary partial EmptyIngress.
3. Obtain clean writer admission, retain geometry, enable FK and begin Immediate.
4. Create exact C8 schema, destination identity, ordinary backend and import
   prefix. Copy the genuine prefix rows before inserting DestinationCopying and
   head, because their generation-zero FK requires the copied snapshot to exist.
5. Set head to the outgoing prefix's source generation. Validate exact C8 schema,
   identity/backend/prefix, singleton destination intent, head and copied rows;
   every unrelated table remains empty.
6. Commit, positively close and independently read back the complete state.

Failure before successful COMMIT rolls back rather than committing an intermediate
EmptyIngress. A later close, cancellation or postvalidation failure can leave a
complete C8 copy durable; exact read-only replay must authenticate that state.
Replaying an exact complete copy performs no writes. Do not copy B's incoming
admission or outgoing intent rows as C history. Ancestry comes from the committed
import rowsets and receipts. Do not use B's current observation as C's G0.

The existing Provider `destination_validation::read_state` table exceptions
omit populated `projection_restore_history`. Any shared implementation must
retain exact restored-row commitment/count checks and permit them only at the
copied phase. A new ordinary reader must include them from its first version.

## Staging and reservation evidence

Before reserving C content, rederive the actual plan from B's protected image,
current selection, selected bases, exact historical mappings and both actual
intents. `validated_metadata_floor == None` is not reservation authority. Reuse
the common plan kernel and `managed_budget::base_metadata_floor` with the complete
representation union and actual source/destination payload envelopes.

Preserve phase order: SourceStaging CAS, DestinationStaging CAS, fresh comparison
of both, then reserve. Both rows bind the deterministic transaction reservation.
Staging remains live in all ordinary gates; no-resource cancellation cannot
handle it. Capacity, recovery and uncertain-close requirements apply separately.

## Dedicated retained-B plus active-C family policy

The ReserveOnly integration has two coupled parts. Factor the complete
`AdmittedFamilyContext::validate_catalog` walk behind an optional active target,
leaving its ordinary entry point on the unchanged `None` path. Classify that
target only after checking all retained Published groups and required roots,
before the final all-reservation inventory. The export writer requires FK ON
and a caller transaction, with complete validation before and after its exact
insert/replay. Unknown groups and any C installation/root remain forbidden.

An export-only source callback must bootstrap from actual SourceStaging,
actual complete DestinationStaging, retained private mappings, cached canonical
manifests and the pinned current image. This DATA can nominate a ReserveOnly
target, but grants no physical content access. Under the dedicated validated
catalog gate, resolve historical/base representations by exact FileManifestId,
verify their indices and CAS bytes, then rederive the complete immutable plan,
Q/M and actual pair metadata floor before reservation. Current-image manifests
may legitimately not be installed yet; their bytes stay handle-backed.

Both ordinary lookups must be bypassed through this explicit export policy:
the pre-action `with_source_transaction` manifest read and the second manifest
read inside `derive_plan`. Otherwise an exact already-existing C reservation
prevents the retry from reaching its action. `Access::with_content`, scope
validation and readonly image scanning can retain their actual private/pin
checks; generic Lease and ContentScope authorization must not be widened.
Later retained file/chunk copying also needs the export-specific reader rather
than its present ordinary lease stream. This only covers the original owner's
retained access; reopening after owner/pin loss remains explicit recovery work.

Keep ordinary `Lease`, `ContentScope` and strict Provider wrappers unchanged.
Introduce an export-only context combining B's authenticated retained groups
with exactly one active target derived from actual B/C Staging rows, pinned C
FORMAT/database/owner, complete required manifests and validated metadata floor.
All fields remain private; detached descriptive inputs grant no physical access.

The validator must classify all retained groups and their Published debit
equality, plus only C's exact reservation/installation group. It must reject
unknown reservations, exact journals, C effects, legacy installations and
unrelated active targets. Validate C's exact Initializing registry, operation,
owner, quota, and absence of a protection root before the appropriate phase.

Three current fences need specialized interpretation, not removal:

- `OrdinarySourceInputs::require_family` uses strict retained admission and
  rejects an active unretained C reservation.
- `provider_import/content::validate_reservation_only` rejects every exact
  installation, including legitimate retained B rows.
- `exact_content/sql::validate_installations_inner` rejects other reservation IDs
  and enumerates all exact rows rather than just the active C group.

The Installing extension should use a closed alternative in the same complete
admitted catalog walk. Factor the active-group validation kernel from
`exact_content/sql.rs`, keeping the strict Provider wrapper unchanged. An
export-only `ExactBinding::validate_export_installations` receives the SAME
charged-chunk and charged-manifest sets populated by all retained Published
groups. It verifies C's actual journal phases, canonical projections, cursors,
inodes, indexed/resident pieces and exact remaining/debit equality. The final
all-reservation classification and global usage remain mandatory; filtering to
C without those checks would omit unknown or doubly charged groups.

Installing prospective journal capacity differs from ReserveOnly:
`global_records - current_C_records + complete_required_C <= 100000`.
Each C journal pays its own 8192-byte prepare charge and its own canonical
manifest column, even when physical CAS objects are already resident. Global
usage includes CAS chunks, CAS manifest payloads, sweep, every exact journal's
prepare/manifest metadata and all remaining reservations. Physical objects must
not be debited twice across retained and active groups.

There is also a Windows sharing adaptation before installing with retained CAS
pins. `open_file` requests DELETE; the immutable B object handles allow READ
sharing only. Existing CAS-only identity/read opens in exact-content `spool.rs`
and `publish.rs` must use `open_readonly_file`. Keep rename rights on staging
sources and keep the immutable B pins. This is a distinct physical adjustment,
not a reason to weaken the complete catalog validator or drop source protections.

The future ordinary Installing `ExactCatalog` adapter borrows actual B/C owners,
source image/closure, target and CAS pins. Its callback reauthenticates those
inputs and the full retained-plus-active catalog around each action; byte I/O
stays outside catalog scopes. Existing prepare/piece/finish/publish operations
can then be reused with current-image or exact retained byte producers. None of
this Installing work is implemented or qualified by the ReserveOnly slice.

Retain global inventory bounds and total family accounting. Share charged
manifest/chunk sets between retained and active groups so duplicated debit cannot
pass. A target WHERE clause alone is insufficient. ReserveOnly permits retained
B journals but no C progress; Installing admits only C's typed progress.

## Managed-only source bytes and exact installations

`OrdinaryExportImage::revalidate` scans checkout files under the existing scope
without entering the family catalog. The accesses needing the export policy are
retained manifest lookup and full/chunk historical streams. A private managed
`with_export_source` callback can provide an exact source reader while preserving
the original owner, SQL snapshot, ContentScope and image discipline.

Compare exact B private mappings and retained manifests, never a family-wide
FileId match or C mapping. Read canonical manifests under the export catalog
gate, then close that scope before byte I/O while retaining physical family
pins. Reuse immutable CAS/chunk/FileId checks from `shared/content.rs`.

Implement the existing `ExactCatalog` interface for ordinary C, with genuine
source/destination revalidation and the dedicated family policy. Reuse
prepare/piece/produce/finish/publish. Current chunks come from immutable B image
pins; historical chunks come from the exact export source reader. Missing
historical representations must be copied, not treated as Provider-only errors.

## Required evidence

First prove authentic C8 copied history including nonempty restore rows, positive
close/reopen and no-write retry. Then prove real B/C Staging and one C reservation
with B retained rows unchanged and unknown groups refused. Finally install a
dirty nonresident current representation and an inherited exact representation,
verify bytes, debit, retry and source checks. These precede checkout staging,
Ready/Published, independent C admission and C operation without A/B.
