# C13 integration recipes — prepared only, not run

These are acceptance recipes for ROOT after integration. The proposed eight
`c13_v2_*` DATA tests exercise the new owner/codec; they do not stand in for any
native recipe below. Reuse the existing ordinary conversion, admission, capture,
prepared RestoreOrdinary and close-fault fixtures. Do not rerun unchanged r94/r96
recipes just to qualify these additions. Use a new retained binary/source binding.

## R1 — mixed preservation and exact ownership

Extend the existing managed conversion fixture with observed writable edit,
creation and deletion; an unknown real file; a changed observed readonly file;
a formerly writable captured edit revoked by the fresh observation; and an
already accepted deletion whose effective base is Absent, also revoked. Include
the case of a deleted captured creation and a fresh writable absence already
satisfying an accepted deletion. Preserve source snapshot/capture payload bytes,
all source inodes and contents and the exact prior family state as witnesses.

Hash the entire real ExportCheckpoint with the complete adapter; use that image
digest when constructing the source import prefix and its retained closure.
Normalize against the genuine whole-scope authority observation, then derive the
closed owner and immutable manifest union. Use derive_reconciled_data to bind the
new immutable plan to that exact owner/observation, companion ID and quota. Supply two manifests of one FileId
(different chunking), including a historical mapping and a native representation.

Before effects, bind the existing reservation to the entire union and metadata
envelope. Install every exact representation through its owned reader, protect
source recovery mappings and destination roots, then persist the same new header
and scalar rows at source and destination before either companion receipt FK.
Do not enlarge the durable reservation if a missing representation is discovered.

Expected: checkout and its Capture contain only authorized work relative to the
fresh snapshot. Unknown/readonly/revoked content is available outside checkout
through the retained companion CAS identities. Every accepted deletion reference
roundtrips the original Capture digest/change/preimage; satisfied deletions remain
in the header and never produce None->None Capture changes. New mappings preserve
historical FileId-PK choices, while both exact representations are protected.
Receipt/header, scalar rows, provenance, mapping rows, claims and logical budget
must match on fresh strict reads. Source content and original history are intact.

## R2 — provider-free ordinary lifecycle

Starting from R1 Ready after all checks, stop/drop the Provider and all retained
provider objects. Open the destination through normal ProjectionStore::open with
the ordinary host/profile and no callbacks/network. Read/status the authorized
namespace, capture a further authorized edit with destination identity, and use
the existing supported prepared RestoreOrdinary route. Fresh strict history and
companion reads must succeed after each operation. Companion-only paths must be
absent from checkout/Capture before and after restore; their original contents,
deletion intents, preimages and unresolved-work report stay available and owned.

## R3 — interruptions at protection and private commit ACK

Use existing deterministic hooks at (a) destination complete-union protection
positive close, before Ready, and (b) private Ready commit returned, before ACK.
Record the actual hook phase and durable state rather than assuming a close
ordinal. Explicitly drop the old holders; reopen through the existing recovery
reader. An unready destination must not be admitted; recovery may resume only
with established owned capabilities. Replay must not duplicate source/destination
headers, mappings, claims or receipts. Conflict, uncertain close or lack of an
owned resume capability must leave data and source intact. Positive replay must
validate source and destination companion rows independently of receipt presence.

## R4 — real preservation/authority/codec failures

Use a missing exact historical representation, a corrupt recovery file/chunk,
a refused companion writer/positive-close, and insufficient *original* budget.
Also change the genuine retained epoch or whole-scope authority observation after
hashing. Each case must refuse before Ready, preserve source and unresolved bytes,
and retain the causal error. No cache hit may bypass authority revalidation.

Corrupt header schemaVersion to an unsupported version, duplicate a JSON field,
alter accepted Capture/path/base/snapshot provenance, remove or add a scalar row,
and change an existing mapping to another ManifestId of the same FileId. Require
typed strict refusal with no writer before validation. Open an authentic v2
artifact with the old v1 reader and require explicit incompatibility. Exercise
the unchanged 64KiB header bound; do not truncate intents or switch to v1.

## R5 — inherited/re-export closure

Convert/re-export the R1 ordinary9 destination, then the ordinary10 descendant.
Include an original provider8 v1 companion and the new ordinary9/10 v2 artifact.
New source imports must independently verify old receipt ancestry and each
artifact's *own* source snapshot/Capture, not current effective paths. Compare
original canonical payloads, bases, mappings and source/destination claims
byte-for-byte. Companions remain excluded from the current checkout/Capture.
Both representations of a shared FileId survive. Tampering any inherited row,
header, origin interval, mapping or claim blocks the outgoing destination.

## Integration gates still missing from this bundle

R1–R5 cannot pass merely by applying this proposal. Wire the new complete adapter
and owner into planning/reservation/installation and publication. Extend terminal
Ready, ordinary reopen/catalogue and inherited normalization as listed in
handoff.json. In particular the existing legacy image/plan/Ready guards remain;
they deliberately prevent activating a half-integrated protocol. ROOT owns
compilation, independent review, runtime acceptance and any commit.
