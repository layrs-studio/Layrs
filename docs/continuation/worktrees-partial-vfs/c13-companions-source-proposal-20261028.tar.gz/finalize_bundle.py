"""Text/diff/hash checks only. Never writes outside this proposal bundle."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

ROOT = Path("D:/Layrs/layrs")
OUT = Path("D:/Layrs/tmp/c13-companions-source-proposal")
EXPECTED_HEAD = "6b1f5632bd7f6092226d57e3c813033a82bcfc98"
PROVIDER = "crates/layrs-store-local/src/projection/provider/"
DOC = "docs/plans/worktrees-partial-vfs-convergence.md"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.run(["git", "-C", str(ROOT), *args], check=True, capture_output=True).stdout


def normalized(data):
    return data.decode("utf-8").replace("\r\n", "\n")


def write_json(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


head = git("rev-parse", "HEAD").decode().strip()
assert head == EXPECTED_HEAD, "source HEAD changed; do not silently rebase this bundle"
entries = []
patches = []
for output in sorted((OUT / "files").rglob("*")):
    if not output.is_file():
        continue
    relative = output.relative_to(OUT / "files").as_posix()
    assert relative.startswith(PROVIDER) or relative == DOC, relative
    source = ROOT / relative
    before = source.read_bytes() if source.exists() else b""
    after = output.read_bytes()
    assert before != after, "unchanged project file copied: " + relative
    assert all(not line.rstrip("\r\n").endswith((" ", "\t")) for line in normalized(after).splitlines(keepends=True)), relative
    old_lines = normalized(before).splitlines(keepends=True)
    new_lines = normalized(after).splitlines(keepends=True)
    chunk = "".join(difflib.unified_diff(old_lines, new_lines,
        fromfile="a/" + relative if source.exists() else "/dev/null", tofile="b/" + relative, n=3))
    assert chunk, relative
    patches.append("diff --git a/" + relative + " b/" + relative + "\n"
        + ("new file mode 100644\n" if not source.exists() else "") + chunk)
    head_bytes = git("show", EXPECTED_HEAD + ":" + relative) if source.exists() else None
    if head_bytes is not None:
        assert normalized(head_bytes) == normalized(before), "base differs from requested HEAD: " + relative
    entries.append({
        "path": relative,
        "kind": "modified" if source.exists() else "new",
        "base_sha256": sha(before) if source.exists() else None,
        "base_bytes": len(before) if source.exists() else None,
        "base_head_blob_sha256": sha(head_bytes) if head_bytes is not None else None,
        "output": output.relative_to(OUT).as_posix(),
        "output_sha256": sha(after),
        "output_bytes": len(after),
        "added_lines": sum(line.startswith("+") and not line.startswith("+++") for line in chunk.splitlines()),
        "removed_lines": sum(line.startswith("-") and not line.startswith("---") for line in chunk.splitlines()),
    })

patch = "".join(patches).encode("utf-8")
(OUT / "proposal.patch").write_bytes(patch)

# Independent in-memory hunk reconstruction: no git apply, checkout or fixture.
sections = patch.decode().split("diff --git ")[1:]
assert len(sections) == len(entries)
for section, entry in zip(sections, entries):
    original = normalized((ROOT / entry["path"]).read_bytes()).splitlines(keepends=True) if entry["kind"] == "modified" else []
    reconstructed = []
    position = 0
    lines = section.splitlines(keepends=True)
    index = next(i for i, line in enumerate(lines) if line.startswith("@@ "))
    while index < len(lines):
        header = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", lines[index])
        assert header, lines[index]
        start = int(header.group(1)) - (1 if int(header.group(1)) else 0)
        reconstructed.extend(original[position:start])
        position = start
        index += 1
        old_count = new_count = 0
        while index < len(lines) and not lines[index].startswith("@@ "):
            line = lines[index]
            assert line[0] in " +-", line
            if line[0] in " -":
                assert position < len(original) and original[position] == line[1:], entry["path"]
                position += 1
                old_count += 1
            if line[0] in " +":
                reconstructed.append(line[1:])
                new_count += 1
            index += 1
        assert old_count == int(header.group(2) or 1)
        assert new_count == int(header.group(4) or 1)
    reconstructed.extend(original[position:])
    assert "".join(reconstructed) == normalized((OUT / entry["output"]).read_bytes()), entry["path"]

assert len(entries) == 17
assert sum(e["kind"] == "new" for e in entries) == 6
tests = (OUT / "files" / PROVIDER / "transition_reconcile/tests/companions.rs").read_text()
assert tests.count("#[test]") == 8
assert not any(part == ".git" for file in OUT.rglob("*") for part in file.relative_to(OUT).parts)
assert not (OUT / "Cargo.toml").exists()
assert not (OUT / "files/Cargo.toml").exists()
for relative, guard in [
    ("bootstrap/preparation/activation/managed_image.rs", "managed image contains recovery-only paths"),
    ("bootstrap/preparation/activation/managed_plan.rs", "fresh != source.initial()"),
]:
    proposed = OUT / "files" / PROVIDER / relative
    actual = proposed.read_text() if proposed.exists() else (ROOT / PROVIDER / relative).read_text()
    assert guard in actual, "legacy guard accidentally removed"

dependencies = []
for relative in [
    "docs/plans/worktrees-partial-vfs-resume-2026-10-28.md",
    PROVIDER + "schema.rs",
    PROVIDER + "records/import.rs",
    PROVIDER + "bootstrap/preparation/activation/managed_plan.rs",
    PROVIDER + "bootstrap/preparation/activation/managed_content/exact.rs",
    PROVIDER + "transition_sql/publication.rs",
]:
    if any(entry["path"] == relative for entry in entries):
        continue
    data = (ROOT / relative).read_bytes()
    dependencies.append({"path": relative, "sha256": sha(data), "bytes": len(data), "modified": False})

manifest = {
    "schema": "layrs.c13-source-proposal-manifest.v1",
    "source_root": str(ROOT), "source_head": head,
    "proposal_root": str(OUT), "checkout": False,
    "patch": {"path": "proposal.patch", "sha256": sha(patch), "bytes": len(patch),
        "line_endings": "LF canonical text diff; base/output hashes identify exact physical bytes"},
    "files": entries, "read_only_dependency_pins": dependencies,
}
write_json("manifest.sha256.json", manifest)

checks = {
    "rustfmt": {"status": "passed", "files": 16, "command": "rustfmt --edition 2024 --config skip_children=true,style_edition=2021 <16 proposed .rs files>"},
    "rustfmt_check": {"status": "passed", "files": 16, "command": "rustfmt --check --edition 2024 --config skip_children=true,style_edition=2021 <16 proposed .rs files>"},
    "hunk_reconstruction": "passed for all 17 files, entirely in memory",
    "ownership_paths": "passed; provider/ and the single owned plan document only",
    "base_head_binding": "passed; all modified bases match requested HEAD after line-ending normalization",
    "main_source_hash_recheck": "passed; final read matches manifest base SHA256",
    "legacy_guards": "present; not removed as a substitute for complete integration",
    "no_placeholders": "no TODO, todo!, unimplemented! or unresolved provider_catalog_id reference in proposed Rust",
    "trailing_whitespace": "passed",
    "source_defined_test_recipes": 8,
    "cargo_build_test_sql_native_network_install_git_mutation": "not run",
    "fixture_open_process_profile_host_activation": "not performed",
    "independent_review": "not performed; implementation self-review only",
}
write_json("checks.json", checks)

handoff = {
    "schema": "layrs.c13-source-proposal-handoff.v1",
    "status": "partial_source_proposal_not_c13_complete",
    "agent": "C13 implementation sub-agent, source only, no delegation",
    "source_head": head, "main_source_modified": False,
    "bundle_is_checkout": False, "files": entries,
    "manifest": {"path": "manifest.sha256.json", "sha256": sha((OUT / "manifest.sha256.json").read_bytes())},
    "patch": manifest["patch"], "checks": checks,
    "implemented_in_proposal": [
        "Companion-aware immutable managed plan adapter derive_reconciled_data binds the closed owner to its exact source/fresh observation/authority DATA, builds placement and authorized Capture, commits companion ID and rowsets, includes the full manifest union and verifies the same prospective quota. Legacy active callers remain unchanged, passing no companion owner to the shared kernel.",
        "Versioned canonical companion-v2 header with durable sorted accepted-Capture and satisfied-deletion intent payloads and exact preserved companion representation references (including alternate manifests of one FileId) in the existing SQL header BLOB; unchanged 64KiB maximum.",
        "Strict v1/v2 dispatch wired into import_validation/scoped.rs. v1 payloads, domains, DDL and row codecs remain unchanged. Unknown/duplicate/unknown-field/noncanonical input refuses.",
        "Autonomous scoped v2 historical validation: exact original snapshot, accepted Capture origin interval/digest/change, effective absence, preimage mapping, satisfied authorized absence and receipt observation. This validator needs no Provider object or native byte reader.",
        "Closed OwnedCompanionData::derive calls the existing reconcile itself; it has no constructor accepting an arbitrary recovery Vec. It derives canonical header/scalar projections, overlay, authorized checkout files, sticky mappings, complete exact manifest union, metadata floor and prospective quota.",
        "Source/destination transaction-only insert/readback primitives for the same canonical new rows, exact existing-row replay, exact cardinality and prerequisite source mappings. They never insert receipts, commit, open/close databases or grant authority.",
        "Verbatim inherited-v1/v2 normalization and payload copying into the owner, receipt-variant dispatch and strict destination equality validation; current paths are not synthesized from inherited companions. Incoming header metadata is included in the existing aggregate bound.",
        "VerifiedCompleteManagedImage physical adapter alongside legacy plan: retained complete ExportCheckpoint, full immutable FileId/chunk verification, native hashing including unknown/readonly/relocated work, Windows native mode=false per capture/scan semantics, full rehash/revalidation, exact file/chunk copying from recovery-only image entries.",
        "CompleteSourceImageData separates checkpoint borrow and native lifetime, enabling real short-lived complete-image normalization while the adapter retains its mutable checkpoint.",
        "Eight new DATA regression recipes and five detailed ROOT integration scenarios, plus proposed convergence-plan clarification. No recipe was run."
    ],
    "interfaces": [
        {"path": PROVIDER + "bootstrap/preparation/activation/managed_plan.rs", "entry": "bootstrap::derive_reconciled_data(prefix, owner, observation, destination, parent pins, nonce, transaction)", "limit": "Immutable DATA adapter at fixed selection; no source/writer/reservation/Ready capability. Existing active derive/rederive paths are intentionally not redirected before installation/publication/readers are integrated."},
        {"path": PROVIDER + "bootstrap/preparation/activation/managed_image/complete.rs", "entry": "plan -> VerifiedCompleteManagedImage; digest, reconcile, current_path, copy_exact_file/chunk, revalidate", "limit": "Provider8 physical adapter only; separate publication-aware and Ordinary9/10 physical adapters still required"},
        {"path": PROVIDER + "transition_reconcile/companions.rs", "entry": "OwnedCompanionData::derive(source, complete_image, observation, exact_manifests, metadata_without_companions, optional_capture_provider_proof, cancel)", "limit": "DATA only. Provider catalog is extracted only from the matching retained capture proof. Ordinary inputs require no provider proof. Incoming normalization accepts explicit CompanionHeaderRef::V1/V2 and retains the original canonical payload; existing constructor callers must adapt their header references."},
        {"path": PROVIDER + "transition_reconcile/companions/sql.rs", "entry": "OwnedCompanionData::{insert_new_rows,require_new_rows,require_inherited_rows}", "limit": "Borrowed existing transaction and independently held writer/read gates required. Caller must insert/acquire exact source mappings and source/destination protection first, perform rollback/positive close/strict fresh read, then publish receipt."},
        {"path": PROVIDER + "records/companion_v2.rs", "entry": "CompanionHeaderRecord::decode; CompanionHeaderV2::{require_prefix,require_receipt,validate_rows}", "limit": "Codec validity is not source authenticity, authority, available content, protection or Ready."},
    ],
    "codec_decisions": {
        "v1": "Untouched; inherited v1 must remain byte-for-byte. Never decode a v2 header as v1.",
        "v2_storage": "Same header BLOB and existing scalar-table layouts. Sorted intent provenance and exact preserved representation references are physically persisted in header.payload, included in its v2 digest. No new table/DDL or private schema bump is proposed.",
        "accepted_deletion": "Existing deletion scalar layout/row commitment is reused as an original-preimage projection; only the enclosing v2 header grants it accepted-Capture semantics. v1 effective-base validation is not relaxed. Full accepted provenance in the header is required and scoped validation resolves the exact original patch/path/snapshot/mapping before accepting effective Absent.",
        "satisfied_deletion": "Stored solely in canonical header intents, with source effective base OR exact accepted-Capture provenance, destination generation/digest. No None->None Capture and no fake present effective base.",
        "ordinary9_10": "Explicit v2 sourcePrivateSchema support; require_prefix delegates to existing strict admitted-source binding validation. v1 remains 6/7/8 only.",
        "compatibility": "Old strict v1 header decoder refuses v2; new scoped reader dispatches both. Active Ready/reopen guards remain, so this bundle cannot create an activated incompatible state. Full old-reader qualification remains R4.",
        "bounds": "Existing 64KiB header maximum, 100k file/deletion/intent counts, existing per-file/aggregate image/metadata limits and managed_budget::quota. Headers too large refuse before persistence; no spill/truncation or durable reservation growth.",
        "root_choice_if_larger_intent_sets_needed": "Accept the unchanged bounded v2 header for this tranche, or commission a separately versioned per-intent payload table/private-schema migration with coordinated readers. Do not simply raise header or reservation limits."
    },
    "unfinished_exactly": [
        {"id": "U1", "files": ["bootstrap/preparation/activation/managed_plan.rs", "managed_content/ready_data.rs", "managed_content/exact.rs"], "work": "Wire the complete image and derive_reconciled_data adapters into live plan rederivation, source checkpoint digest production and reservation metadata. The proposed new adapter already builds fresh placement/authorized Capture and binds companion ID/rowsets, exact union and same quota, but active derive/rederive callers still use their strict legacy path with no owner. Retain actual whole-scope authority through every boundary; DATA equality alone is insufficient."},
        {"id": "U2", "files": ["bootstrap/preparation/activation/managed_content.rs", "bootstrap/preparation/activation/managed_content/exact.rs", "projection/shared exact-content/protection owners"], "work": "Use complete image exact copying for recovery files and existing separately owned readers for historical/fresh bases/preimages. Install/protect full union at source and destination, including every inherited v2 preserved representation; bind both required retention/metadata claims before receipts. No existing active installer or family ownership engine is rewired in this proposal."},
        {"id": "U3", "files": ["transition_sql/publication.rs", "managed source/destination publication writers"], "work": "Invoke new source AND destination row persistence/readback before FK receipt insertion. Add source mappings through authorized owners, account their protections and both receipts before effects, preserve rollback, positive close and fresh strict read. Helpers alone do not make source publication valid."},
        {"id": "U4", "files": ["managed_content/ready_data.rs", "managed_export/ready_data.rs", "managed_ready_reopen/ordinary_private_ready.rs", "projection/shared admitted catalogue terminal validators"], "work": "Replace every empty-companion guard only with exact authenticated owner/row/provenance/budget/mapping/claim validation, reading preserved representation references from v2 headers rather than collapsing them to FileId-PK mappings. Prove authorized checkout validity and all companion preservation before Ready. Active guards intentionally remain."},
        {"id": "U5", "files": ["transition_reconcile/source.rs", "managed_export ordinary source/export adapters"], "work": "Wire the proposed v1/v2 inherited normalization and owned copying into live Ordinary9/10 exports; adapt any new InheritedCompanionData constructors to CompanionHeaderRef rather than a v1-only header reference. The generic source kernel, scoped validator and owner now retain both variants and re-union exact persisted companion representations even after the live image disappears, but live re-export remains blocked by legacy plan/export guards. Existing Ordinary9/10 physical normalization and publication-aware Provider paths need matching complete-image adapters."},
        {"id": "U6", "files": ["ordinary admission/autonomy/capture/RestoreOrdinary integration points"], "work": "Feed autonomous scoped v2 validation through normal open/offline lifecycle and reports. Prove stopProvider/open/capture/preparedRestore and explicit unresolved companion reporting. Current helper is source code for historical validation, not evidence that ProjectionStore::open supports the new end-to-end state."},
        {"id": "U7", "files": ["ROOT-INTEGRATION-RECIPES.md"], "work": "Compile/typecheck the proposed source, integrate meaningful native recipes into retained runner, independently review integrated changes and run R1-R5 including interruption/failure/re-export. No runtime acceptance or release claim is made."}
    ],
    "outside_logical_ownership_dependencies": [
        "Normal ProjectionStore::open, ordinary Capture/Restore and conversion provenance callers outside provider/shared may need narrow integration changes; ROOT must own/coordinate these, not silently infer they work.",
        "If ROOT chooses larger independently stored intention payloads, private schema/version/fingerprint dispatch outside these modules must be coordinated. This bundle proposes no such migration.",
        "New complete image and immutable plan adapters are reexported through bootstrap/preparation/activation.rs and bootstrap.rs, both in owned provider scope; no runtime driver is redirected.",
        "No changes to layrs-vfs, native checkpoint implementation, host/process profile, current fixture, r94 runner, r96 recipes or running processes."
    ],
    "root_required_recipes": ["eight c13_v2_* DATA tests (new; not run)", "R1 mixed preservation/exact ownership", "R2 stopProvider/open/capture/preparedRestore", "R3 after-protection and private-commit-before-ACK interruptions", "R4 preservation/authority/codec failures source intact", "R5 inherited/re-export original payloads/bases/mappings/claims"],
    "integration_instructions": "Do not apply wholesale as a Ready-capable feature. First require the exact base SHA256 for every modified path and absence of every new path; preserve other edits. Review proposal.patch and integrate the 17 files under ROOT ownership. Resolve U1-U7 before any C13 completion claim. This is a bundle, not a checkout; do not run Cargo in it.",
}
write_json("handoff.json", handoff)

# Re-read all original source files after artifact production. No fixture walk,
# native call, test, SQL, git mutation or project-source write is performed.
for entry in entries:
    source = ROOT / entry["path"]
    assert (sha(source.read_bytes()) if source.exists() else None) == entry["base_sha256"], entry["path"]
assert git("rev-parse", "HEAD").decode().strip() == EXPECTED_HEAD
lines = []
for artifact in sorted(OUT.rglob("*")):
    if artifact.is_file() and artifact.name != "SHA256SUMS":
        lines.append(sha(artifact.read_bytes()) + "  " + artifact.relative_to(OUT).as_posix())
(OUT / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"status": handoff["status"], "files": len(entries), "new": sum(e["kind"] == "new" for e in entries),
    "added_lines": sum(e["added_lines"] for e in entries), "removed_lines": sum(e["removed_lines"] for e in entries),
    "patch_sha256": sha(patch), "handoff_sha256": sha((OUT / "handoff.json").read_bytes())}))
