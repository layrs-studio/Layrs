//! Additional source-only recipes. Reuse the existing DATA fixture and kernel;
//! these tests have NOT been compiled or executed by the C13 implementer.
use super::super::companions::OwnedCompanionData;
use super::*;
use crate::projection::provider::records::companion_v2::{
    CompanionHeaderRecord, CompanionHeaderV2, CompanionIntentV2,
};

fn derive(
    data: &Data,
    observed: &TransitionObservationData,
    files: &[ImageFileData<'_>],
    deleted: &[RepoPath],
    manifests: &[FileManifest],
) -> Result<OwnedCompanionData> {
    let source =
        source::from_test_data(data.input(), &data.captures, &data.mappings, &[], observed)?;
    let image = image::from_test_inventory(&source, files, deleted)?;
    OwnedCompanionData::derive(&source, &image, observed, manifests, 0, None, None)
}

#[test]
fn c13_v2_accepted_deletion_roundtrip_retains_payload_and_preimage() {
    let data = Data::new(true);
    let observed = data.observation(true);
    let readme = p("README.md");
    let files = [ImageFileData {
        path: &readme,
        manifest: &data.readme,
        executable: Some(false),
    }];
    let owned = derive(
        &data,
        &observed,
        &files,
        &[p("new.txt")],
        &[data.readme.clone(), data.a.clone()],
    )
    .unwrap();
    assert!(owned.overlay().is_empty());
    assert_eq!(owned.authorized_files().len(), 1);
    let header = owned.header().unwrap();
    assert_eq!(header.deletion_count, 1);
    let CompanionIntentV2::RecoveryAcceptedDeletion {
        accepted, reason, ..
    } = &header.intents[0]
    else {
        panic!("accepted deletion was flattened into an effective-file row");
    };
    assert_eq!(*reason, CompanionReason::RevokedRights);
    assert_eq!(accepted.change, data.captures[0].changes[0]);
    assert_eq!(accepted.capture_digest, data.captures[0].digest);
    assert_eq!(accepted.preimage_manifest_id, *data.a.id());
    let payload = header.encode().unwrap();
    let inherited = CompanionHeaderRecord::decode(&payload).unwrap();
    assert_eq!(inherited.as_ref().encode().unwrap(), payload);
    assert_eq!(
        inherited.as_ref().digest().unwrap(),
        header.digest().unwrap()
    );
    assert_eq!(inherited.as_ref().columns().deletion_count, 1);
    assert_eq!(CompanionHeaderV2::decode(&payload).unwrap(), *header);
    assert!(matches!(
        CompanionHeaderRecord::decode(&payload).unwrap(),
        CompanionHeaderRecord::V2(_)
    ));
    assert!(ProviderCompanionHeaderRecord::decode(&payload).is_err());
    assert!(owned.source_mappings().contains_key(data.a.file_id()));
}

#[test]
fn c13_v2_satisfied_captured_creation_is_durable_without_none_none_capture() {
    let data = Data::new(false);
    let observed = data.observation(false);
    let readme = p("README.md");
    let owned = derive(
        &data,
        &observed,
        &[ImageFileData {
            path: &readme,
            manifest: &data.readme,
            executable: Some(false),
        }],
        &[],
        &[data.readme.clone(), data.a.clone()],
    )
    .unwrap();
    assert!(owned.overlay().is_empty());
    let header = owned.header().unwrap();
    assert_eq!(header.deletion_count, 0);
    let CompanionIntentV2::SatisfiedDeletion {
        path,
        source_effective_base,
        accepted,
        ..
    } = &header.intents[0]
    else {
        panic!("satisfied intent lost");
    };
    assert_eq!(*path, p("new.txt"));
    assert_eq!(
        source_effective_base.as_ref().unwrap().file_id,
        *data.a.file_id()
    );
    assert!(accepted.is_none());
    let encoded = header.encode().unwrap();
    assert_eq!(CompanionHeaderV2::decode(&encoded).unwrap(), *header);
    assert!(owned.metadata_bytes() >= 2 * encoded.len() as u64);
}

#[test]
fn c13_v2_satisfied_accepted_deletion_keeps_original_capture_reference() {
    let data = Data::new(true);
    let mut fresh = data.snapshot.clone();
    fresh.observed_authorization_epoch += 1;
    let entry = fresh
        .entries
        .iter_mut()
        .find(|e| e.path == p("new.txt"))
        .unwrap();
    entry.target = None;
    entry.state = EntryState::Absent;
    let policy = fresh.observed_policy_set_id.clone();
    let epoch = fresh.observed_authorization_epoch;
    let observed = TransitionObservationData::normalize(
        data.input(),
        data.prefix.destination_identity.clone(),
        8,
        fresh,
        data.selected.clone(),
        vec![ProviderSourceDescriptor {
            path: p("README.md"),
            manifest: data.readme.clone(),
        }],
        ObservationCoverageData::default(),
        AuthorityObservationData::ReobservedExpandedScope {
            policy_set_id: policy,
            authorization_epoch: epoch,
        },
        None,
    )
    .unwrap();
    let readme = p("README.md");
    let owned = derive(
        &data,
        &observed,
        &[ImageFileData {
            path: &readme,
            manifest: &data.readme,
            executable: Some(false),
        }],
        &[p("new.txt")],
        &[data.readme.clone(), data.a.clone()],
    )
    .unwrap();
    assert!(owned.overlay().is_empty());
    let header = owned.header().unwrap();
    let CompanionIntentV2::SatisfiedDeletion {
        source_effective_base,
        accepted,
        ..
    } = &header.intents[0]
    else {
        panic!("accepted satisfied intent lost");
    };
    assert!(source_effective_base.is_none());
    assert_eq!(
        accepted.as_ref().unwrap().change,
        data.captures[0].changes[0]
    );
    assert_eq!(
        CompanionHeaderV2::decode(&header.encode().unwrap()).unwrap(),
        *header
    );
}

fn readonly_data() -> Data {
    let mut data = Data::new(false);
    data.snapshot
        .entries
        .iter_mut()
        .find(|e| e.path == p("README.md"))
        .unwrap()
        .writable = false;
    let digest = database::digest(7, Some(PARENT), &data.snapshot.canonical_bytes().unwrap());
    data.captures[0].projection_digest = digest.clone();
    data.captures[0].digest = data.captures[0].computed_digest().unwrap();
    let ImportSource::Ordinary { version, .. } = &mut data.prefix.source else {
        unreachable!()
    };
    version.snapshot_digest = digest.clone();
    version.selection_digest = database::digest(
        7,
        Some(&digest),
        &selection::encode(&data.selected).unwrap(),
    );
    version.capture_head = Some(data.captures[0].digest.clone());
    data
}

#[test]
fn c13_v2_mixed_authorized_unknown_readonly_are_separate_and_budgeted() {
    let data = readonly_data();
    let observed = data.observation(false);
    let readme = p("README.md");
    let created = p("new.txt");
    let unknown = p("unknown.txt");
    let files = [
        ImageFileData {
            path: &readme,
            manifest: &data.b,
            executable: Some(false),
        },
        ImageFileData {
            path: &created,
            manifest: &data.a,
            executable: Some(false),
        },
        ImageFileData {
            path: &unknown,
            manifest: &data.b,
            executable: Some(false),
        },
    ];
    let supplied = [data.readme.clone(), data.a.clone(), data.b.clone()];
    let owned = derive(&data, &observed, &files, &[], &supplied).unwrap();
    assert_eq!(owned.overlay().len(), 1);
    assert_eq!(owned.overlay()[0].path, created);
    assert_eq!(owned.header().unwrap().file_count, 2);
    let paths = owned
        .authorized_files()
        .iter()
        .map(|f| f.path.clone())
        .collect::<Vec<_>>();
    assert_eq!(paths, vec![readme.clone(), created]);
    assert_eq!(owned.authorized_files()[0].file_id, *data.readme.file_id());
    assert!(owned.source_mappings().contains_key(data.b.file_id()));
    assert_eq!(owned.manifests().len(), 3); // shared recovery FileId stored once
    let expected = crate::projection::provider::managed_budget::quota(
        owned.manifests(),
        owned.authorized_files().iter().map(|f| f.bytes),
        owned.metadata_bytes(),
    )
    .unwrap();
    assert_eq!(owned.quota_bytes(), expected);
    assert!(derive(&data, &observed, &files, &[], &supplied[..2]).is_err());
    let mut extra = supplied.to_vec();
    extra.push(manifest(b"unengaged bytes", true));
    assert!(derive(&data, &observed, &files, &[], &extra).is_err());
}

#[test]
fn c13_v2_two_manifests_same_fileid_are_both_retained() {
    let data = Data::new(false);
    let observed = data.observation(true);
    let alternate = manifest(b"captured creation A", true);
    assert_eq!(alternate.file_id(), data.a.file_id());
    assert_ne!(alternate.id(), data.a.id());
    let readme = p("README.md");
    let created = p("new.txt");
    let owned = derive(
        &data,
        &observed,
        &[
            ImageFileData {
                path: &readme,
                manifest: &data.readme,
                executable: Some(false),
            },
            ImageFileData {
                path: &created,
                manifest: &alternate,
                executable: Some(false),
            },
        ],
        &[],
        &[data.readme.clone(), data.a.clone(), alternate.clone()],
    )
    .unwrap();
    assert_eq!(
        owned
            .representations()
            .iter()
            .filter(|r| r.file_id == *data.a.file_id())
            .count(),
        2
    );
    assert!(owned.manifests().iter().any(|m| m.id() == alternate.id()));
    assert!(owned.manifests().iter().any(|m| m.id() == data.a.id()));
    assert_eq!(owned.header().unwrap().preserved_representations.len(), 2);
    assert!(owned
        .header()
        .unwrap()
        .preserved_representations
        .iter()
        .any(|r| r.manifest_id == *alternate.id()));
}

#[test]
fn c13_v2_inherited_payload_keeps_alternate_representation_after_image_disappears() {
    let data = Data::new(false);
    let observed = data.observation(true);
    let alternate = manifest(b"captured creation A", true);
    let readme = p("README.md");
    let created = p("new.txt");
    let previous = derive(
        &data,
        &observed,
        &[
            ImageFileData {
                path: &readme,
                manifest: &data.readme,
                executable: Some(false),
            },
            ImageFileData {
                path: &created,
                manifest: &alternate,
                executable: Some(false),
            },
        ],
        &[],
        &[data.readme.clone(), data.a.clone(), alternate.clone()],
    )
    .unwrap();
    let persisted =
        CompanionHeaderRecord::decode(&previous.header().unwrap().encode().unwrap()).unwrap();
    let rows = [ProviderCompanionFileRecord {
        schema_version: "layrs.projection-provider-companion-file.v1".into(),
        path: created,
        file_id: data.a.file_id().clone(),
        bytes: data.a.byte_length(),
        executable: false,
        manifest_id: data.a.id().clone(),
        base_file_id: Some(data.a.file_id().clone()),
        base_executable: Some(false),
        reason: CompanionReason::RevokedRights,
    }];
    persisted.as_ref().validate_rows(&rows, &[]).unwrap();
    let inherited = [InheritedCompanionData {
        header: persisted.as_ref(),
        files: &rows,
        deletions: &[],
    }];
    // DATA fixture only: this proves union preservation, not receipt/SQL
    // authentication. Production normalize() still requires the closed import.
    let current = data.observation(false);
    let source = source::from_test_data(
        data.input(),
        &data.captures,
        &data.mappings,
        &inherited,
        &current,
    )
    .unwrap();
    let image = image::from_test_inventory(
        &source,
        &[ImageFileData {
            path: &readme,
            manifest: &data.readme,
            executable: Some(false),
        }],
        &[],
    )
    .unwrap();
    let result = reconcile(&source, &image, &current, None).unwrap();
    assert!(result
        .representations
        .iter()
        .any(|r| r.file_id == *data.a.file_id() && r.manifest_id == *alternate.id()));
    assert_eq!(
        persisted.as_ref().encode().unwrap(),
        previous.header().unwrap().encode().unwrap()
    );
}

#[test]
fn c13_v2_unsupported_duplicate_version_and_tampered_intent_refuse() {
    let data = Data::new(true);
    let observed = data.observation(true);
    let readme = p("README.md");
    let owned = derive(
        &data,
        &observed,
        &[ImageFileData {
            path: &readme,
            manifest: &data.readme,
            executable: Some(false),
        }],
        &[p("new.txt")],
        &[data.readme.clone(), data.a.clone()],
    )
    .unwrap();
    let bytes = owned.header().unwrap().encode().unwrap();
    let text = String::from_utf8(bytes.clone()).unwrap();
    assert!(
        CompanionHeaderRecord::decode(text.replace("companion.v2", "companion.v3").as_bytes())
            .is_err()
    );
    let duplicated = text.replacen(
        '{',
        "{\"schemaVersion\":\"layrs.projection-provider-companion.v2\",",
        1,
    );
    assert!(CompanionHeaderRecord::decode(duplicated.as_bytes()).is_err());
    let mut header = CompanionHeaderV2::decode(&bytes).unwrap();
    let CompanionIntentV2::RecoveryAcceptedDeletion { accepted, .. } = &mut header.intents[0]
    else {
        unreachable!()
    };
    accepted.source_snapshot_digest = "f".repeat(64);
    assert!(header.encode().is_err());
    header.schema_version = "layrs.projection-provider-companion.v3".into();
    assert!(header.encode().is_err());
}

#[test]
fn c13_v2_reconciled_plan_binds_companions_overlay_union_and_original_budget() {
    let mut data = readonly_data();
    data.prefix.kind = ProviderImportKind::ManagedOrdinary;
    let observed = data.observation(false);
    let readme = p("README.md");
    let created = p("new.txt");
    let unknown = p("unknown.txt");
    let owned = derive(
        &data,
        &observed,
        &[
            ImageFileData {
                path: &readme,
                manifest: &data.b,
                executable: Some(false),
            },
            ImageFileData {
                path: &created,
                manifest: &data.a,
                executable: Some(false),
            },
            ImageFileData {
                path: &unknown,
                manifest: &data.b,
                executable: Some(false),
            },
        ],
        &[],
        &[data.readme.clone(), data.a.clone(), data.b.clone()],
    )
    .unwrap();
    let plan = crate::projection::provider::bootstrap::derive_reconciled_data(
        &data.prefix,
        &owned,
        &observed,
        data.prefix.destination_identity.clone(),
        "C:\\c13-parent",
        "fs:v1:1111111111111111:2222222222222222",
        "00000000000000000000000000000001",
        "00000000000000000000000000000002",
    )
    .unwrap();
    assert_eq!(
        plan.plan.companion_id.as_deref(),
        Some(owned.header().unwrap().digest().unwrap().as_str())
    );
    assert_eq!(plan.plan.companion_files.count, 2);
    assert_eq!(plan.plan.protected_manifests.count, 3);
    assert_eq!(plan.capture.changes, owned.overlay());
    assert_eq!(plan.quota_bytes, owned.quota_bytes());
    assert_eq!(
        plan.plan.observation.snapshot_digest,
        observed.binding().snapshot_digest
    );
    assert!(plan.placement.entries.iter().all(|e| e.path != unknown));
    let changed = data.observation(true);
    assert!(
        crate::projection::provider::bootstrap::derive_reconciled_data(
            &data.prefix,
            &owned,
            &changed,
            data.prefix.destination_identity.clone(),
            "C:\\c13-parent",
            "fs:v1:1111111111111111:2222222222222222",
            "00000000000000000000000000000001",
            "00000000000000000000000000000002"
        )
        .is_err()
    );
}
