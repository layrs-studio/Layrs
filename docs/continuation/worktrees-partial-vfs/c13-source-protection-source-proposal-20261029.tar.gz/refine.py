from build_bundle import *
p=P+'provider/bootstrap/preparation/activation/managed_content.rs'
edit(p,'mod source_publication;','mod source_publication;\nmod source_protection;')
p=P+'provider/bootstrap/preparation/activation/managed_content/protection.rs'
edit(p,'use super::*;','use super::*;\npub(super) use super::source_protection::ManagedSourceCompanionProtection;')
p=P+'provider/bootstrap/preparation/activation/managed_image/complete.rs'
edit(p,"impl VerifiedCompleteManagedImage<'_, '_> {",'''impl VerifiedCompleteManagedImage<'_, '_> {
    /// Pin/namespace-only check after C Ready; never rehashes source bytes.
    pub(in crate::projection::provider) fn require_retained(
        &self, root:&layrs_vfs::ProviderRootGuard, digest:&str, cancel:&Cancellation,
    )->Result<()> {
        cancel.check()?;
        if digest!=self.retained.digest() {return Err(invalid("complete retained source image digest differs"));}
        self.retained.require_owner(root,self.retained.source,self.retained.activated)?;
        cancel.check()?;Ok(())
    }
''')
# Wire descriptor input into the ACTUAL complete source reconcile call.
# Borrowed source can be enriched at construction; fail clearly if omitted.
edit(p,'        self.revalidate(cancel)?;\n        let (_, _, fixed, activated, _) = proof.import_parts();', '''        self.revalidate(cancel)?;
        source.require_provider_descriptors(proof,Some(cancel))?;
        let (_, _, fixed, activated, _) = proof.import_parts();''')
p=P+'provider/transition_reconcile/source.rs'
needle='    pub(in crate::projection::provider) fn normalize('
edit(p,needle,'''    pub(in crate::projection::provider) fn require_provider_descriptors(
        &self,proof:&super::super::validation::PrivateActiveCaptureValidation,cancel:Option<&Cancellation>,
    )->Result<()> {
        for descriptor in proof.active.source.descriptors() {
            cancellation::check(cancel)?;
            if self.original_descriptors.get(&descriptor.file_id)!=Some(&(descriptor.manifest_id.clone(),descriptor.bytes)) {
                return Err(invalid("complete source requires with_provider_descriptors before reconcile"));
            }
        }
        Ok(())
    }
'''+needle)
p=P+'provider/bootstrap/preparation/activation/managed_content/source_publication.rs'
edit(p,'''        let floor =
            source_metadata_floor(owned.metadata_floor(), &ready, &published, owned.receipt())?;''','''        let floor = if source_protection.is_some() {
            // B is independently funded; C's remaining/debit equation is kept
            // exact. Its existing immutable metadata estimate stays unchanged.
            owned.metadata_floor()
        } else {
            source_metadata_floor(owned.metadata_floor(), &ready, &published, owned.receipt())?
        };''')
p=P+'shared/source_companion.rs'
edit(p,'let c_reserved:bool=c.query_row("SELECT EXISTS(SELECT 1 FROM reservations WHERE id=?1)",[&self.binding.destination.reservation],|r|r.get(0))?;', '''let c_reserved:bool=c.query_row("SELECT EXISTS(SELECT 1 FROM reservations WHERE id=?1)",[&self.binding.destination.reservation],|r|r.get(0))?;
        if c_reserved && !c.query_row("SELECT EXISTS(SELECT 1 FROM reservations WHERE id=?1 AND owner=?2 AND operation=?1 AND remaining<=?3)",params![self.binding.destination.reservation,self.binding.destination.owner.as_str(),self.binding.destination.quota_bytes],|r|r.get::<_,bool>(0))? {
            return Err(invalid("source companion C reservation is foreign or increased"));
        }''')
edit(p,'if root.binding.companion_id!=group.companion_id', 'if root.private_bytes!=group.metadata_bytes || root.binding.companion_id!=group.companion_id')
p=P+'provider/validation/source_companion.rs'
edit(p,'    pub(in crate::projection) root: String,','    pub(in crate::projection) root: String,\n    pub(in crate::projection) metadata_bytes:u64,')
edit(p,'        proof.groups.push(OutgoingCompanion', '''        // Reproduce the exact independently funded B envelope from actual
        // bounded SQL, including reused mappings and both terminal intents.
        let mut row_bytes:u64=c.query_row("SELECT length(payload)+length(CAST(id AS BLOB))+16+length(CAST(files_digest AS BLOB))+length(CAST(deletions_digest AS BLOB)) FROM projection_provider_companions WHERE id=?1",[id],|r|r.get(0))?;
        let fb:u64=c.query_row("SELECT coalesce(sum(length(CAST(companion_id AS BLOB))+length(CAST(path AS BLOB))+length(CAST(file_id AS BLOB))+8+8+length(CAST(manifest_id AS BLOB))+coalesce(length(CAST(base_file_id AS BLOB)),0)+(CASE WHEN base_executable IS NULL THEN 0 ELSE 8 END)+length(CAST(reason AS BLOB))+length(CAST(digest AS BLOB))),0) FROM projection_provider_companion_files WHERE companion_id=?1",[id],|r|r.get(0))?;
        let db:u64=c.query_row("SELECT coalesce(sum(length(CAST(companion_id AS BLOB))+length(CAST(path AS BLOB))+length(CAST(base_file_id AS BLOB))+8+coalesce(length(CAST(base_manifest_id AS BLOB)),0)+length(CAST(reason AS BLOB))+length(CAST(digest AS BLOB))),0) FROM projection_provider_companion_deletions WHERE companion_id=?1",[id],|r|r.get(0))?;
        row_bytes=row_bytes.checked_add(fb).and_then(|n|n.checked_add(db)).ok_or_else(||invalid("source private envelope aggregate overflow"))?;
        for (f,(m,_)) in &content {row_bytes=row_bytes.checked_add(f.len() as u64+m.len() as u64+8).ok_or_else(||invalid("source private mapping envelope overflow"))?;}
        let mut ready=ProviderTransitionIntentRecord::decode(&intent.encode()?)?;
        ready.state=TransitionState::Ready;
        let mut published=ProviderTransitionIntentRecord::decode(&intent.encode()?)?;
        published.state=TransitionState::Published;
        let metadata_bytes=super::super::source_companion::publication_bytes(row_bytes,&ready,&published,receipt)?;
        proof.groups.push(OutgoingCompanion''')
edit(p,'content, root });','content, root, metadata_bytes });')
p=P+'provider/bootstrap/preparation/activation/managed_content/source_protection.rs'
edit(p,'let read_published=||self.source_companion_snapshot(data,cancel,|full| {', '''let read_published=|| {
            let _locks=self.held.family.locks(&self.held.artifacts.allocation.format.identity.worktree_id,true)?;
            self.source_companion_snapshot(data,cancel,|full| {''')
edit(p,'        });\n        let before=read_published()?;', '        })\n        };\n        let before=read_published()?;')
p='docs/plans/worktrees-partial-vfs-convergence.md'
edit(p,'''Before either source or destination receipt references a new companion, persist
and validate the same canonical header/scalar rows at both sides, with the exact
source mappings and independently owned retention/protection. Reserve the full''','''Protect B and C before either new companion receipt. Each database persists
and validates the identical new canonical header/scalar rows before THAT
database's own receipt. B rows remain absent until genuine C private AND family
Ready, then B mappings/rows/claim/receipt and Staging->Ready commit atomically.
B has a separate fixed metadata reservation and canonical exact retention root;
C alone installs/debits the union. Capture and C reservations cannot fund B.
Reserve the full''')
