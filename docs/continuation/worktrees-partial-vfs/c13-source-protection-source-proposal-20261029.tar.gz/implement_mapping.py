from build_bundle import *
p=P+'provider/transition_reconcile/source.rs'
edit(p, '    latest: Option<&\'a CapturedPatch>,', '''    latest: Option<&'a CapturedPatch>,
    pub(super) original_descriptors: BTreeMap<FileId, (FileManifestId, u64)>,''')
edit(p, '            latest,\n            _closure:', '            latest,\n            original_descriptors: BTreeMap::new(),\n            _closure:')
edit(p, '        latest,\n        _closure:', '        latest,\n        original_descriptors: BTreeMap::new(),\n        _closure:')
edit(p, '''        self.mappings
            .get(file)''', '''        self.mappings
            .get(file)
            .or_else(|| self.original_descriptors.get(file))''')
needle="impl<'a> ReconcileSourceData<'a> {"
edit(p,needle,needle+'''
    /// Original descriptor input is the FULL validated source proof, never an
    /// arbitrary FileId->alternate map. Frozen mappings always take precedence.
    /// Call after normalize and before image/reconcile/OwnedCompanion derivation.
    pub(in crate::projection::provider) fn with_provider_descriptors(
        mut self, proof: &super::super::validation::PrivateActiveCaptureValidation,
        cancel: Option<&Cancellation>,
    ) -> Result<Self> {
        let ImportSource::Provider { identity, version, .. } = &self.input.prefix.source else {
            return Err(invalid("original descriptor proof requires provider source"));
        };
        if identity != &proof.active.source.commitment().identity
            || proof.active.activated.generation != version.generation
            || proof.active.activated.digest != version.snapshot_digest
            || proof.active.activated.snapshot != *self.input.snapshot
            || proof.capture.patches.len() as u64 != version.capture_count
            || proof.capture.patches.last().map(|p| p.digest.as_str()) != version.capture_head.as_deref()
        { return Err(invalid("original descriptor full source proof differs")); }
        for descriptor in proof.active.source.descriptors() {
            cancellation::check(cancel)?;
            descriptor.encode()?;
            let value = (descriptor.manifest_id.clone(), descriptor.bytes);
            if self.original_descriptors.insert(descriptor.file_id.clone(), value.clone())
                .is_some_and(|old| old != value) {
                return Err(invalid("original source has ambiguous descriptor representation"));
            }
        }
        Ok(self)
    }
''')
p=P+'provider/transition_reconcile.rs'
edit(p,'    for file in image.entries.values().filter_map(|e| e.file.as_ref()) {','''    for (file, (manifest, bytes)) in &source.original_descriptors {
        add_representation(&mut union, RepresentationData {
            file_id: file.clone(), manifest_id: manifest.clone(), bytes: *bytes,
        })?;
    }
    for file in image.entries.values().filter_map(|e| e.file.as_ref()) {''')
p=P+'provider/transition_reconcile/companions.rs'
edit(p,'''/// Both source and destination must persist the *same* new header/scalar rows
/// before either receipt references its FK. Inherited artifacts remain verbatim;
/// they are not recovery paths of the current checkout or Capture.''','''/// Protect BOTH owners before either new receipt. Each database persists the
/// identical new header/scalars before ITS OWN receipt. B rows remain absent
/// until genuine C private+family Ready. Inherited artifacts remain verbatim.''')
edit(p,'pub(in crate::projection::provider) struct OwnedCompanionData','pub(in crate::projection) struct OwnedCompanionData')
edit(p,'''        if let Some(header) = &header {
            for intent in &header.intents {''','''        if let Some(header) = &header {
            for intent in &header.intents {
                if let Some(a) = intent.accepted() {
                    needed.insert(a.change.expected.as_ref().ok_or_else(|| invalid("owned preimage absent"))?.file_id.clone());
                }''')
edit(p,'''                .cloned()
                .or_else(|| {
                    files''','''                .cloned()
                .or_else(|| source.original_descriptors.get(&file).cloned())
                .or_else(|| {
                    // A freshly created recovery file may supply its own exact
                    // scalar. A source base/preimage must resolve above.
                    files''')
# Only permit scalar fallback for IDs which aren't source preimages.
edit(p,'        for file in needed {','''        let mut preimages = BTreeSet::new();
        for row in &files { preimages.extend(row.base_file_id.iter().cloned()); }
        for row in &deletions { preimages.insert(row.base_file_id.clone()); }
        if let Some(h) = &header { for intent in &h.intents {
            if let Some(a) = intent.accepted() { preimages.insert(a.change.expected.as_ref().ok_or_else(|| invalid("owned accepted preimage missing"))?.file_id.clone()); }
            if let CompanionIntentV2::SatisfiedDeletion { source_effective_base: Some(base), .. } = intent { preimages.insert(base.file_id.clone()); }
        }}
        for file in needed {
            if preimages.contains(&file) && !source.mappings.contains_key(&file) && !source.original_descriptors.contains_key(&file) {
                return Err(invalid("owned original descriptor input absent before effects"));
            }''')
# Source budget must be reproducible independently of C's plan quota.
edit(p,'    pub(in crate::projection::provider) fn header(&self)', '''    pub(in crate::projection::provider) fn source_row_bytes(&self) -> Result<u64> {
        let mut total = match &self.header {
            Some(h) => sql_bytes(&h.encode()?, &self.files, &self.deletions)?,
            None => 0,
        };
        for (file, (manifest, _)) in &self.source_mappings {
            total = managed_budget::add_metadata(total, file.as_str().len() as u64 + manifest.as_str().len() as u64 + 8)?;
        }
        Ok(total)
    }
    pub(in crate::projection::provider) fn header(&self)''')
# original descriptors may need to be unioned before reconcile. Existing old derive
# keeps strict refusal if the caller did not supply that concrete source input.
p=P+'provider/transition_reconcile/companions/sql.rs'
edit(p,'impl OwnedCompanionData {','''impl OwnedCompanionData {
    /// Source-only primitive; the caller has already authenticated the frozen
    /// prefix and absent outgoing rowset, and will insert claim/receipt/CAS in
    /// THIS transaction. Existing mappings are compared byte-for-byte.
    pub(in crate::projection::provider) fn insert_source_mappings_and_rows(
        &self, c: &Connection, cancel: Option<&Cancellation>,
    ) -> Result<()> {
        require_transaction(c)?;
        for (file, (manifest, bytes)) in &self.source_mappings {
            cancellation::check(cancel)?;
            let values = vec![Value::Text(file.to_string()), Value::Text(manifest.to_string()), integer(*bytes)?];
            insert_exact(c, "INSERT INTO projection_content(file_id,manifest_id,bytes) VALUES(?1,?2,?3)",
                "SELECT file_id,manifest_id,bytes FROM projection_content WHERE file_id=?1", &values[..1], &values)?;
        }
        self.insert_new_rows(c, cancel)
    }
''')
