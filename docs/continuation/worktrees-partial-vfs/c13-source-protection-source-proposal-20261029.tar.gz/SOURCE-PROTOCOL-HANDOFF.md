# B source companion protocol — cumulative source proposal

Base HEAD: `6b1f5632bd7f6092226d57e3c813033a82bcfc98`, branch
`feature/worktrees-partial-vfs`. Input bundle manifest:
`0033a04e8831186c79b0d3b8581e1d36d1f5083a56470194c0a672ff4186835c`.
All 23 input paths remain represented. Main sources and the input bundle were
read only. No checkout/worktree, Git mutation, client/server edit, delegation,
build, test, SQL/native/network/fixture/process inspection or recipe execution
was performed. Python source generation/packaging and rustfmt were used only
inside this artifact directory. No interaction with runner99703/r98.

This implements concrete source-side SQL, family, retention and writer paths.
It is **not an end-to-end C13/C14 conversion**. Current companion C Ready and
legacy managed lease constructors still refuse new companions. Compilation,
independent review and runtime qualification remain pending. The investigation
report was used as architecture evidence, not treated as a typecheck/review.

## Implemented interfaces and call sites

* `provider/validation.rs::private_active_publication_with_source` now uses
  internal bounded capture-history DATA, validates transitions/receipts and
  outgoing companion provenance, then produces final capture-only content and
  claims. No incomplete `PrivateCaptureProof` is supplied as authority.
  `validation/source_companion.rs` owns the full outgoing proof and exact
  reference union. Scalar/header codecs and original incoming lineage/effective
  base are reused through `import_validation::validate_outgoing_companion`.
* `PrivateCaptureMutationValidation::{from_publication,require_same_state,
  require_same_publications}` retain/compare the complete companion proof.
  `from_publication` matches ROOT's helper. Publication mode digest now includes
  the companion proof with a versioned hash domain and streamed bounded
  encoding. Frozen incoming prefix selectors remain unchanged.
* `capture_state::read_live`, capture SQL family validation, content catalog
  context and active range checks use the complete source-aware family proof.
  Strict old capture readers still reject companions. No changes to ROOT's new
  session source-view module or its exports are included.
* `shared/source_companion.rs::{SourceCompanionBinding,
  SourceCompanionProtection,SourceCompanionFamilyContext}` implement B's fixed
  reservation, canonical versioned root, global capacity, exact replay,
  membership and recovery classification. B and C owner/database identities
  bind independently to plan/prefix/companion and complete U. No B exact journal
  is allowed. Capture and companion groups coexist only after each exact group
  is proved; unknown groups are never excluded by a namespace filter alone.
* `FamilyAccess::validate_source_companion_catalog` classifies the complete
  source group alongside B capture. `ImportContentInputs::source_context` and
  `ImportSourceInputs::provider_with_companions` carry it through actual C
  reservation/install/protection/publication validators. New companion C
  effects require a separately fixed B envelope; C receipt/family publication
  additionally requires B's complete protected root. Legacy input construction
  keeps `None` and fails closed on a new companion plan.
* `shared/admitted_catalog.rs`, its `terminal_ready` interpreter and
  `destination_ready/autonomous/family_read.rs` explicitly recognize the new
  retained namespace. They validate canonical B retention DATA and consistency
  with the independently proved C group, without opening B or substituting B
  protection for C admission. C's debit/charged-manifest/chunk sets are unchanged.
* `ReconcileSourceData::{provider_descriptor_view,with_provider_descriptors}`
  derive originals from a full source proof, rather than an arbitrary alternate
  manifest. `VerifiedCompleteManagedImage::reconcile` now calls this concrete
  adapter. Frozen mappings win; missing original preimages refuse without a
  validated descriptor. Accepted and satisfied-deletion dependencies are
  included. Current v2 still requires actual sticky mappings.
* `provider/source_companion.rs::SourceCompanionPublication::derive` freezes
  source row projection, actual planned receipt, both valid terminal intents
  and B envelope before effects. `planned_receipt` is real immutable-plan DATA,
  not a fake valid sizing record or a C Ready assertion.
* `managed_content/source_protection.rs` adds the concrete
  `ManagedImportLease::{reserve_source_companion,protect_source_companion}`
  adapters, reexported through existing `protection.rs`. Protection authenticates
  actual complete C Published installation SQL, C's exact root, full CAS bytes
  outside SQL scopes, C member identity and the retained complete source image.
  Its result keeps CAS/image/source owner pins alive through later publication.
* Existing `publish_source` retains its strict guard. The named
  `publish_source_companion` passes the physical source witness through actual
  source contexts, admissions, prospective/fresh reads and both commits.
  `transition_sql::apply_source_publication_with_companion` inserts missing
  exact mappings, complete rows, claim, receipt and Staging->Ready CAS in the
  same FK-enabled transaction. The old low-level entry still refuses new
  companions. All failures require rollback; the managed writer performs it
  before nested C/family closes, then observes the source close. Failed close
  immediately returns, with no fresh SQL/FS probe or next effect.

## Ordering and recovery

The corrected contract is **protect B and C before either new receipt; identical
companion rows in each database before THAT database's own receipt**. B's new
rows remain absent until C private AND family Ready are genuinely proved.
Outgoing receipts never become incoming ancestry. The prior contradictory
comment and convergence-plan text were corrected.

1. Freeze closed rows, plan, U, exact C binding and Q_B/Q_C. Reserve fixed B
   metadata using global usage plus BOTH absent reservations. Close and read
   back positively. No source private companion SQL exists yet.
2. C alone performs exact installation/debit and protects U. Authenticate actual
   Published SQL and CAS; insert B root and all members atomically with its
   fixed reservation retained. Observe closes and complete fresh readback.
3. C writes its identical mappings/header/scalars before its own receipt, then
   proves private and family Ready through its future companion-capable path.
   B remains Staging with no new companion rows/claim/receipt.
4. B's one transaction inserts mappings/header/scalars/claim/receipt and CASes
   Staging->Ready; full prospective validation, commit, positive nested closes,
   positive writer close, complete fresh B/C/family read follow in that order.
5. Existing separate Ready->Published commit/close/readback remains. Terminal
   Published replay opens no writer. Same-phase row/root replay mutates nothing.

`SourceCompanionRecovery` distinguishes absent, reservation-only, root-only,
C Ready/B Staging, B Ready and Published. The actual source publication family
path invokes it only AFTER both genuine C Ready scopes. Classification is DATA,
never permission to manufacture those scopes. Pending source recovery requires
the exact closed root input and actual Staging plan; ordinary autonomous scans
refuse unprovable reservation-only groups. No adoption, cleanup, quota release,
capture reservation borrowing or reclamation-fence change is introduced.

## Deterministic funding proof

Logical envelope units match existing normalized SQL accounting: INTEGER=8,
NULL=0, TEXT=UTF-8 bytes, BLOB=actual encoded length. This makes no claim about
SQLite page/index/WAL or physical disk allocation geometry.

`M_B` charges the exact bounded header/scalars, every required sticky mapping
(including reused mappings conservatively), one complete claim, the actual
receipt's five SQL columns and BOTH valid terminal intent projections. It is
rederived from actual validated SQL by the private interpreter, compared to the
root's committed private envelope by family validation, and bounded at 1GiB.

Let `R19` be the counted serialization size of the exact root frame excluding
only `reservationBytes`, plus that field's literal JSON framing and 19 maximum
SQLite-integer decimal digits. The sizing frame has no invented quota value or
valid protocol record. Count it before cloning/encoding the aggregate root;
require `R19 <= 16MiB`. The actual canonical root must fit `R19`.

`Q_B = M_B + R19 + normalized root scalar columns + 135*|U| + normalized
reservation columns`.

135 is the exact 64-byte root key plus 71-byte manifest key per root index row.
Root/reservation owner, DB and operation costs use actual bounded text lengths.
All additions/multiplications are checked against bounds/SQLite integer range.
Tiny artifacts reserve their actual deterministic envelope, without a fixed
16MiB minimum. Fixed `remaining_B == Q_B` is required everywhere. Any changed or
underfunded persisted reservation refuses rather than growing it. C's unchanged
quota and exact `Q_C - durable debit == remaining_C` equation remain mandatory.
Global usage counts all remaining reservations and exact journal charges;
neither C's conservative metadata estimate nor capture quota is B funding.

## Remaining narrow integration — not implemented or claimed

* The actual C constructors `managed_content/ready_data.rs::OwnedReadyData::new`,
  `destination_ready/data.rs` and autonomous Ready still refuse a newly local
  companion plan. A genuine new constructor must take closed companion rows,
  unchanged sticky mappings/full U, protected B context and complete authorized
  C observation/placement/checkout, then independently validate them. No guard
  was removed and no fake `ManagedPrivateReady`/`ManagedFamilyReady` was made.
* `ManagedImportLease::open/with_authority_metadata` still own the legacy
  `VerifiedManagedImage` and legacy rederivation. The real driver must retain
  the complete image plus ROOT's source anchor and genuine remote observation,
  derive the reconciled plan, and supply `ImportContentInputs.source_context =
  Some(SourceCompanionFamilyContext { publication, pending: Some(B_root) })`
  in EACH C callback. The shared validator path exists; the legacy lease keeps
  `None`. New companion plans refuse before C effects until that concrete lease
  integration is supplied. `publish_source_companion` still reaches the genuine
  old C Ready rederivation/validation seam and therefore cannot bypass it.
* Restart cannot reconstruct the retained original native image/remote owner
  from root DATA. Reservation/root recovery and B Ready/Published completion
  require retained owners or a separately implemented explicit recovery owner.
  The current physical source protection opener requires actual B Staging.
* Full remote observation acquisition and ordinary9/10 outgoing adapters remain
  separate. Source removal/release/GC needs its own future protocol. Existing
  provider/admitted reclamation fences stay unchanged.

See `SOURCE-PROTOCOL-RECIPES.md`, `handoff.json`, `rustfmt-results.json` and the
manifest. Own source self-review and rustfmt are not independent verification,
typechecking, runtime evidence or final acceptance.
