from build_bundle import *

# Stage history DATA separately. No partial PrivateCaptureProof escapes.
p=P+'provider/validation/capture.rs'
s=read(p)
start=s.index('pub(super) fn validate(')
body=s.index('    super::super::cancellation::check(cancel)?;',start)
cut=s.index('    let mut content = Vec::new();',body)
tail=s[cut:s.index('\n#[cfg(test)]',cut)]
history=s[body:cut]+'''    Ok(CaptureHistoryData { transactions, receipts, patches, staged_files, stage_by_id })
}
'''
sig=s[start:body]
hist_sig=sig.replace('fn validate(', 'fn read_history(').replace('Result<PrivateCaptureProof>', 'Result<CaptureHistoryData>')
data='''/// Internal bounded DATA, never a capture or publication authority.
pub(super) struct CaptureHistoryData {
    pub(super) transactions: Vec<ProviderCaptureTransactionRecord>,
    receipts: Vec<ProviderCaptureReceiptRecord>,
    pub(super) patches: Vec<CapturedPatch>,
    staged_files: BTreeMap<String, u64>,
    stage_by_id: BTreeMap<String, (String, BTreeSet<String>)>,
}
'''
wrapper=sig+'''    let history = read_history(c, allocation, mount, activation, activated, cancel)?;
    finish(c, history, &super::source_companion::OutgoingReferences::default(), cancel)
}

pub(super) fn finish(
    c: &Connection,
    history: CaptureHistoryData,
    outgoing: &super::source_companion::OutgoingReferences,
    cancel: Option<&Cancellation>,
) -> Result<PrivateCaptureProof> {
    let CaptureHistoryData { transactions, receipts, patches, staged_files, stage_by_id } = history;
'''
tail=tail.replace('''            if bytes > MAX_CAPTURE_FILE_BYTES || staged_files.get(&file_id) != Some(&bytes) {''','''            if !staged_files.contains_key(&file_id) {
                if outgoing.content.get(&file_id) != Some(&(manifest_id, bytes)) {
                    return Err(invalid("provider content has no capture or outgoing companion reference"));
                }
                continue;
            }
            if outgoing.content.get(&file_id).is_some_and(|expected| expected != &(manifest_id.clone(), bytes)) {
                return Err(invalid("shared capture/companion sticky mapping differs"));
            }
            if bytes > MAX_CAPTURE_FILE_BYTES || staged_files.get(&file_id) != Some(&bytes) {''')
tail=tail.replace('''            if kind != "provider-capture"''','''            if kind == "provider-companion" {
                if outgoing.claims.get(&root_id) != Some(&(digest, owner)) {
                    return Err(invalid("provider companion claim is unowned or differs"));
                }
                continue;
            }
            if kind != "provider-capture"''')
# Outgoing reader has already required every content/claim row it references.
write(p,s[:start]+data+hist_sig+history+'\n'+wrapper+tail+s[s.index('\n#[cfg(test)]',cut):])

# transition kernel needs only history slices; strict entry still takes full proof.
p=P+'provider/validation/transition.rs';s=read(p)
s=s.replace('''    let pending_capture = capture.transactions.iter().any''','''    let pending_capture = transactions.iter().any''')
# Find private validate_view signature only.
i=s.index('fn validate_view(');a=s[:i];b=s[i:]
b=b.replace('    capture: &PrivateCaptureProof,','''    transactions: &[crate::projection::provider::records::capture::ProviderCaptureTransactionRecord],
    patches: &[crate::projection::capture::CapturedPatch],''',1)
b=b.replace('capture.patches','patches').replace('''capture
                        .patches''','''patches''')
# every invocation is explicit history slice; no partial capture proof supplied.
a=a.replace('''        capture,
        View::''','''        &capture.transactions,
        &capture.patches,
        View::''')
write(p,a+b)
p=P+'provider/validation/transition/publication.rs'
edit(p,'    capture: &PrivateCaptureProof,','    capture: &super::super::capture::CaptureHistoryData,')
edit(p,'        capture,\n        View::Publication,','        &capture.transactions,\n        &capture.patches,\n        View::Publication,')

p=P+'provider/validation.rs'
edit(p,'mod capture;','mod capture;\npub(in crate::projection) mod source_companion;')
edit(p,'    pub(super) receipts: Vec<records::import::ProviderTransitionReceiptRecord>,\n}', '    pub(super) receipts: Vec<records::import::ProviderTransitionReceiptRecord>,\n    pub(in crate::projection) companions: source_companion::SourceCompanionPrivateProof,\n}')
edit(p,'impl PrivateCaptureMutationValidation {','''impl PrivateCaptureMutationValidation {
    pub(super) fn from_publication(full: PrivateActivePublicationValidation) -> Result<Self> {
        Ok(Self { full: full.require_no_pending_transition()? })
    }
    pub(in crate::projection) fn publication(&self) -> &PrivateActivePublicationValidation {
        &self.full
    }
''')
edit(p,'            || self.full.receipts != other.full.receipts','            || self.full.receipts != other.full.receipts\n            || self.full.companions != other.full.companions')
edit(p,'    )?\n    .require_no_pending_transition()?;\n    Ok(PrivateCaptureMutationValidation { full })','    )?;\n    PrivateCaptureMutationValidation::from_publication(full)')
edit(p,'pub(super) struct PrivateActivePublicationValidation {','pub(in crate::projection) struct PrivateActivePublicationValidation {')
s=read(p);i=s.index('    // This must precede capture::validate');e=s.index('    Ok(PrivateActivePublicationValidation {',i)
part=s[i:e].replace('let capture = capture::validate(', 'let history = capture::read_history(').replace('        &capture,','        &history,')
part+='''    let companions = source_companion::validate(c, allocation, &transitions, &receipts, cancel)?;
    let references = companions.references()?;
    let capture = capture::finish(c, history, &references, cancel)?;
'''
s=s[:i]+part+s[e:]; i=s.index('    Ok(PrivateActivePublicationValidation {');e=s.index('    })',i)
s=s[:e]+s[e:].replace('    })','        companions,\n    })',1)
s=s.replace('''            || (mode.publication() && table == "projection_provider_transition_receipts")''','''            || (mode.publication() && matches!(table,
                "projection_provider_transition_receipts" | "projection_provider_companions"
                | "projection_provider_companion_files" | "projection_provider_companion_deletions"))''')
write(p,s)

p=P+'provider/import_validation/provider_proof.rs'
edit(p,'hash.update(b"layrs-provider-import-publication-proof-v1\\0");','hash.update(b"layrs-provider-import-publication-proof-v2\\0");')
edit(p,'        hash_rows(&proof.receipts, &mut hash, cancel)?;','''        hash_rows(&proof.receipts, &mut hash, cancel)?;
        proof.companions.hash_into(&mut hash, cancel)?;''')

# New outward-only adapter reuses bounded scalar/provenance kernel; selectors unchanged.
p=P+'provider/import_validation.rs'
edit(p,'mod scoped;','mod scoped;\npub(in crate::projection::provider) use scoped::validate_outgoing_companion;')
p=P+'provider/import_validation/scoped/companions_v2.rs'
edit(p,'    cancel: Option<&Cancellation>,\n) -> CauseResult<()> {','    cancel: Option<&Cancellation>,\n) -> CauseResult<()> {\n    validate_mode(c, id, header, receipt, lineage, content_ids, catalog_ids, cancel, false)\n}\n\n#[allow(clippy::too_many_arguments)]\npub(super) fn validate_mode(\n    c: &Connection, id: &str, header: &CompanionHeaderV2,\n    receipt: &ProviderTransitionReceiptRecord, lineage: &ProvenanceIndex,\n    content_ids: &mut BTreeSet<String>, catalog_ids: &mut BTreeSet<String>,\n    cancel: Option<&Cancellation>, source_outgoing: bool,\n) -> CauseResult<()> {')
edit(p,'    let fresh = if header','    let fresh = if !source_outgoing && header')
edit(p,'            let fresh = fresh\n','''            if source_outgoing {
                // B has no C observation snapshot. The header codec binds the
                // exact observation to this receipt; private+family C Ready
                // independently prove its authorized absence at publication.
                if !source_selection.includes(path)
                    || !source.entries.iter().any(|e| &e.path == path && e.writable && e.state != EntryState::Reserved)
                { return Err(invalid("outgoing satisfied deletion source scope differs")); }
                continue;
            }
            let fresh = fresh
''')
p=P+'provider/import_validation/scoped.rs'
write(p,read(p)+'''
/// Outgoing B proof uses the original INCOMING lineage only. It never calls
/// verify_source_publication and never extends any frozen prefix selector.
pub(in crate::projection::provider) fn validate_outgoing_companion(
    c: &Connection, marker: &format::Marker, id: &str,
    header: &super::super::records::companion_v2::CompanionHeaderV2,
    receipt: &ProviderTransitionReceiptRecord, cancel: Option<&Cancellation>,
) -> CauseResult<BTreeSet<String>> {
    let lineage = super::ancestry::read_ancestry(
        c, marker, ImportDatabaseKind::Provider, &receipt.source_prefix, cancel)?;
    let mut content = BTreeSet::new();
    let mut catalogs = BTreeSet::new();
    companions_v2::validate_mode(c, id, header, receipt, &lineage,
        &mut content, &mut catalogs, cancel, true)?;
    // source-only dependencies must be included even where an earlier sticky
    // check needed no selector mutation.
    for intent in &header.intents {
        if let Some(a) = intent.accepted() {
            content.insert(a.change.expected.as_ref().ok_or_else(|| invalid("outgoing preimage absent"))?.file_id.to_string());
        }
    }
    Ok(content)
}
''')
