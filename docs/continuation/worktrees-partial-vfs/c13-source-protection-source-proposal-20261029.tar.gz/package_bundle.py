from build_bundle import *
import ast

def dump(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

def reconstruct(before,diff):
    original=before.splitlines(keepends=True); result=[]; cursor=0; active=False
    for line in diff:
        if line.startswith('@@ '):
            start=int(re.match(r'@@ -(\d+)',line).group(1));pos=max(0,start-1)
            assert pos>=cursor;result.extend(original[cursor:pos]);cursor=pos;active=True
        elif active and line[0] in ' +-':
            if line[0] in ' -':assert original[cursor]==line[1:];cursor+=1
            if line[0] in ' +':result.append(line[1:])
    result.extend(original[cursor:]);return ''.join(result)

assert sha((OLD/'manifest.sha256.json').read_bytes())==PIN
old=json.loads((OLD/'manifest.sha256.json').read_text());oldfiles={r['path']:r for r in old['files']}
assert len(oldfiles)==23
assert (MAIN/'.git/HEAD').read_text().strip()=='ref: refs/heads/feature/worktrees-partial-vfs'
assert (MAIN/'.git/refs/heads/feature/worktrees-partial-vfs').read_text().strip()==HEAD
for r in oldfiles.values():assert sha((OLD/r['output']).read_bytes())==r['output_sha256']
rows=[];patches=[];base_checks=[]
for output in sorted((OUT/'files').rglob('*')):
    if not output.is_file():continue
    path=output.relative_to(OUT/'files').as_posix()
    assert path.startswith(P+'provider/') or path.startswith(P+'shared/') or path in [P+'provider.rs',P+'shared.rs','docs/plans/worktrees-partial-vfs-convergence.md'],path
    assert not any(s in path for s in ['/layrs-client-core/','/layrs-server/','/fixtures/','session/transition_source.rs','ordinary_tests.rs','fresh_checkout_tests.rs']),path
    oid,blob=base(path)
    physical=(MAIN/path).read_bytes() if (MAIN/path).exists() else None
    assert (physical is None)==(blob is None),path
    assert blob is None or canon(physical)==canon(blob),('main source diverges from declared HEAD',path)
    if path in oldfiles:
        prior=oldfiles[path]
        assert oid==prior['base_head_git_blob'],path
        assert (None if blob is None else sha(blob))==prior['base_head_blob_sha256'],path
        assert (None if physical is None else sha(physical))==prior['base_sha256'],path
    contents=output.read_bytes();before='' if blob is None else canon(blob);after=canon(contents)
    assert after.endswith('\n'),path
    assert not any(line.rstrip()!=line for line in after.splitlines()),path
    if path.endswith('.rs'):assert not re.search(r'\bTODO\b|todo!\s*\(|unimplemented!\s*\(',after),path
    diff=list(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='/dev/null' if blob is None else 'a/'+path,tofile='b/'+path,n=3))
    assert reconstruct(before,diff)==after,path
    if diff:patches.append('diff --git a/'+path+' b/'+path+'\n'+''.join(diff))
    rows.append({'path':path,'kind':'new' if blob is None else 'modified',
        'base_sha256':None if physical is None else sha(physical),'base_bytes':None if physical is None else len(physical),
        'base_head_git_blob':oid,'base_head_blob_sha256':None if blob is None else sha(blob),
        'input_bundle_output_sha256':oldfiles.get(path,{}).get('output_sha256'),
        'output':output.relative_to(OUT).as_posix(),'output_sha256':sha(contents),'output_bytes':len(contents),
        'added_lines':sum(x.startswith('+') and not x.startswith('+++') for x in diff),
        'removed_lines':sum(x.startswith('-') and not x.startswith('---') for x in diff)})
    base_checks.append({'path':path,'head_blob_verified':True,'main_physical_sha256':None if physical is None else sha(physical)})
assert set(oldfiles)<=set(r['path'] for r in rows)
patch=''.join(patches).encode('utf-8');(OUT/'proposal.patch').write_bytes(patch)
fmt=json.loads((OUT/'rustfmt-results.json').read_text());assert fmt['format']['exit_code']==fmt['check']['exit_code']==0
assert fmt['rust_files']==sum(r['path'].endswith('.rs') for r in rows)
for script in OUT.glob('*.py'):ast.parse(script.read_text(encoding='utf-8'),filename=str(script))

manifest={'schema':'layrs.c13-source-companion-protection-source-proposal-manifest.v1','source_root':str(MAIN),
    'source_head':HEAD,'source_branch':'feature/worktrees-partial-vfs','proposal_root':str(OUT),'checkout':False,
    'input_bundle':{'root':str(OLD),'manifest_sha256':PIN,'files':23},
    'patch':{'path':'proposal.patch','sha256':sha(patch),'bytes':len(patch),'line_endings':'LF canonical hunks against exact HEAD; physical byte hashes separate'},
    'files':rows}
dump('manifest.sha256.json',manifest)
checks={'status':'SOURCE_ONLY_SELF_CHECKS','original_manifest_pin':'PASS','all_23_original_output_pins':'PASS',
    'all_23_paths_retained':'PASS','declared_HEAD_and_branch':'PASS; direct loose Git object/ref reads; no Git command',
    'base_source_hashes':'PASS for every output; original physical bases and exact HEAD blobs verified',
    'hunk_reconstruction':f'PASS for {len(rows)} outputs in memory','ownership_and_no_unrelated_checkout_tests':'PASS',
    'trailing_whitespace_and_no_TODO_stubs':'PASS','python_packaging_AST':'PASS; no recipe execution',
    'rustfmt':fmt,'base_checks':base_checks,
    'build_typecheck_tests_SQL_native_network_fixtures':'NOT_RUN by assignment','independent_verification':False}
dump('source-checks.json',checks)

interfaces=[
 {'path':'provider/validation.rs','symbols':['private_active_publication_with_source','PrivateActivePublicationValidation::capture_data','PrivateActivePublicationValidation::source_transitions','PrivateCaptureMutationValidation::from_publication','PrivateCaptureMutationValidation::require_same_publications','PrivateCaptureMutationValidation::require_same_state'],'call_sites':'capture history -> outgoing validation -> final capture-only proof; ROOT helper converges without session edits'},
 {'path':'provider/validation/source_companion.rs','symbols':['SourceCompanionPrivateProof','OutgoingCompanion','validate','preflight','hash_into'],'call_sites':'complete publication reader, exact family classifier, publication mode digest and capture equality'},
 {'path':'provider/import_validation/scoped/companions_v2.rs','symbols':['validate_mode'],'call_sites':'unchanged incoming validate wrapper plus new outgoing validator with original incoming lineage; actual C observation remains C Ready obligation'},
 {'path':'shared/source_companion.rs','symbols':['SourceCompanionBinding','SourceCompanionProtection','SourceCompanionFamilyContext','classify_source_groups','retained_namespace'],'call_sites':'B family classifier, C content/publication validators, actual retained source adapter, autonomous admitted/terminal scans'},
 {'path':'shared/provider_access.rs','symbols':['FamilyAccess::validate_source_companion_catalog'],'call_sites':['capture_state::read_live','capture_sql::family','content_catalog::validate','ranges::read','ImportSourceInputs::require_family','source retention and source publication contexts']},
 {'path':'shared/provider_import/content.rs','symbols':['ImportContentInputs::source_context','require_source_envelope'],'call_sites':'real validate_import_content/installation/protection and reservation callbacks; full source context required before new C effects'},
 {'path':'shared/provider_import/source.rs','symbols':['ImportSourceInputs::provider_with_companions'],'call_sites':'shared C base-at-member/source validation; pointer equality binds complete proof capture component'},
 {'path':'provider/transition_reconcile/source.rs','symbols':['provider_descriptor_view','with_provider_descriptors','mapping'],'call_sites':'VerifiedCompleteManagedImage::reconcile -> exact source descriptor input -> full representation union -> closed source mappings'},
 {'path':'provider/source_companion.rs','symbols':['SourceCompanionPublication::derive','planned_receipt','publication_bytes','insert','require_rows'],'call_sites':'new physical source reserve/protect and actual source SQL publication primitive'},
 {'path':'provider/bootstrap/preparation/activation/managed_content/source_protection.rs','symbols':['ManagedSourceCompanionProtection','reserve_source_companion','protect_source_companion'],'call_sites':'module wired from managed_content.rs and protection.rs; authenticates C Published SQL/CAS and retains complete source image pins'},
 {'path':'provider/bootstrap/preparation/activation/managed_content/source_publication.rs','symbols':['publish_source_companion','publish_source_scoped','with_source_publication_inputs','require_source_publication_family'],'call_sites':'actual clean admission, FK writer, retained both C Ready scopes, independent B envelope, full prospective/readback, separate terminal commits'},
 {'path':'provider/transition_sql/publication.rs','symbols':['apply_source_publication_with_companion'],'call_sites':'publish_source_scoped -> mappings/header/scalars/claim/receipt/Staging->Ready in one transaction; legacy constructor guard preserved'},
 {'path':'shared/admitted_catalog.rs + shared/admitted_catalog/terminal_ready.rs + provider/destination_ready/autonomous/family_read.rs','symbols':['retained_namespace'],'call_sites':'explicit new family namespace interpretation without B DB/native lookup; C authority and exact debit independent'},
]
recipes=['canonical_source_root_binds_both_owners_and_all_alternates_without_large_minimum','source_root_checks_bounds_before_aggregate_encoding','source_fixed_reservation_counts_b_plus_c_and_refuses_changed_remaining_without_writes']
handoff={'schema':'layrs.c13-source-companion-protocol-handoff.v1','status':'SOURCE_PROPOSAL_ONLY_NOT_END_TO_END',
    'base_head':HEAD,'input_manifest_sha256':PIN,'cumulative_files':len(rows),'rust_files':fmt['rust_files'],
    'all_23_input_outputs_represented':True,'main_repository_modified':False,'original_bundle_modified':False,'checkout_created':False,
    'implementation':'Concrete B source private/family/protection/publication modules and typed call sites; genuine new C Ready/retained driver prerequisites remain blocked',
    'architecture':'Separate fixed B metadata reservation + canonical exact root over U; C sole exact installer/debit owner; no DDL/quota/reclamation change',
    'corrected_order':'Protect B+C before either new receipt. Identical rows per database before THAT database receipt. B rows absent until genuine C private+family Ready. B rows+claim+receipt+Staging->Ready atomic; Ready->Published separate.',
    'funding':'Q_B = actual bounded source SQL envelope (reused mappings + actual receipt + both valid terminal intents) + counted root frame with 19 sizing-only reservation digits + exact normalized root/reservation/index columns. No 16MiB minimum; root maximum16MiB and private maximum1GiB. Fixed B remaining; global journal/CAS/all reservations counted. C exact equation unchanged.',
    'interfaces_and_actual_call_sites':interfaces,
    'remaining_narrow_integration':[
      {'edge':'Genuine companion-capable C Ready','missing_input_signature':'A separately validated OwnedReadyData/ManagedPrivateReady/ManagedFamilyReady constructor taking closed companion rows, complete U/sticky mappings, protected B context, genuine C fresh/placement/checkout/claim and source authority. Current OwnedReadyData::new and destination_ready guards stay strict.','consequence':'publish_source_companion cannot produce new successful C13 conversion until this real constructor exists; no Ready fabricated.'},
      {'edge':'Companion-aware retained C engine lease','missing_input_signature':'ManagedImportLease companion route retaining VerifiedCompleteManagedImage + full source publication/ROOT source anchor/remote authority and passing ImportContentInputs.source_context=Some({publication,pending:Some(B_root)}) in each C callback. Legacy open/with_authority_metadata and image rederivation remain guarded.','consequence':'Shared C source-context validators are wired and refuse new C effects without B funding; legacy callbacks retain None.'},
      {'edge':'Restart after B Ready/Published','missing_input_signature':'Retained original complete native image/source/remote owner, or future explicit authenticated recovery owner. Existing source protection opener accepts actual B Staging only.','consequence':'DATA root is not a capability; no repair/release or authority reconstruction.'},
    ],
    'ROOT_source_view_convergence':{'helper':'from_publication(full) = Ok(Self { full: full.require_no_pending_transition()? })','full_companion_equality_and_live_family_path':True,'session_transition_source_or_reexports_edited':False},
    'registered_unrun_recipes':recipes,'recipe_document':'SOURCE-PROTOCOL-RECIPES.md','native_writer_recipes':'W1-W6 authored, explicitly NOT RUNNABLE until genuine companion C Ready/retained driver exists; ACK and OS close separated',
    'checks':{'rustfmt_format_exit':fmt['format']['exit_code'],'rustfmt_check_exit':fmt['check']['exit_code'],'hashes_bases_and_patch_reconstruction':'PASS','compilation':'NOT_RUN','tests_runtime_SQL_native_network':'NOT_RUN','independent_verification':False,'self_review_only':True},
    'deliverables':['proposal.patch','files/','manifest.sha256.json','handoff.json','SOURCE-PROTOCOL-HANDOFF.md','SOURCE-PROTOCOL-RECIPES.md','source-checks.json','rustfmt-results.json']}
dump('handoff.json',handoff)
assert sha((OLD/'manifest.sha256.json').read_bytes())==PIN
print(json.dumps({'files':len(rows),'rust_files':fmt['rust_files'],'patch_sha256':sha(patch),'patch_bytes':len(patch),'manifest_sha256':sha((OUT/'manifest.sha256.json').read_bytes()),'all_23_retained':True,'base_hashes_match':True,'rustfmt':'PASS','compilation_runtime':'NOT_RUN'}))
