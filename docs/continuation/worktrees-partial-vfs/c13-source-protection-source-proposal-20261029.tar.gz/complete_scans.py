from build_bundle import *
p=P+'shared/admitted_catalog/terminal_ready.rs'
edit(p,'    let mut roots = BTreeSet::new();','''    // Classify every B companion namespace without opening B. It neither
    // supplies C authority nor participates in C's exact debit/charged sets.
    let source_groups=super::super::source_companion::retained_namespace(c,cancel)?;
    for source in &source_groups {
        let b=&source.binding.destination;
        if b.family_incarnation!=family.incarnation || b.family_root_identity!=family.root_identity
            || b.family_catalog_identity!=family.database_identity || b.family_marker_digest!=digest {
            return Err(invalid("terminal Ready source retention family differs"));
        }
        let id=super::source_destination_root_id(c,b)?;
        if id==protection.id() {
            if *b!=*binding {return Err(invalid("terminal Ready B retention names a different C binding"));}
            source.require_union(required,cancel)?;
        } else {
            let (actual,manifests,member)=read_group(c,&id,None,cancel)?;
            if actual!=*b {return Err(invalid("terminal Ready foreign B/C retention differs"));}
            source.require_union(&manifests,cancel)?;
            require_member(c,&family,marker,b,&member)?;
        }
    }
    let mut roots = BTreeSet::new();''')
p=P+'provider/destination_ready/autonomous/family_read.rs'
edit(p,'    exact.validate()?;\n    Ok(FamilyData {','''    exact.validate()?;
    // These are family retention DATA only. No historical B database/native
    // path is reopened and C's own private claim/root remains mandatory.
    for source in shared::source_companion::retained_namespace(c,cancel)? {
        let b=&source.binding.destination;
        if b.owner==exact.owner && b.transaction_id==exact.transaction_id {
            if *b!=exact {return Err(invalid("autonomous source retention C binding differs"));}
            source.require_union(&root.manifests,cancel)?;
        }
    }
    Ok(FamilyData {''')
