from build_bundle import *
p=P+'shared/admitted_catalog.rs';s=read(p)
i=s.index('            let croot=ExactProtection::new(');e=s.index('            if actual!=*b',i)
s=s[:i]+'''            let croot=source_destination_root_id(c,b)?;
            let (actual,required,member)=read_group(c,&croot,known.get(croot.as_str()).copied(),cancel)?;
            source.require_union(&required,cancel)?;
'''+s[e:]
i=s.index('\nfn read_group_required_for_source(')
s=s[:i]+'''
fn source_destination_root_id(c:&Connection,b:&crate::projection::shared::exact_content::ExactBinding)->Result<String> {
    let operation=format!("provider-import:{}",b.transaction_id);
    let n:u64=c.query_row("SELECT count(*) FROM roots WHERE operation=?1 AND owner=?2",rusqlite::params![operation,b.owner.as_str()],|r|r.get(0))?;
    if n!=1 {return Err(invalid("retained B source group lacks unique C root"));}
    Ok(c.query_row("SELECT id FROM roots WHERE operation=?1 AND owner=?2 AND length(CAST(id AS BLOB))=64",rusqlite::params![operation,b.owner.as_str()],|r|r.get(0))?)
}
''';write(p,s)
p=P+'shared/source_companion.rs'
edit(p,'    pub(in crate::projection) fn require_plan(', '''    pub(in crate::projection) fn require_union(&self,required:&[FileManifest],cancel:Option<&Cancellation>)->Result<()> {
        cancellation::check(cancel)?;
        let stored:Stored=serde_json::from_slice(&self.payload).map_err(|e|invalid(e.to_string()))?;
        let mut expected=required.iter().collect::<Vec<_>>();expected.sort_by(|a,b|a.id().cmp(b.id()));
        if stored.manifests.len()!=expected.len() || !stored.manifests.iter().zip(expected).all(|(a,b)|a==b) {
            return Err(invalid("source retention U differs from actual protected C union"));
        }Ok(())
    }
    pub(in crate::projection) fn require_plan(''')
edit(p,'        let roots:u64=c.query_row', '''        if c.query_row("SELECT EXISTS(SELECT 1 FROM exact_installations i JOIN reservations r ON r.id=i.reservation WHERE r.owner=?1)",[self.binding.source_owner.as_str()],|r|r.get::<_,bool>(0))? {
            return Err(invalid("source companion owner cannot own exact installation journals"));
        }
        let roots:u64=c.query_row''')
edit(p,'        let expected=Self::new(stored.binding,', '''        if !c.query_row("SELECT EXISTS(SELECT 1 FROM worktrees WHERE id=?1 AND database_identity=?2 AND state='ready')",params![stored.binding.source_owner.as_str(),stored.binding.source_database],|r|r.get::<_,bool>(0))? {
            return Err(invalid("retained source group B registration identity differs"));
        }
        let expected=Self::new(stored.binding,''')
p=P+'shared/provider_import/publication.rs'
edit(p,'    let ready = inputs.destination_ready;','''    let ready = inputs.destination_ready;
    if ready.plan.companion_id.is_some() {
        let context=inputs.content.source_context.as_ref().ok_or_else(||invalid("companion C Ready requires full B source context"))?;
        let root=context.pending.ok_or_else(||invalid("companion C Ready requires B fixed retention"))?;
        root.require_plan(inputs.content.allocation,inputs.content.source_staging,cancel)?;
    }''')
edit(p,'        let phase = member_phase(c, binding.owner.as_str(), cancel)?;', '''        if inputs.destination_ready.plan.companion_id.is_some() {
            let root=inputs.content.source_context.as_ref().and_then(|s|s.pending).ok_or_else(||invalid("C receipt B protection scope absent"))?;
            if root.inspect(c,cancel)?!=crate::projection::shared::source_companion::SourceCompanionPresence::Protected {
                return Err(invalid("C receipt requires B protection before either receipt"));
            }
        }
        let phase = member_phase(c, binding.owner.as_str(), cancel)?;''')
p=P+'provider/bootstrap/preparation/activation/managed_content/source_publication.rs';s=read(p)
outer='''            let result=match result {
                Err(primary) if !bare.connection().is_autocommit()=>match bare.connection().execute_batch("ROLLBACK") {
                    Ok(())=>Err(primary),Err(rollback)=>Err(Cause::Cleanup{primary:Box::new(primary),close:Box::new(rollback.into())}),
                }, other=>other,
            };
''';assert outer in s;s=s.replace(outer,'')
needle='''                    |destination_c, family_c, current| {
                        if current != before'''
assert needle in s;s=s.replace(needle,'''                    |destination_c, family_c, current| {
                        let operation=(|| {
                        if current != before''')
needle='''                        source_c.execute_batch("COMMIT")?;
                        Ok(())
                    },'''
assert needle in s;s=s.replace(needle,'''                        source_c.execute_batch("COMMIT")?;
                        Ok(())
                        })();
                        // Roll back BEFORE nested C/family scopes close. If a
                        // close itself fails, no subsequent SQL/FS probe runs.
                        match operation {
                            Err(primary) if !source_c.is_autocommit()=>match source_c.execute_batch("ROLLBACK") {
                                Ok(())=>Err(primary),Err(e)=>Err(Cause::Cleanup{primary:Box::new(primary),close:Box::new(e.into())}),
                            },other=>other,
                        }
                    },''')
write(p,s)
