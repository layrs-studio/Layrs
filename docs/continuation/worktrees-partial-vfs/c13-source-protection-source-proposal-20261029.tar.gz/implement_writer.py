from build_bundle import *
p=P+'provider.rs';edit(p,'mod transition_reconcile;', 'mod transition_reconcile;\n#[cfg(windows)]\npub(in crate::projection) mod source_companion;')
p=P+'provider/validation.rs';edit(p,'    transition::preflight_publication(c, cancel)?;','    transition::preflight_publication(c, cancel)?;\n    source_companion::preflight(c, cancel)?;')

# Named source family context, retained through concrete C catalog paths.
p=P+'shared/provider_import/content.rs'
edit(p,'    pub required: &\'a [FileManifest],', '''    pub required: &'a [FileManifest],
    pub source_context: Option<crate::projection::shared::source_companion::SourceCompanionFamilyContext<'a>>,''')
needle='#[derive(Debug, Clone, Copy, PartialEq, Eq)]\npub(in crate::projection) enum ImportContentReservation'
edit(p,needle,'''impl<'a> ImportContentInputs<'a> {
    fn source_inputs(&self)->ImportSourceInputs<'_, '_> {
        ImportSourceInputs::provider_with_companions(self.allocation,self.prepared,self.activation,self.capture,self.source_context.as_ref())
    }
}

'''+needle)
s=read(p)
s=s.replace('validate_import_base_at_member(\n            self,\n            c,\n            inputs.allocation,\n            inputs.prepared,\n            inputs.activation,\n            inputs.capture,','validate_import_base_at_member_for_source(\n            self,\n            c,\n            &inputs.source_inputs(),')
s=s.replace('validate_import_base(\n            self,\n            c,\n            inputs.allocation,\n            inputs.prepared,\n            inputs.activation,\n            inputs.capture,','validate_import_base_for_source(\n            self,\n            c,\n            &inputs.source_inputs(),')
write(p,s)
p=P+'shared/provider_import/source.rs'
edit(p,"    capture: &'p PrivateCaptureProof,\n}","    capture: &'p PrivateCaptureProof,\n    source_context: Option<&'p crate::projection::shared::source_companion::SourceCompanionFamilyContext<'p>>,\n}")
edit(p,'            capture,\n        })','            capture,\n            source_context: None,\n        })')
edit(p,'    pub(super) fn require_family(', '''    pub(super) fn provider_with_companions(
        allocation:&'p AllocationRecord, prepared:&'p PreparedRecord,
        activation:&'p ProviderActivationRecord, capture:&'p PrivateCaptureProof,
        source_context:Option<&'p crate::projection::shared::source_companion::SourceCompanionFamilyContext<'p>>,
    )->Self {
        Self::Provider(ProviderSourceInputs{allocation,prepared,activation,capture,source_context})
    }
    pub(super) fn require_family(''')
edit(p,'                if family.validate_capture_catalog(c, source.allocation, source.capture, cancel)?\n                    != ActivationRegistration::Ready','''                let phase=if let Some(context)=source.source_context {
                    if !std::ptr::eq(source.capture,&context.publication.capture) {
                        return Err(invalid("source family context discarded the complete private proof"));
                    }
                    family.validate_source_companion_catalog(c,source.allocation,context,cancel)?
                } else {family.validate_capture_catalog(c,source.allocation,source.capture,cancel)?};
                if phase != ActivationRegistration::Ready''')
p=P+'provider/bootstrap/preparation/activation/managed_content.rs';edit(p,'            required: self.manifests,','            required: self.manifests,\n            source_context: None,')

# Low-level legacy constructor keeps its guard. New concrete closed DATA input
# runs in the very same receipt+CAS transaction and full before/after reader.
p=P+'provider/transition_sql/publication.rs';s=read(p)
i=s.index('    cancellation::check(cancel)?;')
s=s[:i]+'''    if next.plan.companion_id.is_some() {
        return Err(invalid("legacy source publication requires no new companion"));
    }
    apply_source_publication_scoped(c,allocation,prepared,binding,root_id,previous,next,receipt,None,cancel)
}

pub(in crate::projection::provider) fn apply_source_publication_with_companion(
    c:&Connection, allocation:&AllocationRecord, prepared:&PreparedRecord,
    binding:&ProviderBootstrapBinding, root_id:[u8;16],
    previous:&ProviderTransitionIntentRecord, next:&ProviderTransitionIntentRecord,
    receipt:&ProviderTransitionReceiptRecord,
    companion:&crate::projection::provider::source_companion::SourceCompanionPublication<'_>,
    cancel:Option<&Cancellation>,
)->Result<SourceIntentEffect> {
    apply_source_publication_scoped(c,allocation,prepared,binding,root_id,previous,next,receipt,Some(companion),cancel)
}

fn apply_source_publication_scoped(
    c:&Connection, allocation:&AllocationRecord, prepared:&PreparedRecord,
    binding:&ProviderBootstrapBinding, root_id:[u8;16],
    previous:&ProviderTransitionIntentRecord, next:&ProviderTransitionIntentRecord,
    receipt:&ProviderTransitionReceiptRecord,
    companion:Option<&crate::projection::provider::source_companion::SourceCompanionPublication<'_>>,
    cancel:Option<&Cancellation>,
)->Result<SourceIntentEffect> {
'''+s[i:]
s=s.replace('''    if current == Some(next) {
''','''    if let Some(companion)=companion {
        let mut staging=ProviderTransitionIntentRecord::decode(&next.encode()?)?;
        staging.state=TransitionState::Staging; staging.receipt_id=None;
        companion.require(allocation,&staging,receipt,cancel)?;
    } else if next.plan.companion_id.is_some() {
        return Err(invalid("source publication companion scope absent"));
    }
    if current == Some(next) {
        if let Some(companion)=companion {companion.require_rows(c,cancel)?;}
''')
i=s.index('        let proof = PrivateActiveCaptureValidation {');e=s.index('    } else if before',i)
s=s[:i]+'''        import_validation::verify_source_publication(c,&allocation.format,&next.plan.source_prefix,
            ImportSourceReferences::Provider {allocation,prepared,activation:&before.active.activation},
            &before,match &next.plan.source_prefix.source {
                crate::projection::provider::records::import::ImportSource::Provider {version,..}=>&version.effective_image_digest,
                _=>return Err(invalid("source publication requires provider prefix")),
            },cancel)?;
'''+s[e:]
s=s.replace('''        // No orphan is adopted:''','''        if let Some(companion)=companion {companion.insert(c,cancel)?;}
        // No orphan is adopted:''')
s=s.replace('''    cancellation::check(cancel)?;
    Ok(SourceIntentEffect::Updated)''','''    if let Some(companion)=companion {companion.require_rows(c,cancel)?;}
    cancellation::check(cancel)?;
    Ok(SourceIntentEffect::Updated)''')
write(p,s)
p=P+'provider/transition_sql.rs';edit(p,'pub(super) use publication::apply_source_publication;', 'pub(super) use publication::{apply_source_publication, apply_source_publication_with_companion};')

# Thread an optional PHYSICAL source witness through every source publication
# read, clean admission, prospective validation and both separate writes.
p=P+'provider/bootstrap/preparation/activation/managed_content/source_publication.rs';s=read(p)
s=s.replace('        family: &ManagedFamilyReady<\'_, \'_>,\n        cancel:', '        family: &ManagedFamilyReady<\'_, \'_>,\n        source_protection: Option<&super::protection::ManagedSourceCompanionProtection<\'_, \'_>>,\n        cancel:')
s=s.replace('        self.require_intent()?;\n        let private', '''        self.require_intent()?;
        if self.staging.plan.companion_id.is_some() != source_protection.is_some() {
            return Err(invalid("source publication requires exact retained source companion scope"));
        }
        if let Some(source)=source_protection {source.require(self,cancel)?;}
        let private''')
s=s.replace('''                required: self.manifests,
''','''                required: self.manifests,
                source_context: Some(crate::projection::shared::source_companion::SourceCompanionFamilyContext {
                    publication:&proof,pending:source_protection.map(|p|p.data().protection()),
                }),
''')
s=s.replace('''        let binding = self.exact_binding()?;
        private.require_physical''','''        if let Some(source)=source_protection {
            source.data().require(&self.held.artifacts.allocation,self.staging,owned.receipt(),Some(cancel))?;
        }
        let binding = self.exact_binding()?;
        private.require_physical''')
# Every nested invocation has family on a separate line; callback functions
# with private argument are handled separately below.
s=s.replace('''            family,
            cancel,
''','''            family,
            source_protection,
            cancel,
''')
s=s.replace('self.with_source_publication_context(source_c, family, cancel,', 'self.with_source_publication_context(source_c, family, source_protection, cancel,')
s=s.replace('''                                    family.private_ready(),
                                    cancel,''','''                                    family.private_ready(),
                                    cancel,''')
# family SQL source class check is already performed by publication.content context.
# Add exact retained B state to the common family read helper.
s=s.replace('''        let (protected, checkout) = private.physical_parts();
        let remaining''','''        if let Some(context)=publication.content.source_context.as_ref() {
            self.held.family.validate_source_companion_catalog(family_c,&self.held.artifacts.allocation,context,Some(cancel))?;
            if let Some(root)=context.pending {
                if root.inspect(family_c,Some(cancel))? != crate::projection::shared::source_companion::SourceCompanionPresence::Protected {
                    return Err(invalid("source publication B protection absent"));
                }
            }
        }
        let (protected, checkout) = private.physical_parts();
        let remaining''')
# preserve public legacy signature, introduce named entry and one private kernel
needle='''        self.require_intent()?;
        // Deliberately no self.rehash():'''
replacement='''        if self.staging.plan.companion_id.is_some() {return Err(invalid("legacy publish_source requires no new companion"));}
        self.publish_source_scoped(family,None,close,cancel)
    }
    pub(in crate::projection::provider::bootstrap::preparation::activation) fn publish_source_companion<'p,'r,'b>(
        &mut self, family:&'p ManagedFamilyReady<'r,'b>,
        source:&super::protection::ManagedSourceCompanionProtection<'_, '_>,
        close:&mut impl WriterCloseObserver,cancel:&Cancellation,
    )->CauseResult<ManagedPublished<'p,'r,'b>> {
        self.publish_source_scoped(family,Some(source),close,cancel)
    }
    fn publish_source_scoped<'p,'r,'b>(
        &mut self, family:&'p ManagedFamilyReady<'r,'b>,
        source_protection:Option<&super::protection::ManagedSourceCompanionProtection<'_, '_>>,
        close:&mut impl WriterCloseObserver,cancel:&Cancellation,
    )->CauseResult<ManagedPublished<'p,'r,'b>> {
        self.require_intent()?;
        if let Some(source)=source_protection {source.require(self,cancel)?;}
        // Deliberately no self.rehash():'''
assert needle in s;s=s.replace(needle,replacement)
s=s.replace('self.read_source_publication(family, cancel)', 'self.read_source_publication(family, source_protection, cancel)')
# remaining context calls indented differently
s=s.replace('''                    family,
                    cancel,
''','''                    family,
                    source_protection,
                    cancel,
''')
i=s.index('                        transition_sql::apply_source_publication(');e=s.index('                        let prospective',i)
call=s[i:e]
scoped=call.replace('transition_sql::apply_source_publication(', 'transition_sql::apply_source_publication_with_companion(').replace('                            Some(cancel),','                            source.data(),\n                            Some(cancel),')
s=s[:i]+'''                        if let Some(source)=source_protection {
'''+scoped+'''                        } else {
'''+call+'''                        }
'''+s[e:]
s=s.replace('''                            family,
                            cancel,
''','''                            family,
                            source_protection,
                            cancel,
''')
# Explicit rollback before nested destination/family scope closes. Don't run
# rollback or any SQL/FS readback after an unacknowledged close.
s=s.replace('''            // Family/destination read closes have already completed.''','''            let result=match result {
                Err(primary) if !bare.connection().is_autocommit()=>match bare.connection().execute_batch("ROLLBACK") {
                    Ok(())=>Err(primary),Err(rollback)=>Err(Cause::Cleanup{primary:Box::new(primary),close:Box::new(rollback.into())}),
                }, other=>other,
            };
            // Family/destination read closes have already completed.''')
write(p,s)
