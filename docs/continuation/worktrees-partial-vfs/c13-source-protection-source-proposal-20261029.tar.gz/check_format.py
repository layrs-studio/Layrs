from pathlib import Path
import hashlib,json,subprocess
ROOT=Path('D:/Layrs/tmp/c13-source-protection-source-proposal')
files=sorted((ROOT/'files').rglob('*.rs'))
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
exe='C:/Users/ALEXA/.cargo/bin/rustfmt.exe'
args=[exe,'--edition','2024','--config','skip_children=true,style_edition=2021']
formatted=subprocess.run(args+[str(p) for p in files],capture_output=True,text=True)
checked=subprocess.run(args+['--check']+[str(p) for p in files],capture_output=True,text=True)
result={'kind':'source-format-check-only','rust_files':len(files),'format':{'exit_code':formatted.returncode,'stdout':formatted.stdout,'stderr':formatted.stderr},'check':{'exit_code':checked.returncode,'stdout':checked.stdout,'stderr':checked.stderr},'arguments':args[1:],'compilation':'NOT_RUN','tests':'NOT_RUN','native_SQL_network_fixtures':'NOT_RUN','independent_verification':False}
(ROOT/'rustfmt-results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'rust_files':len(files),'format_exit':formatted.returncode,'check_exit':checked.returncode,'diagnostics':formatted.stderr+checked.stderr}))
assert formatted.returncode==0 and checked.returncode==0
