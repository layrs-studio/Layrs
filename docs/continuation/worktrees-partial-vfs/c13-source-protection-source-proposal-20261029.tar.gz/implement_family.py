from build_bundle import *
p=P+'shared.rs';edit(p,'pub(in crate::projection) mod exact_protection;','pub(in crate::projection) mod exact_protection;\n#[cfg(windows)]\npub(in crate::projection) mod source_companion;')
p=P+'shared/source_companion.rs'
edit(p,'ImportSource::Provider {identity, private_schema, private_database_identity, ..}', 'ImportSource::Provider {identity, private_schema, ..}')
edit(p,'''        let c = intent.destination''','''        let private_database_identity = &a.private.database_file_identity;
        let c = intent.destination''')
edit(p,"    manifests: &'a [FileManifest],", "    manifests: Vec<&'a FileManifest>,")
edit(p,'let ordered:Vec<FileManifest>=sorted.values().map(|m|(*m).clone()).collect();','let ordered:Vec<&FileManifest>=sorted.into_values().collect();')
edit(p,'manifests:&ordered','manifests:ordered.clone()')
edit(p,'reservation_bytes,manifests:ordered','reservation_bytes,manifests:ordered.into_iter().cloned().collect()')
# Parsed U must also equal the immutable plan, not just root self-hash.
edit(p,'    pub(in crate::projection) fn id(&self)', '''    pub(in crate::projection) fn require_plan(&self, a:&AllocationRecord, intent:&ProviderTransitionIntentRecord, cancel:Option<&Cancellation>)->Result<()> {
        if Self::binding_for(a,intent,&self.binding.destination)? != self.binding {
            return Err(invalid("source root belongs to another immutable plan"));
        }
        let stored:Stored=serde_json::from_slice(&self.payload).map_err(|e|invalid(e.to_string()))?;
        let expected=&intent.plan.protected_manifests;
        let mut ordered=BTreeMap::new();
        for m in &stored.manifests { ordered.insert((m.file_id(),m.id()),m); }
        let mut hash=blake3::Hasher::new();hash.update(b"layrs-provider-managed-protected-manifests-v1\\0");hash.update(&(ordered.len() as u64).to_be_bytes());
        #[derive(Serialize)] #[serde(rename_all="camelCase")]
        struct Row<'a> {file_id:&'a layrs_core::scm::FileId,manifest_id:&'a layrs_core::scm::FileManifestId,bytes:u64}
        for m in ordered.into_values() {
            cancellation::check(cancel)?;
            let b=canonical_json(&Row{file_id:m.file_id(),manifest_id:m.id(),bytes:m.byte_length()}).map_err(|e|invalid(e.to_string()))?;
            hash.update(&(b.len() as u64).to_be_bytes());hash.update(&b);
        }
        if expected.count!=stored.manifests.len() as u64 || expected.digest!=format!("blake3:{}",hash.finalize()) {
            return Err(invalid("source root does not retain entire planned U"));
        }
        Ok(())
    }
    fn binding_for(a:&AllocationRecord,intent:&ProviderTransitionIntentRecord,c:&ExactBinding)->Result<SourceCompanionBinding> {SourceCompanionBinding::new(a,intent,c)}
    pub(in crate::projection) fn id(&self)''')
# Exact group inventory supplied to capture interpreter only after fully proving
# every companion row. Unknown groups are never excluded by namespace alone.
write(p,read(p)+'''
pub(in crate::projection) struct SourceCompanionFamilyContext<'a> {
    pub(in crate::projection) publication: &'a crate::projection::provider::validation::PrivateActivePublicationValidation,
    pub(in crate::projection) pending: Option<&'a SourceCompanionProtection>,
}
pub(super) struct ClassifiedSourceGroups {
    pub(super) reservations: std::collections::BTreeSet<String>,
    pub(super) roots: std::collections::BTreeSet<String>,
}
pub(super) fn classify_source_groups(c:&Connection,a:&AllocationRecord,
    context: Option<&SourceCompanionFamilyContext<'_>>, cancel:Option<&Cancellation>)->Result<ClassifiedSourceGroups> {
    let mut result=ClassifiedSourceGroups{reservations:Default::default(),roots:Default::default()};
    let Some(context)=context else {return Ok(result);};
    for group in context.publication.companions.groups() {
        cancellation::check(cancel)?;
        let intent=context.publication.transitions.iter().find(|i|i.transaction_id==group.transaction)
            .ok_or_else(||invalid("source family companion intent absent"))?;
        let root=SourceCompanionProtection::read_retained(c,&group.root,cancel)?;
        root.require_plan(a,intent,cancel)?;
        if root.binding.companion_id!=group.companion_id || root.binding.destination.plan_digest!=group.plan_digest
            || root.binding.destination.prefix_id!=group.prefix_id {
            return Err(invalid("source family private companion binding differs"));
        }
        // Exact sticky and alternate representations are ALL members of U.
        let stored:Stored=serde_json::from_slice(&root.payload).map_err(|e|invalid(e.to_string()))?;
        for (file,(manifest,bytes)) in &group.content {
            if !stored.manifests.iter().any(|m|m.file_id().as_str()==file && m.id().as_str()==manifest && m.byte_length()==*bytes) {
                return Err(invalid("source companion private mapping outside retained U"));
            }
        }
        let header=crate::projection::provider::records::companion_v2::CompanionHeaderRecord::decode(&group.header)?;
        if let crate::projection::provider::records::companion_v2::CompanionHeaderRecord::V2(h)=header {
            for r in h.preserved_representations {
                if !stored.manifests.iter().any(|m|m.file_id()==&r.file_id && m.id()==&r.manifest_id && m.byte_length()==r.bytes) {
                    return Err(invalid("source companion exact alternate outside retained U"));
                }
            }
        }
        if !result.reservations.insert(root.operation.clone()) || !result.roots.insert(root.id.clone()) {
            return Err(invalid("source family companion group repeats"));
        }
    }
    if let Some(root)=context.pending {
        let intent=context.publication.transitions.iter().find(|i|i.transaction_id==root.binding.destination.transaction_id)
            .ok_or_else(||invalid("pending source protection has no actual Staging intent"))?;
        root.require_plan(a,intent,cancel)?;
        if intent.state==TransitionState::Staging {
            if context.publication.companions.groups().iter().any(|g|g.transaction==intent.transaction_id) {
                return Err(invalid("source Staging has premature companion SQL"));
            }
            let state=root.inspect(c,cancel)?;
            if state!=SourceCompanionPresence::Absent {result.reservations.insert(root.operation.clone());}
            if state==SourceCompanionPresence::Protected {result.roots.insert(root.id.clone());}
        } else if !result.roots.contains(root.id()) {
            return Err(invalid("pending source group is neither Staging nor exact terminal"));
        }
    }
    Ok(result)
}

/// Autonomous family scan recognizes the new namespace explicitly, without
/// opening B or treating its retention as C's own admission proof. A reserve
/// without a root blocks this admission; it is resumable only by the B owner.
pub(in crate::projection) fn retained_namespace(c:&Connection,cancel:Option<&Cancellation>)->Result<Vec<SourceCompanionProtection>> {
    let mut roots=Vec::new();
    let mut q=c.prepare("SELECT id FROM roots WHERE operation LIKE 'provider-companion%' ORDER BY id LIMIT 4097")?;
    let mut rows=q.query([])?;
    while let Some(row)=rows.next()? {
        cancellation::check(cancel)?;
        let id=row.get_ref(0)?.as_str().map_err(|e|invalid(e.to_string()))?;
        if roots.len()>=4096 || id.len()!=64 {return Err(invalid("source namespace root count/key exceeds bound"));}
        roots.push(SourceCompanionProtection::read_retained(c,id,cancel)?);
    }
    let mut q=c.prepare("SELECT id FROM reservations WHERE operation LIKE 'provider-companion%' OR id LIKE 'provider-companion%' ORDER BY id LIMIT 4097")?;
    let mut rows=q.query([])?; let mut seen=std::collections::BTreeSet::new();
    while let Some(row)=rows.next()? {
        let id=row.get_ref(0)?.as_str().map_err(|e|invalid(e.to_string()))?;
        if id.len()>128 || seen.len()>=4096 || !roots.iter().any(|r|r.operation()==id) || !seen.insert(id.to_owned()) {
            return Err(invalid("unowned or reservation-only source companion family group"));
        }
    }
    Ok(roots)
}
''')
p=P+'provider/transition_reconcile/source.rs'
edit(p,'ImportSource::Provider { identity, version, .. }','ImportSource::Provider { activation_map_id, version, .. }')
edit(p,'if identity != &proof.active.source.commitment().identity','if activation_map_id != &proof.active.activation.digest()?')

p=P+'shared/provider_capture.rs'
edit(p,'pub(super) fn validate(\n','''pub(super) fn validate(
''')
edit(p,'    cancel(cancellation)?;\n    family.verify()?;\n    let owner', '''    validate_with_companions(family,c,allocation,proof,None,cancellation)
}

pub(super) fn validate_with_companions(
    family: &FamilyAccess, c: &Connection, allocation: &AllocationRecord,
    proof: &PrivateCaptureProof,
    context: Option<&crate::projection::shared::source_companion::SourceCompanionFamilyContext<'_>>,
    cancellation: Option<&Cancellation>,
) -> Result<()> {
    cancel(cancellation)?;
    family.verify()?;
    let source_groups=crate::projection::shared::source_companion::classify_source_groups(c,allocation,context,cancellation)?;
    let owner''')
edit(p,'validate_reservations(c, owner, &attempts, &reservations, cancellation)?;', 'validate_reservations(c, owner, &attempts, &reservations, &source_groups, cancellation)?;')
edit(p,'        &content,\n        cancellation,','        &content,\n        &source_groups,\n        cancellation,')
edit(p,'    reservations: &BTreeMap<&str, &str>,\n    cancellation: Option<&Cancellation>,\n) -> Result<()> {\n    // Reservation', '    reservations: &BTreeMap<&str, &str>,\n    source_groups: &crate::projection::shared::source_companion::ClassifiedSourceGroups,\n    cancellation: Option<&Cancellation>,\n) -> Result<()> {\n    // Reservation')
edit(p,'        let transaction = reservations\n            .get(id.as_str())','        if source_groups.reservations.contains(&id) { continue; }\n        let transaction = reservations\n            .get(id.as_str())')
edit(p,'length(CAST(operation AS BLOB))>81','length(CAST(operation AS BLOB))>128')
edit(p,'length(CAST(operation AS BLOB))!=81','length(CAST(operation AS BLOB))>128')
edit(p,'    content: &BTreeMap<&str, (&str, u64)>,\n    cancellation:', '    content: &BTreeMap<&str, (&str, u64)>,\n    source_groups: &crate::projection::shared::source_companion::ClassifiedSourceGroups,\n    cancellation:')
# Exclusion after complete exact classification; still sees all unknown roots.
edit(p,'        let id: String = row.get(0)?;\n        let digest: String = row.get(1)?;', '        let id: String = row.get(0)?;\n        if source_groups.roots.contains(&id) { continue; }\n        let digest: String = row.get(1)?;')
p=P+'shared/provider_access.rs'
edit(p,'self.validate_catalog_inner(c, a, cancel, false, None)?','self.validate_catalog_inner(c, a, cancel, false, None, None)?')
edit(p,'self.validate_catalog_inner(c, a, cancel, true, None)?','self.validate_catalog_inner(c, a, cancel, true, None, None)?')
edit(p,'self.validate_catalog_inner(c, a, cancel, true, Some(proof))?','self.validate_catalog_inner(c, a, cancel, true, Some(proof), None)?')
edit(p,'    fn validate_catalog_inner(', '''    pub(in crate::projection) fn validate_source_companion_catalog(
        &self, c:&Connection, a:&AllocationRecord,
        context:&crate::projection::shared::source_companion::SourceCompanionFamilyContext<'_>,
        cancel:Option<&layrs_vfs::Cancellation>,
    )->ProviderResult<ActivationRegistration> {
        match self.validate_catalog_inner(c,a,cancel,true,Some(&context.publication.capture),Some(context))? {
            CatalogRegistration::Ready=>Ok(ActivationRegistration::Ready),
            _=>Err(provider_invalid("source companion requires exact Ready B family owner")),
        }
    }
    fn validate_catalog_inner(''')
edit(p,'        capture: Option<&crate::projection::provider::validation::PrivateCaptureProof>,','        capture: Option<&crate::projection::provider::validation::PrivateCaptureProof>,\n        source_companion:Option<&crate::projection::shared::source_companion::SourceCompanionFamilyContext<\'_>>,')
edit(p,'            provider_capture::validate(self, c, a, proof, cancel)?;', '            provider_capture::validate_with_companions(self, c, a, proof, source_companion, cancel)?;')

p=P+'provider/bootstrap/preparation/activation/capture_state.rs'
edit(p,'''        held.family.validate_capture_catalog(
            c,
            &held.artifacts.allocation,
            private.capture(),
            cancel,
        )''','''        match &private {
            ReadProof::Strict(proof)=>held.family.validate_capture_catalog(c,&held.artifacts.allocation,&proof.capture,cancel),
            ReadProof::Live(proof)=>held.family.validate_source_companion_catalog(c,&held.artifacts.allocation,
                &crate::projection::shared::source_companion::SourceCompanionFamilyContext {publication:proof,pending:None},cancel),
        }''')
p=P+'provider/content_catalog.rs'
edit(p,'.validate_capture_catalog(c, &self.allocation, self.proof.capture(), None)?', '''.validate_source_companion_catalog(c, &self.allocation,
                &crate::projection::shared::source_companion::SourceCompanionFamilyContext {publication:self.proof.publication(),pending:None}, None)?''')
p=P+'provider/bootstrap/preparation/activation/capture_sql.rs'
edit(p,'fn family(held: &outcome::PublicationPins, proof: &PrivateCaptureProof)', 'fn family(held: &outcome::PublicationPins, proof: &PrivateCaptureMutationValidation)')
edit(p,'.validate_capture_catalog(c, &held.artifacts.allocation, proof, None)', '''.validate_source_companion_catalog(c, &held.artifacts.allocation,
                &crate::projection::shared::source_companion::SourceCompanionFamilyContext {publication:proof.publication(),pending:None}, None)''')
edit(p,'family(held, value.capture())?', 'family(held, &value)?')
edit(p,'family(held, successor.capture())?', 'family(held, &successor)?')
p=P+'provider/bootstrap/preparation/activation/ranges.rs'
edit(p,'held.family.validate_capture_catalog(\n            c,\n            &held.artifacts.allocation,\n            &inspected.capture,\n            Some(cancel),\n        )?', '''held.family.validate_source_companion_catalog(
            c, &held.artifacts.allocation,
            &crate::projection::shared::source_companion::SourceCompanionFamilyContext {publication:&inspected,pending:None}, Some(cancel),
        )?''')

p=P+'shared/admitted_catalog.rs'
needle='        let mut groups = BTreeSet::new();'
edit(p,needle,'''        // Independently classify B's retained metadata groups. This performs no
        // B open and does not make them members of C's exact debit inventory.
        let source_groups=super::source_companion::retained_namespace(c,cancel)?;
        for source in &source_groups {
            let b=&source.binding.destination;
            if b.family_incarnation!=marker.incarnation || b.family_root_identity!=marker.root_identity
                || b.family_catalog_identity!=marker.database_identity || b.family_marker_digest!=digest {
                return Err(invalid("retained source group family identity differs"));
            }
            let croot=ExactProtection::new(&b.family_incarnation,&b.owner,&b.database_identity,&b.transaction_id,
                &read_group_required_for_source(c,b,cancel)?,cancel)?;
            let (actual,_,member)=read_group(c,croot.id(),known.get(croot.id()).copied(),cancel)?;
            if actual!=*b {return Err(invalid("retained source group names a different C exact binding"));}
            require_member(c,&marker,&self.primary.marker,b,&member)?;
        }
'''+needle)
# Read C canonical import root through exact operation, then normal read_group.
write(p,read(p)+'''
fn read_group_required_for_source(c:&Connection,b:&crate::projection::shared::exact_content::ExactBinding,
    cancel:Option<&Cancellation>)->Result<Vec<layrs_core::scm::FileManifest>> {
    let operation=format!("provider-import:{}",b.transaction_id);
    let n:u64=c.query_row("SELECT count(*) FROM roots WHERE operation=?1 AND owner=?2",rusqlite::params![operation,b.owner.as_str()],|r|r.get(0))?;
    if n!=1 {return Err(invalid("retained B source group lacks unique C root"));}
    let id:String=c.query_row("SELECT id FROM roots WHERE operation=?1 AND owner=?2 AND length(CAST(id AS BLOB))=64",rusqlite::params![operation,b.owner.as_str()],|r|r.get(0))?;
    let (actual,required,_)=read_group(c,&id,None,cancel)?;
    if actual!=*b {return Err(invalid("retained B source group C binding differs"));}
    Ok(required)
}
''')
