from build_bundle import *
p=P+'provider/validation.rs'
edit(p,'impl PrivateActivePublicationValidation {','''impl PrivateActivePublicationValidation {
    pub(in crate::projection) fn capture_data(&self)->&PrivateCaptureProof {&self.capture}
    pub(in crate::projection) fn source_transitions(&self)->&[records::transition::ProviderTransitionIntentRecord] {&self.transitions}
''')
for p in [P+'shared/provider_access.rs',P+'shared/provider_import/source.rs',P+'shared/source_companion.rs']:
    s=read(p).replace('&context.publication.capture','context.publication.capture_data()')
    s=s.replace('context\n            .publication\n            .transitions','context\n            .publication\n            .source_transitions()')
    s=s.replace('context.publication.transitions','context.publication.source_transitions()')
    write(p,s)
# Clear harmless unused imports introduced by the explicit source scope.
p=P+'provider/transition_sql.rs'
# Old source intent path still needs the capture type; keep its import.
p=P+'provider/bootstrap/preparation/activation/capture_state.rs'
s=read(p);i=s.index('impl ReadProof {');e=s.index('\n}\n',i)+3
# This helper discarded publication context and is no longer used.
s=s[:i]+s[e:];write(p,s)
