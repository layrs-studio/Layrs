from pathlib import Path
import hashlib, json, zlib, shutil, difflib, re

OUT = Path('D:/Layrs/tmp/c13-source-protection-source-proposal')
MAIN = Path('D:/Layrs/layrs')
OLD = Path('D:/Layrs/tmp/c13-provider-driver-source-proposal')
HEAD = '6b1f5632bd7f6092226d57e3c813033a82bcfc98'
PIN = '0033a04e8831186c79b0d3b8581e1d36d1f5083a56470194c0a672ff4186835c'
P = 'crates/layrs-store-local/src/projection/'
def sha(b): return hashlib.sha256(b).hexdigest()
def canon(b): return b.decode('utf-8').replace('\r\n','\n')
def obj(oid):
    raw = zlib.decompress((MAIN/'.git/objects'/oid[:2]/oid[2:]).read_bytes())
    assert hashlib.sha1(raw).hexdigest() == oid
    h,b = raw.split(b'\0',1)
    k,n = h.split(b' ')
    assert len(b) == int(n)
    return k,b
def base(path):
    k,b=obj(HEAD); assert k==b'commit'
    oid=b.split(b'\n',1)[0].decode().removeprefix('tree ')
    for part in path.split('/'):
        k,b=obj(oid); assert k==b'tree'
        cursor=0; found=None
        while cursor<len(b):
            end=b.index(b'\0',cursor)
            name=b[cursor:end].split(b' ',1)[1].decode()
            candidate=b[end+1:end+21].hex(); cursor=end+21
            if name==part: found=candidate; break
        if found is None: return None,None
        oid=found
    k,b=obj(oid); assert k==b'blob'
    return oid,b
def read(path):
    f=OUT/'files'/path
    return f.read_text(encoding='utf-8') if f.exists() else canon(base(path)[1])
def write(path,s):
    f=OUT/'files'/path; f.parent.mkdir(parents=True,exist_ok=True)
    f.write_text(s,encoding='utf-8',newline='\n')
def edit(path,a,b):
    s=read(path); assert a in s, (path,a[:120]); write(path,s.replace(a,b))
def initialize():
    assert sha((OLD/'manifest.sha256.json').read_bytes())==PIN
    m=json.loads((OLD/'manifest.sha256.json').read_text())
    assert len(m['files'])==23
    assert (MAIN/'.git/refs/heads/feature/worktrees-partial-vfs').read_text().strip()==HEAD
    checked=set()
    for row in m['files']:
        path=row['path']; data=(OLD/row['output']).read_bytes()
        assert sha(data)==row['output_sha256']
        oid,b=base(path)
        assert oid==row['base_head_git_blob']
        assert (None if b is None else sha(b))==row['base_head_blob_sha256']
        physical=(MAIN/path).read_bytes() if (MAIN/path).exists() else None
        assert (None if physical is None else sha(physical))==row['base_sha256'],path
        assert b is None or canon(b)==canon(physical),path
        target=OUT/row['output'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    for path in [MAIN, MAIN.parent, Path('D:/'), MAIN/'crates/layrs-store-local/src/projection/provider', MAIN/'crates/layrs-store-local/src/projection/shared']:
        for ancestor in [path,*path.parents]:
            if ancestor in checked: continue
            checked.add(ancestor)
            f=ancestor/'AGENTS.md'
            if f.exists(): print(str(f)+'\n'+f.read_text())
    print('Validated and copied all 23 input outputs; exact HEAD blobs and physical base hashes match.')
if __name__=='__main__': initialize()
