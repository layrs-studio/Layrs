# Source companion recipes — authored, never compiled or run

These are source proposals, not runtime evidence. No existing native suite is
requested for rerun. Do not execute while ROOT's retained native runner is
active. Keep audited owner/child bounds and the normal positive-close hooks.
No recipe creates a fake C Ready to bypass the pending native constructor.

## Registered source recipes

`shared::source_companion::tests` adds:

1. `canonical_source_root_binds_both_owners_and_all_alternates_without_large_minimum`:
   DATA only. Same FileId, distinct ManifestIds, permutation equality, full U,
   binding/domain separation, tiny reservation below 64KiB, changed owner/plan,
   duplicate manifest refusal, actual private envelope boundary.
2. `source_root_checks_bounds_before_aggregate_encoding`: DATA only. Private
   envelope over 1GiB, overlong source identity, aliased B/C owner, counting
   writer beyond 16MiB. Each must refuse before aggregate root allocation.
3. `source_fixed_reservation_counts_b_plus_c_and_refuses_changed_remaining_without_writes`:
   ignored audited SQL child, proposed 120s ceiling, empty U and tiny metadata.
   Global quota Q_B+Q_C-1 refuses with unchanged `total_changes`; exact boundary
   reserves Q_B; replay performs zero mutations; reduced B remaining refuses;
   reservation-only cannot be classified as source Ready. The fixture is only
   reservation DATA; it constructs no C private Ready or physical capability.

## Private and family validator recipes to implement/run after integration

P1 — accepted capture plus outgoing companion. Use the existing audited active
SQL fixture and real reconcile codecs. Freeze prefix content/companion/receipt
selectors. Supply one Accepted capture, one staged capture replacement, a v2
outgoing file with the same FileId but alternate ManifestId, and a recovery-only
file. Publish through the new low-level transaction primitive. Require the
actual SQL mappings to equal exactly the reference union; `PrivateCaptureProof`
contains only capture references and capture claims. The shared mapping stays
byte-exact while U contains both ManifestIds. Recompute the frozen closure and
require byte-identical commitments before and after. Change a scalar digest,
header payload, mapping, receipt owner, private claim, or outgoing proof and
require refusal. An extra content/claim/header/scalar row must refuse. A later
Accepted capture sharing that FileId must preserve the full outgoing proof and
pass `PrivateCaptureMutationValidation::require_same_publications` and
`require_same_state`; removing the companion from the family must fail.

P2 — descriptor-only preimage. Start with a valid original source descriptor
whose FileId is absent from frozen `projection_content`, then delete or modify
the path. Derive through `VerifiedCompleteManagedImage::reconcile`, which now
adds `provider_descriptor_view` from the full source proof. Require original
descriptor manifest+bytes in the missing mapping, header and U. Supply a
different same-FileId manifest as the live recovery scalar; it cannot replace
the original descriptor. Omit/alter the original source proof or introduce
ambiguous original descriptors and require refusal before reservation/writer
open. Accepted-deletion and satisfied-deletion preimages must also require
their actual mappings; header-only substitution must fail under v2.

P3 — exact coexistence. Keep an Accepted B capture root/reservation and add a
fixed B companion reservation and root. Validate through
`validate_source_companion_catalog` with the full publication proof. Enumerate
reservation-only, protected-root-only, C Ready/B Staging, B Ready, Published.
Assert no B `exact_installations`, no release, no repair and unchanged Q_C.
Tamper independently with B/C owner, DB, prefix, plan, companion, U, operation,
root digest, membership and fixed remaining. Add an unknown root/reservation
under a malformed `provider-companion...` namespace. All must refuse, including
an orphan membership with its root absent. Never delete corruption and retry
as if it were a legitimate predecessor. Exercise old strict capture/import
constructors too: they must continue refusing companion state.

P4 — exact accounting with real C progress. Derive Q_B before either new
reservation. With unrelated ordinary/capture reservations and retained exact
journals already present, calculate production global usage. Q_B+absent Q_C
fits exactly; one byte less fails before effects. Drive C installation through
its real exact engine and require `Q_C - exact durable debit == remaining_C`
through every phase, with shared chunks charged once. B remaining is always
Q_B, including both root and source SQL publication. Replaying with increased
or decreased Q_B, changed private envelope or changed reservation ownership
must fail, never top up; `quota.bytes` stays unchanged.

## Source writer and close recipes — native integration prerequisite missing

The following are explicitly **not runnable** until the genuine companion-aware
C private Ready/checkout/family Ready constructor and retained driver wiring
exist. Existing strict Ready guards stay enabled. Invoke the real API chain,
not handwritten Ready SQL, bool declarations, or an arbitrary callback:

`complete image + full source/authority -> closed reconcile + immutable plan ->
SourceCompanionPublication::derive -> reserve_source_companion -> real C exact
installation/protection -> protect_source_companion -> genuine C private Ready
and family Ready -> publish_source_companion`.

W1 — atomic rollback. In an isolated audited fixture, inject a failure after
each B mapping, header, file, deletion, claim, receipt insert and after the exact
Staging->Ready CAS, plus full prospective-validator failure. Require explicit
rollback before nested scopes close. After positive closes, B is either its
exact Staging predecessor or the complete Ready atom; never an adopted partial
rowset. Both protection roots and fixed reservations persist. Incoming receipt
ancestry is unchanged; the new receipt is outgoing only. READY and PUBLISHED
must occur in separate commits, with complete fresh reads between them.

W2 — same-phase replay and final replay. Repeating the exact low-level Ready
atom or a protected source reservation/root performs zero mutations. An exact
Published `publish_source_companion` replay opens zero writers. Resuming from
durable B Ready performs only the separate Ready->Published writer required by
the existing protocol. Count actual opens, commits, and positive closes; do
not conflate that required final phase with same-phase Ready replay.

W3 — acknowledgement refusal. Inject the observer's ACK failure AFTER an
actual successful OS SQLite close for B reservation, B protection, C/family
Ready, B Ready and B Published. Require failure, retained pins/owners and zero
subsequent SQL/FS probes or next effects. A later separately initiated recovery
may recognize the exact complete durable phase; it must not repair state.

W4 — actual OS close failure. Separately use the audited real busy-handle/
unfinalized-statement mechanism to make the underlying `sqlite3_close` fail.
Assert the close result reports failure and quarantines the handle. No next
probe/effect runs. This is distinct from W3; an injected ACK is not evidence of
an OS close failure. Include nested C/family RO close failure: no B readback,
next writer, image callback or cleanup follows the unacknowledged close.

W5 — retained C autonomy. Complete the real conversion and close its original
holders. Stop Provider and make the B DB/native paths unavailable. Normal C
open, authorized capture, prepared Restore and supported inherited re-export
must use C private receipt/claim/root/U exclusively, preserving alternate and
descriptor preimage references. New family namespace interpretation may read
family DATA; it must never reopen B or use a B root to replace a missing C
claim/root/journal. Missing own C protection refuses even with valid B
retention. Keep existing reclamation fences and fixed B reservation unchanged.

W6 — restart limitations. Reservation-only and root-only recovery needs the
same closed plan/rows and genuine source/image/authority owners; DATA cannot
recreate them. B Ready/Published replay needs the retained witness or a future
explicit recovery owner. If that owner is unavailable, fail with protections
retained and record the missing input; never reconstruct authority from SQL.
