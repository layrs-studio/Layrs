//! Full retained-checkpoint adapter for C13, alongside the still-strict legacy
//! managed adapter. Unknown/protected files are HASHED, not granted authority.
//! No output path, writable hardlink, invented observation or capture is made.
use super::*;
use crate::projection::provider::{
    transition_observation::TransitionObservationData,
    transition_reconcile::{
        companions::OwnedCompanionData, CompleteSourceImageData, ImageFileData, ReconcileSourceData,
    },
    validation::PrivateActiveCaptureValidation,
};

pub(in crate::projection::provider) struct VerifiedCompleteManagedImage<'a, 'c> {
    retained: VerifiedManagedImage<'a, 'c>,
}

/// All namespace/size/alias checks precede the first content read. Every
/// immutable file verifies FileId AND exact chunks; every NeedsHash entry uses
/// the real retained checkpoint reader. Missing/unsupported bytes propagate.
pub(in crate::projection::provider) fn plan<'a, 'c>(
    checkpoint: &'a mut ExportCheckpoint<'c>,
    bytes: &'a dyn SnapshotSource,
    source: &'a ProviderBootstrapSource,
    activated: &'a ProjectionSnapshot,
    cancel: &Cancellation,
) -> Result<VerifiedCompleteManagedImage<'a, 'c>> {
    if checkpoint.root_guard().is_none() {
        return Err(invalid(
            "complete managed image lacks retained provider root",
        ));
    }
    let data = build_complete(checkpoint, bytes, source, activated, cancel)?;
    Ok(VerifiedCompleteManagedImage {
        retained: VerifiedManagedImage {
            checkpoint,
            bytes,
            source,
            activated,
            data,
        },
    })
}

impl VerifiedCompleteManagedImage<'_, '_> {
    /// Pin/namespace-only check after C Ready; never rehashes source bytes.
    pub(in crate::projection::provider) fn require_retained(
        &self,
        root: &layrs_vfs::ProviderRootGuard,
        digest: &str,
        cancel: &Cancellation,
    ) -> Result<()> {
        cancel.check()?;
        if digest != self.retained.digest() {
            return Err(invalid("complete retained source image digest differs"));
        }
        self.retained
            .require_owner(root, self.retained.source, self.retained.activated)?;
        cancel.check()?;
        Ok(())
    }

    pub(in crate::projection::provider) fn digest(&self) -> &str {
        self.retained.digest()
    }

    /// The import prefix must have been constructed with this complete digest.
    /// from_checkpoint independently binds the entire inventory to that prefix
    /// and real source control/FORMAT. No caller-selected inventory is accepted.
    pub(in crate::projection::provider) fn reconcile(
        &mut self,
        source: &ReconcileSourceData<'_>,
        observation: &TransitionObservationData,
        proof: &PrivateActiveCaptureValidation,
        manifests: &[FileManifest],
        metadata_without_companions: u64,
        cancel: &Cancellation,
    ) -> Result<OwnedCompanionData> {
        self.revalidate(cancel)?;
        let source = source.provider_descriptor_view(proof, Some(cancel))?;
        let (_, _, fixed, activated, _) = proof.import_parts();
        self.retained.require_source(fixed, &activated.snapshot)?;
        let views = self
            .retained
            .files()
            .iter()
            .map(|file| ImageFileData {
                path: &file.path,
                manifest: file.manifest.manifest(),
                executable: Some(file.executable),
            })
            .collect::<Vec<_>>();
        let complete = CompleteSourceImageData::from_checkpoint(
            &source,
            &*self.retained.checkpoint,
            &views,
            Some(cancel),
        )?;
        let result = OwnedCompanionData::derive(
            &source,
            &complete,
            observation,
            manifests,
            metadata_without_companions,
            Some(proof),
            Some(cancel),
        )?;
        self.revalidate(cancel)?;
        Ok(result)
    }

    /// Exact current-image lookup includes recovery-only files; companions are
    /// not filtered out before installation. Historical/fresh-base bytes still
    /// require the existing separately owned family/acquisition reader.
    pub(in crate::projection::provider) fn current_path(
        &self,
        manifest: &FileManifest,
    ) -> Option<&RepoPath> {
        self.retained
            .files()
            .iter()
            .find(|file| file.manifest.manifest() == manifest)
            .map(|file| &file.path)
    }
    pub(in crate::projection::provider) fn copy_exact_chunk(
        &mut self,
        path: &RepoPath,
        manifest: &FileManifest,
        ordinal: usize,
        output: &mut dyn Write,
        cancel: &Cancellation,
    ) -> Result<()> {
        self.revalidate(cancel)?;
        self.retained
            .copy_exact_chunk(path, manifest, ordinal, output, cancel)?;
        self.revalidate(cancel)
    }
    pub(in crate::projection::provider) fn copy_exact_file(
        &mut self,
        path: &RepoPath,
        manifest: &FileManifest,
        output: &mut dyn Write,
        cancel: &Cancellation,
    ) -> Result<()> {
        self.revalidate(cancel)?;
        self.retained
            .copy_exact_file(path, manifest, output, cancel)?;
        self.revalidate(cancel)
    }
    pub(in crate::projection::provider) fn revalidate(
        &mut self,
        cancel: &Cancellation,
    ) -> Result<()> {
        let refreshed = build_complete(
            self.retained.checkpoint,
            self.retained.bytes,
            self.retained.source,
            self.retained.activated,
            cancel,
        )?;
        if !self.retained.data.matches(&refreshed) {
            return Err(invalid("complete managed image bytes/namespace changed"));
        }
        Ok(())
    }
}

fn build_complete<'a>(
    checkpoint: &mut ExportCheckpoint<'_>,
    bytes: &dyn SnapshotSource,
    source: &'a ProviderBootstrapSource,
    activated: &ProjectionSnapshot,
    cancel: &Cancellation,
) -> Result<ImageData<'a>> {
    cancel.check()?;
    checkpoint.revalidate_namespace()?;
    if activated != &activation_snapshot(source)? {
        return Err(invalid(
            "complete image activation differs from fixed source",
        ));
    }
    let count = bound_observation_paths(checkpoint.entries().iter().map(|e| &e.path), cancel)?;
    let mut observations = Vec::with_capacity(count);
    for entry in checkpoint.entries() {
        cancel.check()?;
        observations.push(Observed {
            path: entry.path.clone(),
            evidence: entry.evidence.clone(),
            original_path: checkpoint.original_path(&entry.path)?,
        });
    }
    let planned = recovery_export::plan(&observations, source, activated)?;
    let descriptors: BTreeMap<_, _> = source.descriptors().iter().map(|d| (&d.path, d)).collect();
    let mut files = Vec::with_capacity(planned.files.len());
    let mut report = Vec::with_capacity(planned.files.len());
    let mut metadata = 0u64;
    for file in &planned.files {
        cancel.check()?;
        let (manifest, executable) = match file.reader {
            ReaderKind::ImmutableSource => {
                let descriptor = descriptors
                    .get(&file.path)
                    .ok_or_else(|| invalid("complete immutable descriptor absent"))?;
                verify_source_manifest_stream(
                    &descriptor.manifest,
                    cancel,
                    |offset, output, cancel| {
                        bytes.read_exact_at(&descriptor.file_id, offset, output, cancel)
                    },
                )?;
                (
                    ManagedManifest::Source(&descriptor.manifest),
                    file.executable
                        .ok_or_else(|| invalid("complete immutable mode unknown"))?,
                )
            }
            ReaderKind::Native => {
                let manifest = checkpoint.with_reader(&file.path, |reader| {
                    capture_image::hash_reader(reader, file.size, cancel)
                })?;
                // This module is Windows-only. Native ordinary capture observes
                // false on this platform (capture/scan.rs::executable), even for
                // an unobserved creation. Do not copy a remote executable bit
                // onto a native replacement or invent a cross-platform mode.
                (ManagedManifest::Native(manifest), false)
            }
        };
        if manifest.manifest().byte_length() != file.size {
            return Err(invalid("complete native/source size differs"));
        }
        // Bound cumulative owned manifest metadata, in addition to the 4GiB
        // complete image and per-file bounds applied by recovery_export::plan.
        crate::projection::provider::records::codec::preflight(manifest.manifest(), 256 * 1024)?;
        let encoded = layrs_core::scm::canonical_json(manifest.manifest())
            .map_err(|e| invalid(e.to_string()))?;
        metadata = metadata
            .checked_add(encoded.len() as u64)
            .filter(|n| *n <= 256 * 1024 * 1024)
            .ok_or_else(|| invalid("complete manifest metadata exceeds bound"))?;
        let class = recovery_export::verified_class(file, manifest.manifest().file_id());
        report.push(ProviderRecoveryExportFile {
            path: file.path.clone(),
            file_id: manifest.manifest().file_id().clone(),
            length: file.size,
            executable: Some(executable),
            class,
        });
        files.push(ManagedFile {
            path: file.path.clone(),
            manifest,
            executable,
            expected: file.expected.clone(),
        });
    }
    let mut deletions = Vec::with_capacity(planned.deletions.len());
    for deletion in &planned.deletions {
        cancel.check()?;
        deletions.push(ManagedDeletion {
            path: deletion.path.clone(),
            base: deletion.base.clone(),
            executable: deletion
                .expected_executable
                .ok_or_else(|| invalid("complete deletion source mode unknown"))?,
        });
    }
    let token = recovery_export::image_digest(&report, &planned.deletions, &[])?;
    let digest = token
        .strip_prefix("blake3:")
        .filter(|s| s.len() == 64)
        .ok_or_else(|| invalid("complete managed image digest malformed"))?
        .to_owned();
    checkpoint.revalidate_namespace()?;
    cancel.check()?;
    Ok(ImageData {
        files,
        deletions,
        digest,
    })
}
