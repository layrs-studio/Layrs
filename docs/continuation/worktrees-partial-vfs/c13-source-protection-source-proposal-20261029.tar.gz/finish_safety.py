from build_bundle import *
p=P+'shared/provider_import/content.rs'
s=read(p).replace('        require_staging_pair(inputs, cancel)?;','        require_staging_pair(inputs, cancel)?;\n        require_source_envelope(c,inputs,cancel)?;')
s+='''
fn require_source_envelope(c:&Connection,inputs:&ImportContentInputs<'_>,cancel:Option<&Cancellation>)->Result<()> {
    if inputs.source_staging.plan.companion_id.is_none() {return Ok(());}
    let context=inputs.source_context.as_ref().ok_or_else(||invalid("companion C effects require complete source family context"))?;
    let root=context.pending.ok_or_else(||invalid("companion C effects require separate fixed B reservation"))?;
    root.require_plan(inputs.allocation,inputs.source_staging,cancel)?;
    if root.inspect(c,cancel)?==crate::projection::shared::source_companion::SourceCompanionPresence::Absent {
        return Err(invalid("companion C effects cannot precede B reservation"));
    }
    root.require_union(inputs.required,cancel)?;
    root.require_capacity(c,cancel)
}
''';write(p,s)
p=P+'shared/source_companion.rs'
edit(p,'            || private_database_identity != &a.private.database_file_identity\n','')
edit(p,'        exact_protection::{ProtectionEffect, ProtectionPresence},','        exact_protection::ProtectionEffect,')
edit(p,'use rusqlite::{params, Connection, OptionalExtension};','use rusqlite::{params, Connection};')
p=P+'provider/validation/source_companion.rs';s=read(p)
i=s.index('            let bytes = layrs_core::scm::canonical_json(group)');e=s.index('\n        }',i)
s=s[:i]+'''            // Deterministic struct/BTreeMap serialization, streamed twice:
            // count with a bound, then hash. No aggregate group allocation.
            let mut count=ProofWriter{hash:None,bytes:0};
            serde_json::to_writer(&mut count,group).map_err(|e|invalid(e.to_string()))?;
            hash.update(&count.bytes.to_be_bytes());
            let mut writer=ProofWriter{hash:Some(hash),bytes:0};
            serde_json::to_writer(&mut writer,group).map_err(|e|invalid(e.to_string()))?;'''+s[e:]
s+='''
struct ProofWriter<'a> {hash:Option<&'a mut blake3::Hasher>,bytes:u64}
impl std::io::Write for ProofWriter<'_> {
    fn write(&mut self,b:&[u8])->std::io::Result<usize> {
        self.bytes=self.bytes.checked_add(b.len() as u64).filter(|n|*n<=1024*1024*1024)
            .ok_or_else(||std::io::Error::other("source private proof encoding exceeds bound"))?;
        if let Some(hash)=&mut self.hash {hash.update(b);}
        Ok(b.len())
    }
    fn flush(&mut self)->std::io::Result<()> {Ok(())}
}
''';write(p,s)
# Explicit guard of both pre-receipt C identity and member remains in physical
# source protection scopes, separate from the exact install/debit validation.
p=P+'provider/bootstrap/preparation/activation/managed_content/source_protection.rs'
needle='''                let state = validate_protected_installations('''
# rustfmt may put the complete invocation on one line; locate exact line.
s=read(p)
assert needle in s
s=s.replace(needle,'''                self.require_source_companion_destination_member(c,data)?;
'''+needle,1)
s=s.replace('''                bytes.require(binding, self.manifests, cancel)?;
                data.protection().inspect(c, Some(cancel))''','''                self.require_source_companion_destination_member(c,data)?;
                bytes.require(binding, self.manifests, cancel)?;
                data.protection().inspect(c, Some(cancel))''')
needle="impl ManagedImportLease<'_, '_, '_, '_> {"
s=s.replace(needle,needle+'''
    fn require_source_companion_destination_member(&self,c:&Connection,data:&SourceCompanionPublication<'_>)->CauseResult<()> {
        let destination=self.staging.destination.as_ref().ok_or_else(||invalid("source protection C destination absent"))?;
        let shared=destination.format.shared.as_ref().ok_or_else(||invalid("source protection C shared identity absent"))?;
        let valid:bool=c.query_row("SELECT EXISTS(SELECT 1 FROM worktrees WHERE id=?1 AND database_identity=?2 AND metadata_path=?3 AND marker=?4 AND state IN ('initializing','ready'))",
            rusqlite::params![data.protection().binding.destination.owner.as_str(),destination.private_database_identity,
                crate::projection::shared::provider_access::exact_path(&shared.metadata_path)?,destination.format.bytes()?],|r|r.get(0))?;
        if !valid {return Err(invalid("source protection C family member identity differs"));}Ok(())
    }
''')
write(p,s)
