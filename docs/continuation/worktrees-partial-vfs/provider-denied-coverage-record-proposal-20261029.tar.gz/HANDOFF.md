# C14 immutable denial coverage record — ROOT source work

This is the first implementation slice of the accepted durable-denial contract
in `tmp/c14-durable-denial-contract.json`. It is not complete C14 or a live
permission feature. The main checkout and running r98/r99/r100 source closure
remain unchanged. No compilation, SQL, native test, network or fixture open.

Three Rust files: one module declaration plus the new pure codec and its seven
registered DATA tests. The document fits the existing 64MiB
`projection_observations` BLOB constraint; no DDL change is proposed.

`TransitionDeniedCoverageRecord::from_observation` derives ALL explicit denied
paths from the real `TransitionObservationData` normalizer and matches its
actual versioned prefix ID, identities, source generation/snapshot/selection,
capture count/head and authority/path commitments. The record also commits the
prefix's effective image digest, transaction, Step/root, path semantics and
destination observation generation/snapshot/selection. It is DATA, never a
remote observation capability or a live transaction witness.

The document has a new domain-separated whole-body ID. `DeniedCoverageRef`
contains ID/count/pathBytes/rowsDigest for later REQUIRED versioned links.
`read_body` decodes the actual canonical payload and compares its complete
reference and SQL key. It does not open SQL or claim that a supplied reference
belongs to a validated plan. There is no final plan hash in the document, so
document -> plan -> receipt has no digest cycle.

The path limit is 100000 rows and 8MiB raw UTF-8 total, per-path 4096 bytes and
depth128. From-observation construction counts visible and denied namespace
rows together before cloning; it does not grant a second denial allowance.
The deserializer stops before retaining more than the count/byte bounds.
Canonical allocation follows path bounds; alias prefix maps have the existing
256MiB conservative index-work envelope. Strict BINARY ordering, duplicate,
Windows alias, ancestor and metadata-name checks apply. The row digest exactly
matches the normalizer's existing length-framed canonical-path commitment.

Authored tests: exact canonical-body/reference matching and independent row
hash framing; unknown/duplicate/missing/noncanonical fields; oversized decode;
Windows aliases/ancestors; 100000 paths at exactly 8MiB and one-byte overflow;
shared positive+negative namespace bounds; real normalizer derivation and
prefix mismatch plus typed precancellation. They are NOT RUN. The capacity
test is a DATA codec case, not durable persistence or performance evidence.

## Remaining integration, all required

1. Required versioned intent/plan-v2 and receipt-v2 links (compact, legacy v1
   byte-compatible), prefix-v3 denial-observations rowset. Do not add ignorable
   optional fields under old schema names. SourcePublished stays its full
   actual compact body within256KiB.
2. Under actual source owner/transaction, atomic coverage+Planned insertion;
   exact existing-byte replay, close/readback ordering and fixed full budget.
   Destination copy before dependent effects, using authenticated prefix scopes.
3. Scoped connection-retained body reader linked to actual plan/receipt/current
   observation, complete private/family inventories, C Ready/admission/autonomy
   and re-export transport. A standalone decoded record is not such a proof.
4. Current-generation negative acceptance fences for capture, namespace,
   restore/receive/rebase/selection and Provider mutation. Keep historical
   bodies, supersede live fences only via an explicit coherent observation.
5. Integrated source review, compilation, SQL/native/crash/tamper/autonomy and
   full-capacity persistence qualification. Existing strict readers continue
   to reject new observation rows until required versions are supported.

Merge the two-line records.rs declaration, not an older whole module file,
onto the cumulative C13 bundle. The earlier versioned-prefix fix at
`tmp/provider-observation-prefix-domain-fix` is needed for v2 derivation and is
already assigned to the C13 lease implementer. No other candidate is modified.
