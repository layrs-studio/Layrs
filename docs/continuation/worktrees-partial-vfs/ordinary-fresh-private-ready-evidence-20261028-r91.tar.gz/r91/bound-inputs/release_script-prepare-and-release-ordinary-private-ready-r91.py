"""ROOT invokes once after reading the completed r89 review and accepting r90.

This creates immutable source/artifact bindings; it executes no test or SQL.
"""
from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, sys

assert sys.argv[1:] == ['--root-accept-r89-review']
root, tmp = Path('D:/Layrs/layrs'), Path('D:/Layrs/tmp')
prior = root / '.layrs-local/validation/provider-ordinary-fresh-private-ready-20261028-r88'
out = root / '.layrs-local/validation/provider-ordinary-fresh-private-ready-20261028-r91'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pin = lambda p: dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))
normal = lambda p: p.read_text(encoding='utf-8').replace('\r\n', '\n')
head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD']).decode().strip()
assert head == '91c566ab6cf778f731167e7adc1334fc1a46ce73'
assert subprocess.check_output(['git', '-C', str(root), 'branch', '--show-current']).decode().strip() == 'feature/worktrees-partial-vfs'
manifest_path = tmp / 'provider-ordinary-checkout-progress-review-r89-inputs.json'
report_path = tmp / 'provider-ordinary-checkout-progress-critical-review-r89.json'
manifest, report = read(manifest_path), read(report_path)
assert sha(manifest_path) == '153fc804bfd947a2d0921357f11b89fd278905b928ef5db11ab362a673adb866'
assert not report['findings'], 'unresolved r89 finding'
diff = tmp / 'provider-ordinary-checkout-progress-review-r89.diff'
assert sha(diff) == manifest['diffSha256']
for e in manifest['files']:
    assert sha(root / e['path']) == sha(Path(manifest['snapshot']) / e['path']) == e['sha256'], e['path']
for e in report['inputs']['additional_dependencies']:
    p = Path(e['path'])
    assert p.is_relative_to(root) and e['unchanged']
    assert sha(p) == e['start']['sha256'] == e['end']['sha256']
    assert p.stat().st_size == e['start']['bytes'] == e['end']['bytes']
previous = read(prior / 'ordinary-fresh-private-ready-results.json')
assert len(previous['results']) == 5 and all(r['exit'] == 0 for r in previous['results'][:4]) and previous['results'][-1]['exit'] == 101
build, check = [tmp / f'provider-ordinary-checkout-progress-{kind}-r90.log' for kind in ['build', 'check']]
for p in [build, check]:
    raw = p.read_bytes()
    text = raw.decode('utf-16' if raw.startswith(b'\xff\xfe') else 'utf-8-sig')
    assert 'Finished `' in text and 'error[' not in text, p
audit = tmp / 'provider-ordinary-fresh-private-ready-host-audit-r91.py'
text = normal(tmp / 'provider-ordinary-fresh-private-ready-host-audit-r88.py').replace('r88', 'r91')
text = text.replace('Fresh private Ready r85 and retained Ready failure-order correction r86, with test-only phase timers and ROOT one-line SQL test pattern compilation correction; build/check r87b PASS. New runtime qualification pending.',
                    'Fresh private Ready and retained Ready ordering with r89 protected checkout-progress SQL, corrected inherited-receipt witness and finer allocation timing. Build/check r90 PASS; new runtime qualification pending.')
with audit.open('x', encoding='utf-8') as f: f.write(text)
subprocess.run(['py', str(audit), 'r91'], check=True)
host = read(out / 'host-disposition.json')
assert len(host['sourceClosure']) == 669
changed = []
for e in host['sourceClosure']:
    rel = Path(e['path']).relative_to(root)
    assert sha(root / rel) == sha(out / 'source' / rel) == e['sha256'], str(rel)
    if normal(root / rel) != normal(prior / 'source' / rel): changed.append(rel.as_posix())
assert set(changed) == set(manifest['changed']) and len(changed) == 7, changed
runner = tmp / 'provider-ordinary-fresh-private-ready-run-r91.py'
with runner.open('x', encoding='utf-8') as f:
    f.write(normal(tmp / 'provider-ordinary-fresh-private-ready-run-r88.py').replace('r88', 'r91'))
prior_release = read(prior / 'ordinary-fresh-private-ready-source-release.json')
# The two unchanged strict-read recipes already passed in r88. Re-run the two
# affected Ready SQL recipes and the five natives that never reached their
# target driver (or were not reached at all) in r88.
recipes = prior_release['recipes'][2:]
assert len(recipes) == 7
recipes[1]['scope'] = 'Protected checkout-progress SQL None/Owned/Verified/complete, strict finalizable refusal, exact family/manifest/budget, query-only/no-effects and corruption checks; separate family Ready publication.'
bindings = dict(runner=pin(runner), host_audit=pin(audit), release_script=pin(Path(__file__)),
    build=pin(build), workspace_check=pin(check), r89_manifest=pin(manifest_path), r89_review=pin(report_path), r89_diff=pin(diff),
    prior_results=pin(prior / 'ordinary-fresh-private-ready-results.json'), prior_release=pin(prior / 'ordinary-fresh-private-ready-source-release.json'),
    prior_archive=pin(root / 'docs/continuation/worktrees-partial-vfs/ordinary-fresh-private-ready-evidence-20261028-r88.tar.gz'),
    phase_analyzer=pin(tmp / 'analyze-native-phase-log.py'))
saved = out / 'bound-inputs'
saved.mkdir(exist_ok=False)
for name, entry in bindings.items(): shutil.copyfile(entry['path'], saved / (name + '-' + Path(entry['path']).name))
release = dict(decision='released', revision='r91', recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_head=head, artifact_audit=host['executable'],
    reviewer='Independent critical source review r89 plus ROOT integrated acceptance; prior r85/r86 review evidence retained in bound r88 archive.',
    source_review='All669 source inputs match live/retained; exactly7 paths differ from r88 and equal frozen r89 delta. Build/check r90 PASS. Runtime pending at release.',
    reused_evidence='Two unchanged strict-read recipes passed under retained r88; no new r91 runtime claim for those recipes.',
    limitations=prior_release['limitations'] + ['The SQL progress reader grants no physical partial-checkout recovery rights. r88 failed at the setup receipt witness before the fresh driver.'],
    recipes=recipes, input_bindings=bindings)
path = out / 'ordinary-fresh-private-ready-source-release.json'
with path.open('x', encoding='utf-8') as f: json.dump(release, f, indent=2)
print(json.dumps(dict(release=pin(path), source_inputs=len(host['sourceClosure']), changed=len(changed), recipes=len(recipes))))
