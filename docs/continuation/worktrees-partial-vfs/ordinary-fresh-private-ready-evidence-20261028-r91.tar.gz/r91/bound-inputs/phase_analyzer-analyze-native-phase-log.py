"""Read retained test logs only; never open or run a product fixture.

Phase lifetimes can overlap (outer setup and its inner phases), so their sums
must not be interpreted as whole-test elapsed time. END is not a test verdict.
"""
from pathlib import Path
import argparse
import collections
import hashlib
import json
import re

pattern = re.compile(
    r'LAYRS_TEST_PHASE phase=(\S+) event=(START|END) '
    r'elapsed_seconds=([0-9]+(?:\.[0-9]+)?) unwinding=(true|false)'
)


def analyze(path):
    raw = path.read_bytes()
    phases = {}
    events = []
    outstanding = collections.Counter()
    unmatched = []
    for line_number, line in enumerate(raw.decode('utf-8', errors='replace').splitlines(), 1):
        match = pattern.search(line)
        if not match:
            continue
        name, kind, seconds, unwinding = match.groups()
        duration = float(seconds)
        row = dict(line=line_number, phase=name, event=kind,
                   elapsed_seconds=duration, unwinding=unwinding == 'true')
        events.append(row)
        phase = phases.setdefault(name, dict(phase=name, starts=0, ends=0,
                                             unwinding_ends=0, durations_seconds=[]))
        if kind == 'START':
            outstanding[name] += 1
            phase['starts'] += 1
        else:
            if outstanding[name]:
                outstanding[name] -= 1
            else:
                unmatched.append(dict(line=line_number, phase=name, reason='END without START'))
            phase['ends'] += 1
            phase['unwinding_ends'] += int(row['unwinding'])
            phase['durations_seconds'].append(duration)
    summary = []
    for phase in phases.values():
        samples = phase['durations_seconds']
        phase['open_starts'] = outstanding[phase['phase']]
        phase['sum_seconds'] = round(sum(samples), 6)
        phase['maximum_seconds'] = max(samples, default=None)
        summary.append(phase)
    summary.sort(key=lambda row: row['sum_seconds'], reverse=True)
    return dict(path=str(path.resolve()), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest(),
                status='phase_events_observed' if events else 'no_phase_events',
                warning='Nested phase durations overlap; do not add phases to infer whole-test time. END does not establish success.',
                phases=summary, unmatched_ends=unmatched, events=events)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('logs', type=Path, nargs='+', help='Explicit retained log files; no fixtures')
    parser.add_argument('--output', type=Path, help='Create a new JSON report exclusively')
    args = parser.parse_args()
    report = dict(schema_version=1, logs=[analyze(path) for path in args.logs])
    encoded = json.dumps(report, indent=2)
    if args.output:
        with args.output.open('x', encoding='utf-8') as f:
            f.write(encoded + '\n')
        print(json.dumps(dict(report=str(args.output), logs=len(report['logs']),
                              phases=sum(len(log['phases']) for log in report['logs']))))
    else:
        print(encoded)
